package com.ly.member.service.impl.computingAccountChange.impl;

import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IComputingAccountService;
import com.ly.member.service.impl.computingAccountChange.ComputingAccountChange;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 10:16
 * @desc 算力值确认支付（减掉冻结金额）
 */
@Service("ComputingAccountConfirmPay")
@AllArgsConstructor
public class ConfirmPay implements ComputingAccountChange {

    private final IComputingAccountDetailService computingAccountDetailService;

    private final IComputingAccountService computingAccountService;

    @Override
    public ComputingAccountDetail change(ComputingAccount computingAccount, BigDecimal amount, BigDecimal oldAmount, ComputingAccountDetail oldDetail,Integer operationType,String remark) {
        if (computingAccount.getFreezeAmount().compareTo(amount) < 0) {
            //小于则抛出异常，认为传入金额错误
            throw new ServiceException(ResultCode.ACCOUNT_FREEZE_NOT_ENOUGH);
        } else if (computingAccount.getFreezeAmount().compareTo(amount) == 0) {
            //等于那只需要扣去冻结的
            computingAccount.setFreezeAmount(computingAccount.getFreezeAmount().subtract(amount));
        } else {
            //大于实际支付金额，则扣去冻结的，还要补回余额
            computingAccount.setFreezeAmount(computingAccount.getFreezeAmount().subtract(oldAmount));
            computingAccount.setAvailableAmount(computingAccount.getAvailableAmount().add(oldAmount.subtract(amount)));
        }

        computingAccountService.updateById(computingAccount);
        oldDetail.setStatus(ComputingAccountChangeEnum.CONFIRM_PAY.getCode());
        //更新账单支付金额
        oldDetail.setPayAmount(amount);
        computingAccountDetailService.updateById(oldDetail);
        return oldDetail;
    }
}
