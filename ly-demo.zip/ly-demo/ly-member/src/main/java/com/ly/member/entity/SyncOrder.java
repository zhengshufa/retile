package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 同步订单表（vst订单）
 * </p>
 *
 * @author sean
 * @since 2024-12-20 15:54:03
 */
@Getter
@Setter
@TableName("sync_order")
public class SyncOrder extends BaseEntity {

    @Serial
    private static final long serialVersionUID = 1L;


    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 操作类型
     */
    private Integer operationType;

    /**
     * 金额
     */
    private BigDecimal amount;

    /**
     * 第三方订单号
     */
    private String billNo;

    /**
     * 分佣金额
     */
    private BigDecimal sharingAmount;

    /**
     * 无需分佣金额·
     */
    private BigDecimal nonSharingAmount;

    /**
     * 分佣代数
     */
    private Integer sharingGeneration;

    /**
     * 初代分润金额·
     */
    private BigDecimal sharingFirstGenerationAmount;

    /**
     * 公司利润（仅店铺卖货有）
     */
    private BigDecimal companyProfit;

    /**
     * 沉淀小数金额
     */
    private BigDecimal depositDecimalAmount;

    /**
     * 备注
     */
    private String remark;
}
