package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  注销会员VO
 */
@Schema(description = "注销会员VO")
@Data
public class MemberLogoutVO {

    @Schema(description = "推荐码")
    private String referralCode;

}
