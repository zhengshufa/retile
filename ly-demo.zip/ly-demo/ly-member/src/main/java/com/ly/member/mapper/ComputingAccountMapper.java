package com.ly.member.mapper;

import com.ly.member.entity.ComputingAccount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 算力账号表 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface ComputingAccountMapper extends BaseMapper<ComputingAccount> {

}
