package com.ly.member.service.impl;

import com.ly.member.entity.SyncOrder;
import com.ly.member.mapper.SyncOrderMapper;
import com.ly.member.service.ISyncOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 同步订单表（vst订单） 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-12-20 15:54:03
 */
@Service
public class SyncOrderServiceImpl extends ServiceImpl<SyncOrderMapper, SyncOrder> implements ISyncOrderService {

}
