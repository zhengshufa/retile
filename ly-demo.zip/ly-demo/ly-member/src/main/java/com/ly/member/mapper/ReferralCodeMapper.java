package com.ly.member.mapper;

import com.ly.member.entity.ReferralCode;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 推荐码生成表 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-12-27 10:28:04
 */
public interface ReferralCodeMapper extends BaseMapper<ReferralCode> {

}
