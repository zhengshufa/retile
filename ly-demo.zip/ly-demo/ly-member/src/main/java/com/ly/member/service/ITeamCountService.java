package com.ly.member.service;

import com.ly.member.entity.TeamCount;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 团队数量统计 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface ITeamCountService extends IService<TeamCount> {

}
