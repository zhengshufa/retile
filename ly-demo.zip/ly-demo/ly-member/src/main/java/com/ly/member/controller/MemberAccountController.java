package com.ly.member.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberAccountDTO;
import com.ly.member.entity.VO.*;
import com.ly.member.service.IMemberAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    会员账户相关接口
 */
@RestController
@RequestMapping("memberAccount")
@Schema(title = "会员账户相关接口")
@AllArgsConstructor
public class MemberAccountController {

    private final IMemberAccountService memberAccountService;

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员账户列表(分页)
     */
    @PostMapping("memberAccountPage")
    @Operation(summary = "会员账户列表查询(分页)")
    public R<Page<MemberAccountDTO>> memberAccountPage(@RequestBody MemberAccountPageVO vo){
        return memberAccountService.memberAccountPage(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员账户信息
     */
    @PostMapping("memberAccount")
    @Operation(summary = "会员账户信息查询")
    public R<MemberAccountDTO> memberAccount(@RequestBody MemberAccountVO vo){
        return memberAccountService.memberAccount(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/18 11:17
     * @desc: 会员账号提现申请
     */
    @PostMapping("memberAccountWithdraw")
    @Operation(summary = "会员账号提现申请")
    public R<String> memberAccountWithdraw(@RequestBody MemberAccountWithdrawVO vo){
        return memberAccountService.memberAccountWithdraw(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/18 11:31
     * @desc: 会员账号提现
     */
    @PostMapping("memberAccountWithdrawChange")
    @Operation(summary = "会员账号提现")
    public R<String> memberAccountWithdrawChange(@RequestBody MemberAccountWithdrawChangeVO vo){
        return memberAccountService.memberAccountWithdrawChange(vo);
    }



    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员账户支付
     */
    @PostMapping("memberAccountPay")
    @Operation(summary = "会员账户支付")
    public R<String> memberAccountPay(@RequestBody MemberAccountChangeVO vo){
        return memberAccountService.memberAccountPay(vo);
    }

    @PostMapping("memberAccountAdd")
    @Operation(summary = "会员账户充值")
    public R<String> memberAccountAdd(@RequestBody MemberAccountAddVO vo){
        return memberAccountService.memberAccountAdd(vo);
    }


}
