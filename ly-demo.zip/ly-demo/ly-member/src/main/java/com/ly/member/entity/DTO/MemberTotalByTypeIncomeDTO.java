package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户DTO
 */

@Schema(description = "会员账户DTO")
@Data
public class MemberTotalByTypeIncomeDTO {

    @Schema(description = "收益方的推荐码")
    private String referralCode;

    @Schema(description = "已分佣金额")
    private BigDecimal sharingAmount = BigDecimal.ZERO;

    @Schema(description = "未分佣金额")
    private BigDecimal nonSharingAmount = BigDecimal.ZERO;

    @Schema(description = "订单类型")
    private Integer billType;
}
