package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 算力账号操作详情
 * </p>
 *
 * @author sean
 * @since 2024-12-17 10：12：04
 */
@Getter
@Setter
@TableName("computing_account_detail")
public class ComputingAccountDetail extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 会员id
     */
    private Long memberId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 操作单号
     */
    private String operationNo;

    /**
     * 操作类型（1-充值，2-任务，3-课程观看，4-AI经纪人，5-数字主播视频，6-AI经纪人模型）
     */
    private Integer operationType;

    /**
     * 金额
     */
    private BigDecimal amount;

    /**
     * 支付金额
     */
    private BigDecimal payAmount;

    /**
     * 第三方订单号（支付的情况下才有）
     */
    private String billNo;

    /**
     * 备注
     */
    private String remark;
}
