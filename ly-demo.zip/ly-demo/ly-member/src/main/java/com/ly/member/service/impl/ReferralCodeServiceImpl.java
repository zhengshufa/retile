package com.ly.member.service.impl;

import cn.hutool.crypto.SecureUtil;
import com.alibaba.csp.sentinel.util.StringUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.Constant;
import com.ly.distribute.DistributeLock;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.config.Config;
import com.ly.member.entity.Member;
import com.ly.member.entity.ReferralCode;
import com.ly.member.entity.VO.MemberRegisterVO;
import com.ly.member.mapper.ReferralCodeMapper;
import com.ly.member.service.IReferralCodeService;
import com.ly.utils.HttpUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.ly.constant.Constant.COMPANY_REFERRED_CODE;

/**
 * <p>
 * 推荐码生成表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-12-27 10:28:04
 */
@Service
@AllArgsConstructor
@Slf4j
public class ReferralCodeServiceImpl extends ServiceImpl<ReferralCodeMapper, ReferralCode> implements IReferralCodeService {

    private final RedisTemplate<String, String> redisTemplate;

    private final Config config;

    private final DistributeLock distributeLock;


    @Override
    public String referralCodeInit(String country) {
        //生成推荐码的方式有2种，一个是默认的10位数字，一个是合作伙伴的，国别+8位随机数
        if(StringUtil.isEmpty(country)){
            ReferralCode referralCode = new ReferralCode();
            this.save(referralCode);
            if(Objects.equals(referralCode.getId(), COMPANY_REFERRED_CODE)){
                return referralCodeInit(country);
            }
            return String.valueOf(referralCode.getId());
        }else{
            //合作伙伴推荐码生成
            return country + getCodesForBusinessOperation();
        }

    }

    // 从 Redis 池中获取 ID，若 ID 池为空则补充新 ID
    public String getCodesForBusinessOperation() {
        // 监视 code 池
        String code;
        int count = 0;
            // 尝试从 Redis 池中取出一个 ID
        code = redisTemplate.opsForList().leftPop(Constant.REFERRAL_CODE_POOL_KEY);
        if (StringUtil.isEmpty(code)) {
            String lockKey = Constant.REFERRAL_CODE_POOL_KEY;
            boolean isLock = false;
            try {
                isLock = distributeLock.tryLock(lockKey, 1000);
                if (isLock) {
                    // 从数据库获取新的 ID
                    List<String> newCodes = getNewIdsFromDatabase();
                    // 将新 ID 批量放入 Redis
                    redisTemplate.opsForList().rightPushAll(Constant.REFERRAL_CODE_POOL_KEY, newCodes);
                }
            } catch (Exception e) {
                log.error("获取合作伙伴推荐码失败,重试次数：{}",count, e);
            } finally {
                if (isLock) {
                    distributeLock.unlock(lockKey);
                }
            }
            code = redisTemplate.opsForList().leftPop(Constant.REFERRAL_CODE_POOL_KEY);
        }
        if(StringUtil.isEmpty(code)){
            throw new ServiceException(ResultCode.REFERRAL_CODE_CAN_NOT_GET);
        }
        return code;
    }

    // 从合作伙伴处获取推荐码
    private List<String> getNewIdsFromDatabase() {
        try{
            HttpUtils.trustAllCertificates();
            long l = System.currentTimeMillis();
            String sign = SecureUtil.md5(l + config.getAuthKey());
            String url = config.getUrl() + config.getCodeUrl() + "?timestamp=" + l + "&authId=" + sign;
            System.out.println(url);
            String response = HttpUtils.sendGetRequest(url);
            List<String> newCodes = new ArrayList<>();
            JSONArray jsonArray = JSONObject.parseObject(response).getJSONArray("data");
            for (Object node : jsonArray) {
                newCodes.add(String.valueOf(node));
            }
            if(newCodes.isEmpty()){
                log.error("获取合作伙伴推荐码为空,返回的response：{}",response);
                throw new ServiceException(ResultCode.REFERRAL_CODE_CAN_NOT_GET);
            }
            return newCodes;
        }catch (Exception e){
            log.error("获取合作伙伴推荐码失败",e);
            throw new ServiceException(ResultCode.REFERRAL_CODE_CAN_NOT_GET);
        }
    }


    @Override
    public boolean registerV(MemberRegisterVO vo,String referralCode){
        try{
            HttpUtils.trustAllCertificates();
            long l = System.currentTimeMillis();
            String sign = SecureUtil.md5(referralCode + vo.getReferralCode() + vo.getCountry() + vo.getLocale() + vo.getPassword() + vo.getPassword() + l + config.getAuthKey());
            String url = config.getUrl() + config.getRegisterUrl() + "?userCode=" + referralCode + "&recommendNo=" + vo.getReferralCode() + "&companyCode=" + vo.getCountry() + "&locale=" + vo.getLocale() + "&password=" + vo.getPassword() + "&password2=" + vo.getPassword() + "&timestamp=" + l + "&authId=" + sign + "&email=" + vo.getEmail() + "&petName=" + vo.getNickname();
            System.out.println(url);
            String response = HttpUtils.sendGetRequest(url);
            if(StringUtil.isEmpty(response) || !response.contains(referralCode)){
                log.error("合作伙伴注册失败,返回的response：{}",response);
                return false;
            }
            return true;
        }catch (Exception e){
            log.error("合作伙伴注册失败",e);
            return false;
        }
    }

    @Override
    public boolean registerSpecial(Member member, String referralCode) {
        try{
            HttpUtils.trustAllCertificates();
            long l = System.currentTimeMillis();
            String sign = SecureUtil.md5(referralCode + member.getReferralCode() + member.getCountry() + member.getLocale() + member.getReferralCode() + member.getReferralCode() + l + config.getAuthKey());
            String url = config.getUrl() + config.getRegisterUrl() + "?userCode=" + referralCode + "&recommendNo=" + member.getReferralCode() + "&companyCode=" + member.getCountry() + "&locale=" + member.getLocale() + "&password=" + member.getReferralCode() + "&password2=" + member.getReferralCode() + "&timestamp=" + l + "&authId=" + sign + "&email=" + member.getEmail() + "&petName=" + member.getNickname();
            System.out.println(url);
            String response = HttpUtils.sendGetRequest(url);
            if(StringUtil.isEmpty(response) || !response.contains(referralCode)){
                log.error("合作伙伴注册失败,返回的response：{}",response);
                return false;
            }
            return true;
        }catch (Exception e){
            log.error("合作伙伴注册失败",e);
            return false;
        }
    }
}
