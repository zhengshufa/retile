package com.ly.member.service;

import com.ly.member.entity.Partner;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author sean
 * @since 2024-23-18 13：12：44
 */
public interface IPartnerService extends IService<Partner> {

}
