package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  会员注册VO
 */
@Schema (description = "会员注册VO")
@Data
public class MemberRegisterVO {

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "用户昵称")
    private String nickname;

    @Schema(description = "国别")
    private String country;

    @Schema(description = "推荐人的推荐码")
    private String referralCode;

    @Schema(description = "语言设置")
    private String locale;

    /*以下信息不记录*/
    @Schema(description = "密码（md5加密）")
    private String password;

}
