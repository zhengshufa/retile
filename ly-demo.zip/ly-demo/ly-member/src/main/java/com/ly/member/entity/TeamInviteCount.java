package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 团队邀请数量统计（天）
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Data
@TableName("team_invite_count")
public class TeamInviteCount implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;



    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 数量
     */
    private Integer count;

    /**
     * 日期
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATE)
    private Date date;


    /**
     * 创建时间
     */

    @DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;


    /**
     * 更新时间
     */

    @DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    @TableField(condition = "update_time", updateStrategy = FieldStrategy.NEVER)
    private Date updateTime;

    /**
     * 状态[1:正常]
     */
    private Integer status;

    /**
     * 状态[0:未删除,1:删除]
     */
    @TableLogic
    private Integer isDeleted;
}
