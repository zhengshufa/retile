package com.ly.member.entity.DTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户明细DTO
 */

@Schema(description = "会员账户明细DTO")
@Data
public class MemberAccountDetailDTO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "操作类型（1-分佣，2-提现，3-支付）")
    private Integer operationType;

    @Schema(description = "创建时间/操作时间/支付时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "金额")
    private BigDecimal amount;

    @Schema(description = "订单号（提现和支付的情况下才有）")
    private String billNo;

    @Schema(description = "状态：0-充值，1-扣款，2-提现冻结，5-确认提现，6-取消提现，7-冻结分佣金额，8-解除冻结的分佣金额，9-转入不可用金额")
    private Integer status;


}
