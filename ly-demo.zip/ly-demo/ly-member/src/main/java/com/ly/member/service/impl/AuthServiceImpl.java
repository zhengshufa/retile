package com.ly.member.service.impl;

import cn.hutool.cache.Cache;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.constant.Constant;
import com.ly.member.entity.Partner;
import com.ly.member.service.IAuthService;
import com.ly.member.service.IPartnerService;
import com.ly.utils.signatureUtil.rsa.RSACoder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.TreeMap;

/**
 * packageName.className com.ly.pay.service.impl.AuthServiceImpl
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 9:59
 * @description
 */
@Slf4j
@Service
@AllArgsConstructor
public class AuthServiceImpl implements IAuthService {


    private static final String VST_PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKj6WggOj9Y5zsbbAbHZWeLl14nbGP3DwY/+U2GEfdOoXJoACKfcFScd6ysa0LMQwBxqzdHFZtu7ktfoZrqpuyl5JWMsRAusC4ma81uRtRxwzPcXRCUgWHwxcE7CSuwJ/hoO41+4x6/nLtMtgxQ1Gp5m+gpX9P/Y1asO4zWc655DAgMBAAECgYA28eDgicuffwCLjJ8Kc4BU1SO2wbVonoSMC8iVBv3bGv2xXZ1y549BPus/AuMltqahFuGB+kwt2toutnTg8VvX4J/STOE7VxOUkrmQaDKqsZeJHW2+oTd40Wcv1e+wbCpknhhgDPQfEySPH4Vvg/FesxJ1WETks64iSSneBkDeEQJBAKsKq3B38Qu5Y29BQjXcj2/4+/KIAc9KMedStuIVNwBnbXytYS17GPjh1/nu1XNRzW8UtkQtmX77XZh84nAyP/UCQQD86UKxcpRW9SXIWGtdAqJV4NnCaLfPvsNGfNGMpvBP4TG4ClY5XhSSt4jcBUa9vMV6fR8XMBIVfOmwlupxVRpXAkAwNN6i4Tsvyb1rsuHdWl+W+H7SGWEhMlEkWFyxFbedxojGNfuInQQpyUVc7OJ+ERUsdJL2Xj+/2UrE2pXbd14tAkAkDCc6XYdxIX3iIWAkIKT8spC3Ge/hB2KT4GSJtJ2Z9RH+FlMV2Cf8hXZXTdU4Y/iNrdnJl0tsjqJMTiZaQvP/AkEAiGvzyQH7vqFc3MFDwXytA0ysCsybNS4I36Y8YyDitrX+ENuud/OuBhzzO8yiTY2qLtmOOptAYxYQ4i13jXouPw==";

    private final IPartnerService partnerService;

    private final Cache<String,String> guavaCacheConfig;

    @Override
    public String vstEncode(String inputStr) throws Exception {
        return RSACoder.sign(inputStr.getBytes(StandardCharsets.UTF_8), VST_PRIVATE_KEY);

    }

    @Override
    public Boolean verifyAndDecode(String headerId, String sign, String jsonStr) throws Exception {
        TreeMap<String, String> treeMap = JSON.parseObject(jsonStr, new TypeReference<TreeMap<String, String>>() {});
        StringBuilder sb = new StringBuilder();
        treeMap.forEach((k, v) -> {
            sb.append(k).append("=").append(v).append("&");
        });
        String publicKey = guavaCacheConfig.get(Constant.MEMBER_PARTNER + headerId);
        if(StringUtils.isEmpty(publicKey)){
            Partner partner = partnerService.getOne(new LambdaQueryWrapper<Partner>().eq(Partner::getPartnerCode,headerId));
            if(Objects.isNull(partner)){
                return false;
            }
            guavaCacheConfig.put(Constant.MEMBER_PARTNER + headerId, partner.getPublicKey());
        }
        log.info(sb.toString());
        return RSACoder.verify(sb.toString().getBytes(StandardCharsets.UTF_8), publicKey, sign);
    }
}