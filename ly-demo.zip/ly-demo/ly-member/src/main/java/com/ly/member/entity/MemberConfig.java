package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 配置表
 * </p>
 *
 * @author sean
 * @since 2024-12-25 11:43:40
 */
@Getter
@Setter
@TableName("member_config")
public class MemberConfig extends BaseEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * 分佣时限配置(天)
     */
    private Integer sharingTime;

    /**
     * 会员过期分佣时限配置项（单位：天。该时间内过期会将分佣金额放到分佣冻结金额里，该时间外过期会将分佣金额放到不可用金额里）
     */
    private Integer memberExpireTime;


    /**
     * AI经纪人消息发送价格(前面的是会员价格，后面的是非会员价格)
     */
    private String aiBrokerMsgFee;
}
