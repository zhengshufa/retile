package com.ly.member.service;

import com.ly.member.entity.BusinessLog;
import com.baomidou.mybatisplus.extension.service.IService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * <p>
 * 第三方请求和业务处理日志表 服务类
 * </p>
 *
 * @author sean
 * @since 2024-12-28 10:13:20
 */
public interface IBusinessLogService extends IService<BusinessLog> {

    void saveLogAsync(BusinessLog businessLog);

}
