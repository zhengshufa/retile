package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  会员改网VO
 */
@Schema (description = "会员改网VO")
@Data
public class ReferralChangeVO {

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "推荐人的推荐码")
    private String recommendCode;

}
