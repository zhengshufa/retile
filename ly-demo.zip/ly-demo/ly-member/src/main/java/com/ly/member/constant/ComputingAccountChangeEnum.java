package com.ly.member.constant;

import com.ly.member.service.impl.computingAccountChange.ComputingAccountChange;
import com.ly.member.service.impl.computingAccountChange.impl.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 算力账号操作类型
 */
@Getter
@AllArgsConstructor
public enum ComputingAccountChangeEnum {

    //算力账号操作类型

    ADD(0,"增加", Add.class),
    REDUCE(1,"减少", Reduce.class ),
    FREEZE(2,"冻结", Freeze.class),
    //(减掉冻结金额)
    CONFIRM_PAY(3,"确认支付", ConfirmPay.class),
    THAW(4,"解冻", Thaw.class),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    final Class<? extends ComputingAccountChange> clazz;

    public static ComputingAccountChangeEnum fromCode(int code) {
        for (ComputingAccountChangeEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
