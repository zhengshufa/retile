package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.*;
import com.ly.member.entity.SharingRecord;
import com.ly.member.entity.VO.*;

import java.util.List;

/**
 * <p>
 * 分佣记录 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface ISharingRecordService extends IService<SharingRecord> {

    R<MemberIncomeDTO> memberIncome(MemberIncomeVO vo);

    R<List<MemberIncomeDetailDTO>> memberIncomeDetailList(MemberIncomeDetailVO vo);

    R<Page<SharingRecordDetailDTO>> sharingRecordDetailPage(SharingRecordDetailVO vo);

    R<Page<MemberTotalIncomeDTO>> memberTotalIncome(MemberTotalIncomeVO vo);

    R<Page<MemberTotalByTypeIncomeDTO>> memberTotalByTypeIncome(MemberTotalByTypeIncomeVO vo);

    R<Page<SharingRecordDetailDTO>> recordDetailPage(RecordDetailVO vo);

}
