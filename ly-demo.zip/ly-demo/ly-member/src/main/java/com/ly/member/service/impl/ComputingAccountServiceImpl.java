package com.ly.member.service.impl;

import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.ComputingAccountOperationTypeEnum;
import com.ly.constant.Constant;
import com.ly.constant.YesOrNoEnum;
import com.ly.distribute.DistributeLock;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.config.Config;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.DTO.ComputingAccountDTO;
import com.ly.member.entity.Member;
import com.ly.member.entity.MemberConfig;
import com.ly.member.entity.VO.*;
import com.ly.member.mapper.ComputingAccountMapper;
import com.ly.member.mapstruct.ComputingAccountDTOMapStruct;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IComputingAccountService;
import com.ly.member.service.IMemberConfigService;
import com.ly.member.service.IMemberService;
import com.ly.member.service.impl.computingAccountChange.ComputingAccountChangeFactory;
import com.ly.utils.PageBeanUtils;
import com.ly.utils.signatureUtil.rsa.RSACoder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Base64;
import java.util.Objects;

/**
 * <p>
 * 算力账号表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
@Slf4j
public class ComputingAccountServiceImpl extends ServiceImpl<ComputingAccountMapper, ComputingAccount> implements IComputingAccountService {

    private final IMemberService memberService;

    private final ComputingAccountDTOMapStruct computingAccountDTOMapStruct;

    private final DistributeLock distributeLock;

    private final IComputingAccountDetailService computingAccountDetailService;

    private final RedisTemplate<String,String> redisTemplate;

    private final IMemberConfigService memberConfigService;

    private final ComputingAccountChangeFactory computingAccountChangeFactory;

    private final Config config;

    @Override
    public R<ComputingAccountDTO> computingAccountDetail(ComputingAccountVO vo) {
        Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            // 会员码不存在
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        ComputingAccount computingAccount = this.getOne(new LambdaQueryWrapper<ComputingAccount>().eq(ComputingAccount::getReferralCode, member.getReferralCode()));
        return R.data(computingAccountDTOMapStruct.toDto(computingAccount));
    }

    @Override
    public R<Page<ComputingAccountDTO>> computingAccountList(ComputingAccountPageVO vo) {
        Page<ComputingAccount> computingAccountPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()));
        Page<ComputingAccountDTO> page = PageBeanUtils.copyProperties(computingAccountPage, computingAccountDTOMapStruct);
        return R.data(page);
    }

    @Override
    public R<String> consumption(ComputingAccountConsumptionVO vo) {
        //算力账户消费
        Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            // 推荐码下无会员信息
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }
        // 判断是新单子还是旧单子
        if (StringUtils.isEmpty(vo.getOperationNo())) {
            return handleNewOrder(member, vo);
        } else {
            return handleOldOrder(member, vo);
        }
    }

    @Override
    @Transactional
    public R<String> computingAccountConsumption(ComputingAccountConsumptionVO vo) {
        //算力账户消费
        return consumption(vo);
    }

    private R<String> handleNewOrder(Member member, ComputingAccountConsumptionVO vo) {
        if (Objects.equals(vo.getOperationType(), ComputingAccountOperationTypeEnum.AI_DIGITAL_VIDEO.getCode())  || Objects.equals(vo.getOperationType(), ComputingAccountOperationTypeEnum.AI_DIGITAL_VOICE.getCode()) || Objects.equals(vo.getOperationType(), ComputingAccountOperationTypeEnum.TUTOR_APPOINTMENT.getCode())) {
            // 视频生成，声音克隆，导师预约需要冻结
            return handleOperation(member, null,vo, ComputingAccountChangeEnum.FREEZE);
        } else {
            return handleOperation(member,null, vo, ComputingAccountChangeEnum.REDUCE);
        }
    }

    private R<String> handleOldOrder(Member member, ComputingAccountConsumptionVO vo) {
        ComputingAccountDetail oldDetail = computingAccountDetailService.getOne(new LambdaQueryWrapper<ComputingAccountDetail>()
                .eq(ComputingAccountDetail::getOperationNo, vo.getOperationNo())
                .eq(ComputingAccountDetail::getStatus, ComputingAccountChangeEnum.FREEZE.getCode()));
        if(Objects.isNull(oldDetail)){
            log.error("account detail not exist");
            throw new ServiceException(ResultCode.ACCOUNT_DETAIL_NOT_EXIST);
        }
        if (Objects.equals(vo.getOperationType(), ComputingAccountOperationTypeEnum.CONFIRM_PAY.getCode())) {
            // 确认支付
            // 如果金额不一样，则需要把冻结金额减去一部分，解掉一部分
            return handleOperation(member,oldDetail, vo, ComputingAccountChangeEnum.REDUCE);
        } else {
            // 取消支付
            return handleOperation(member, oldDetail,vo, ComputingAccountChangeEnum.THAW);
        }
    }

    private R<String> handleOperation(Member member, ComputingAccountDetail oldDetail, ComputingAccountConsumptionVO vo, ComputingAccountChangeEnum changeType) {
        try{
            ComputingAccountDetail computingAccountDetail = computingAccountChange(member.getId(), vo.getAmount(),Objects.isNull(oldDetail)?BigDecimal.ZERO:oldDetail.getAmount(),changeType,oldDetail,vo.getOperationType(),null);
            return R.data(computingAccountDetail.getOperationNo());
        } catch (ServiceException e) {
            log.error("算力账户操作失败",e);
            throw e;
        } catch (Exception e) {
            log.error("算力账户操作失败，会员id:{}，金额:{}", member.getId(), vo.getAmount());
            log.error("算力账户操作失败",e);
            throw new ServiceException(ResultCode.FAILURE);
        }
    }

    @Override
    @Transactional
    public R<String> computingAccountAdd(ComputingAccountAddVO vo) {
        Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            // 推荐码下无会员信息
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }
        try {
            // 更新算力账号
            ComputingAccountDetail computingAccountDetail = computingAccountChange(member.getId(), vo.getAmount(),null, ComputingAccountChangeEnum.ADD,null,vo.getOperationType(),vo.getRemark());
            return R.data(computingAccountDetail.getOperationNo());
        } catch (ServiceException e) {
            log.error("算力充值接口业务失败",e);
            throw e;
        } catch (Exception e) {
            log.error("算力账户操作失败，会员id:{}，金额:{}", member.getId(), vo.getAmount());
            log.error("算力充值接口未知异常",e);
            throw new ServiceException(ResultCode.FAILURE);
        }

    }



    /**
     * @author: sean
     * @date: 2024/12/18 15:05
     * @param memberId 会员id
     * @param amount 金额
     * @param computingAccountChangeEnum 算力账户变动类型
     * @desc: 算力账号增加金额方法（所有增加算力值的都调用这个方法）
     */
    @Override
    public ComputingAccountDetail computingAccountChange(Long memberId, BigDecimal amount,BigDecimal oldAmount,ComputingAccountChangeEnum computingAccountChangeEnum,ComputingAccountDetail oldDetail,Integer operationType,String remark){
        //3、分布式锁，防止重复提交
        String lockKey = Constant.COMPUTING_ACCOUNT + memberId;
        boolean isLock = false;
        try {
            isLock = distributeLock.tryLock(lockKey, 10000);
            if (isLock) {
                //算力值修改
                ComputingAccount computingAccount = this.getOne(new LambdaQueryWrapper<ComputingAccount>().eq(ComputingAccount::getMemberId, memberId));
                return computingAccountChangeFactory.creator(computingAccountChangeEnum).change(computingAccount, amount, oldAmount,oldDetail,operationType,remark);
            }
        } finally {
            if (isLock) {
                distributeLock.unlock(lockKey);
            }
        }
        log.error("会员账号修改余额方法失败,memberId:{}", memberId);
        throw new ServiceException(ResultCode.FAILURE);
    }


    @Override
    public R<Boolean> computingAccountCheck(ComputingAccountCheckVO vo) {
        try{
            // 根据令牌解析出会员，然后判断是否足够支付本次算力消费
            String token = new String(RSACoder.decryptByPrivateKey(Base64.getDecoder().decode(vo.getToken()), config.getServerPrivateKey()));
            String[] tokenStr = token.split(":");
            if(tokenStr.length != 3){
                log.error("令牌解析失败，token:{}",token);
                return R.fail(ResultCode.UN_AUTHORIZED);
            }
            String referralCode = tokenStr[0];
            long expireTime = Long.parseLong(tokenStr[2]);
            if(System.currentTimeMillis() > expireTime){
                log.error("令牌已过期，token:{}",token);
                return R.fail(ResultCode.UN_AUTHORIZED);
            }
            Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, referralCode));
            if (Objects.isNull(member)) {
                // 推荐码下无会员信息
                return R.fail(ResultCode.MEMBER_NOT_EXIST);
            }
            ComputingAccount computingAccount = this.getOne(new LambdaQueryWrapper<ComputingAccount>().eq(ComputingAccount::getReferralCode, referralCode));
            // 获取价格配置
            MemberConfig config = JSON.parseObject(redisTemplate.opsForValue().get(Constant.MEMBER_CONFIG),MemberConfig.class);
            if(Objects.isNull(config)){
                 config = memberConfigService.getOne(new LambdaQueryWrapper<>());
            }
            if(Objects.isNull(config)){
                log.error("无法读取会员配置-member_config");
                return R.fail(ResultCode.FAILURE);
            }
            BigDecimal price;
            if(Objects.equals(member.getIsMember(), YesOrNoEnum.YES.getCode())){
                price = new BigDecimal(config.getAiBrokerMsgFee().split(",")[0]);
            }else{
                price = new BigDecimal(config.getAiBrokerMsgFee().split(",")[1]);
            }

            if(computingAccount.getAvailableAmount().compareTo(price) >= 0){
                return R.data(true);
            }
            return R.data(false);
        } catch (Exception e) {
            log.error("AI经纪人算力值校验报错：\n",e);
            return R.fail(ResultCode.FAILURE);
        }
    }

    @Override
    @Transactional
    public R<Boolean> computingAccountAiConsumption(AiConsumptionVO vo) {
        // 根据令牌解析出会员，然后进行扣款消费，生成明细单，消费额从缓存里取
        try{
            // 根据令牌解析出会员，然后判断是否足够支付本次算力消费
            String token = new String(RSACoder.decryptByPrivateKey(Base64.getDecoder().decode(vo.getToken()),config.getServerPrivateKey()));
            String[] tokenStr = token.split(":");
            if(tokenStr.length != 3){
                log.error("令牌解析失败，token:{}",token);
                throw new ServiceException(ResultCode.UN_AUTHORIZED);
            }
            String referralCode = tokenStr[0];
            long expireTime = Long.parseLong(tokenStr[2]);
            if(System.currentTimeMillis() > expireTime){
                log.error("令牌已过期，token:{}",token);
                throw new ServiceException(ResultCode.UN_AUTHORIZED);
            }
            Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, referralCode));
            if (Objects.isNull(member)) {
                // 推荐码下无会员信息
                throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
            }
            // 获取价格配置
            MemberConfig config = JSON.parseObject(redisTemplate.opsForValue().get(Constant.MEMBER_CONFIG),MemberConfig.class);
            if(Objects.isNull(config)){
                config = memberConfigService.getOne(new LambdaQueryWrapper<>());
            }
            if(Objects.isNull(config)){
                log.error("无法读取会员配置-member_config");
                return R.fail(ResultCode.FAILURE);
            }
            ComputingAccountConsumptionVO consumptionVO = getConsumptionVO(member, config, referralCode);
            R<String> res = consumption(consumptionVO);
            return R.data(res.isSuccess());
        } catch (Exception e) {
            log.error("AI经纪人算力值支付报错：\n",e);
            throw new ServiceException(ResultCode.FAILURE);
        }
    }

    private static ComputingAccountConsumptionVO getConsumptionVO(Member member, MemberConfig config, String referralCode) {
        BigDecimal price;
        if(Objects.equals(member.getIsMember(), YesOrNoEnum.YES.getCode())){
            price = new BigDecimal(config.getAiBrokerMsgFee().split(",")[0]);
        }else{
            price = new BigDecimal(config.getAiBrokerMsgFee().split(",")[1]);
        }
        //  进行扣款消费，生成明细单
        ComputingAccountConsumptionVO consumptionVO  = new ComputingAccountConsumptionVO();
        consumptionVO.setAmount(price);
        consumptionVO.setReferralCode(referralCode);
        consumptionVO.setOperationType(ComputingAccountOperationTypeEnum.AI_BROKER_MSG.getCode());
        return consumptionVO;
    }
}
