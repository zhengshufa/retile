package com.ly.member.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.ComputingAccountDTO;
import com.ly.member.entity.VO.*;
import com.ly.member.service.IComputingAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    算力账户相关接口
 */
@RestController
@RequestMapping("computingAccount")
@Schema(description = "算力账户相关接口")
@AllArgsConstructor
public class ComputingAccountController {


    private final IComputingAccountService computingAccountService;

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 算力账户信息查询
     */
    @PostMapping("computingAccount")
    @Operation(summary = "算力账户信息查询")
    public R<ComputingAccountDTO> computingAccountDetail(@RequestBody ComputingAccountVO vo){
        return computingAccountService.computingAccountDetail(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 算力账户列表查询(分页)
     */
    @PostMapping("computingAccountPage")
    @Operation(summary = "算力账户列表查询(分页)")
    public R<Page<ComputingAccountDTO>> computingAccountList(@RequestBody ComputingAccountPageVO vo){
        return computingAccountService.computingAccountList(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/17 16:00
     * @desc: 算力值额度校验(AI经纪人专用)
     */
    @PostMapping("computingAccountCheck")
    @Operation(summary = "算力值额度校验(AI经纪人专用)")
    public R<Boolean> computingAccountCheck(@RequestBody ComputingAccountCheckVO vo){
        return computingAccountService.computingAccountCheck(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/17 16:46
    * @desc: 算力账户消费(AI经纪人专用)
    */

    @PostMapping("computingAccountAiConsumption")
    @Operation(summary = "算力账户消费(AI经纪人专用)")
    public R<Boolean> computingAccountAiConsumption(@RequestBody AiConsumptionVO vo){
        return computingAccountService.computingAccountAiConsumption(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 算力账户消费（AI经纪人，数字主播视频，AI经纪人模型）
     */
    @PostMapping("computingAccountConsumption")
    @Operation(summary = "算力账户消费（AI经纪人，数字主播视频，AI经纪人模型）")
    public R<String> computingAccountConsumption(@RequestBody ComputingAccountConsumptionVO vo){
        return computingAccountService.computingAccountConsumption(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 算力账户新增（充值，任务，课程观看）
     */
    @PostMapping("computingAccountAdd")
    @Operation(summary = "算力账户新增（充值，任务，课程观看）")
    public R<String> computingAccountAdd(@RequestBody ComputingAccountAddVO vo){
        return computingAccountService.computingAccountAdd(vo);
    }

}
