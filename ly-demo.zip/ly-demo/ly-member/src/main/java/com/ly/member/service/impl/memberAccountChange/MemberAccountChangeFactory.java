package com.ly.member.service.impl.memberAccountChange;

import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.exception.PayBusinessException;
import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import static com.ly.domain.api.ResultCode.PARTNER_PAY_WAY_NOT_FIND;

/**
 * @Author sean
 * @Date 2024/12/24 09:38
 * @desc
 */
@Component
@AllArgsConstructor
public class MemberAccountChangeFactory {

    private final ApplicationContext applicationContext;

    public MemberAccountChange creator(MemberAccountChangeEnum changeEnum) {
        return applicationContext.getBean(changeEnum.getClazz());
    }
}
