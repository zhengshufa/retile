package com.ly.member.entity;

import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author sean
 * @since 2024-23-18 13：12：44
 */
@Getter
@Setter
public class Partner extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 合作商/业务线名称
     */
    private String partnerName;

    /**
     * 合作商/业务线编号
     */
    private String partnerCode;

    /**
     * 接入业务的公钥
     */
    private String publicKey;
}
