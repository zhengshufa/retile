package com.ly.member.service.impl;

import com.ly.member.entity.Partner;
import com.ly.member.mapper.PartnerMapper;
import com.ly.member.service.IPartnerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-23-18 13：12：44
 */
@Service
public class PartnerServiceImpl extends ServiceImpl<PartnerMapper, Partner> implements IPartnerService {

}
