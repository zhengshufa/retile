package com.ly.member.constant;

import com.ly.member.service.impl.sharingQualification.SharingQualification;
import com.ly.member.service.impl.sharingQualification.impl.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 分佣订单类型
 */
@Getter
@AllArgsConstructor
public enum BillTypeEnum {

    //会员订阅
    MEMBER(1,"会员订阅", DefaultSharingQualification.class),
    RENEW_MEMBER(2,"会员续费", RenewMemberSharingQualification.class),
    CLASS(3,"知识付费", DefaultSharingQualification.class),
    COMPUTING(4,"充值算力值", DefaultSharingQualification.class),
    TV_ANCHOR(5,"个人直播奖励", TvAnchorSharingQualification.class),
    MENTOR(6,"导师服务奖励", DefaultSharingQualification.class),
    SELL(7,"产品销售奖励", DefaultSharingQualification.class),
    ONLINE_STORE(8,"云连锁店购买", DefaultSharingQualification.class),
    STORE_SELL(9,"云连锁店卖货", StoreSellSharingQualification.class),
//    TIKTOK_ADVERTISEMENT(10,"充值tiktok广告"),
//    SERVICE_MATCHING(11,"服务撮合"),
//    STORE_DISTRIBUTION(12,"店铺分发账号收益"),
    MEMBER_TV_ANCHOR(13,"直播团队奖励", DefaultSharingQualification.class),
    ADDITIONAL_LIVE(14,"额外直播奖励", AdditionalLiveSharingQualification.class),
    OTHER(99,"其他", DefaultSharingQualification.class);
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    final Class<? extends SharingQualification> clazz;


    public static BillTypeEnum fromCode(int code) {
        for (BillTypeEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
