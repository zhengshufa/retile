package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 会员账号表
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Getter
@Setter
@TableName("member_account")
public class MemberAccount extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 会员id
     */
    private Long memberId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 总金额（总佣金）
     */
    private BigDecimal amount;

    /**
     * 可用余额
     */
    private BigDecimal availableAmount;

    /**
     * 已提现金额
     */
    private BigDecimal withdrawalAmount;

    /**
     * 冻结分佣金额
     */
    private BigDecimal freezeAmount;

    /**
     * 提现冻结金额（发起提现的时候使用）
     */
    private BigDecimal withdrawalFreezeAmount;

    /**
     * 不可用金额
     */
    private BigDecimal unavailableAmount;
}
