package com.ly.member.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.ComputingAccountDetailDTO;
import com.ly.member.entity.VO.ComputingAccountDetailPageVO;
import com.ly.member.service.IComputingAccountDetailService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    算力账户详情相关接口
 */
@RestController
@RequestMapping("computingAccountDetail")
@Schema(title = "算力账户详情相关接口")
@AllArgsConstructor
public class ComputingAccountDetailController {

    private final IComputingAccountDetailService computingAccountDetailService;


    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 算力账户明细查询（分页）
     */
    @PostMapping("computingAccountDetailPage")
    @Operation(summary = "算力账户明细查询（分页）")
    public R<Page<ComputingAccountDetailDTO>> computingAccountDetailPage(@RequestBody ComputingAccountDetailPageVO vo){
        return computingAccountDetailService.computingAccountDetailPage(vo);
    }



}
