package com.ly.member.kafka;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * @Author sean
 * @Date 2025/1/3 15:26
 * @desc
 */
@Service
@AllArgsConstructor
@Slf4j
public class KafkaProducerService {

    private final KafkaTemplate<String,String> kafkaTemplate;

    private static final String TOPIC = "memberExpire";

    public void sendMessage(String message,String topic) {
        kafkaTemplate.send(topic, message);
        log.info("Sent message: {}" ,message);
    }
}
