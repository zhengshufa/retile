package com.ly.member.mapper;

import com.ly.member.entity.MemberAccount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 会员账号表 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface MemberAccountMapper extends BaseMapper<MemberAccount> {

    List<MemberAccount> memberExpireAccount(@Param("expireTime") Date expireTime, @Param("limit")Integer limit,@Param("isMember")Integer isMember);

}
