package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 分佣记录
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Getter
@Setter
@TableName("sharing_record")
public class SharingRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 来源方的会员id
     */
    private Long sourceMemberId;

    /**
     * 来源方的推荐码
     */
    private String sourceReferralCode;


    /**
     * 受益方的会员id
     */
    private Long beneficiaryMemberId;

    /**
     * 受益方的推荐码
     */
    private String beneficiaryReferralCode;

    /**
     * 金额
     */
    private BigDecimal amount;

    /**
     * 订单编号（支付单编号）
     */
    private String billNo;

    /**
     * 订单类型
     */
    private Integer billType;
}
