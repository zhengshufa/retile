package com.ly.member.service.impl.memberAccountChange.impl;

import com.ly.constant.Constant;
import com.ly.constant.MemberAccountDetailOperationTypeEnum;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.service.IMemberAccountDetailService;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.impl.memberAccountChange.MemberAccountChange;
import com.ly.utils.OrderNumberUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 09:32
 * @desc 冻结分佣金额（分佣金额增加到冻结分佣金额）
 */
@Service
@AllArgsConstructor
public class FreezeSharing implements MemberAccountChange {

    private final IMemberAccountService memberAccountService;

    private final IMemberAccountDetailService memberAccountDetailService;

    @Override
    public MemberAccountDetail change(MemberAccount memberAccount, BigDecimal amount, BigDecimal oldAmount, MemberAccountDetail oldDetail, String billNo) {
        //  冻结分佣金额（分佣金额增加到冻结分佣金额）
//        memberAccount.setFreezeAmount(amount);
//        memberAccountService.updateById(memberAccount);
//        // 生成操作单号 1条 冻结
//        MemberAccountDetail memberAccountDetail = new MemberAccountDetail();
//        memberAccountDetail.setMemberId(memberAccount.getMemberId());
//        memberAccountDetail.setReferralCode(memberAccount.getReferralCode());
//        memberAccountDetail.setOperationNo(Constant.MEMBER_OPERATOR + OrderNumberUtils.generateOrderNumber());
//        memberAccountDetail.setOperationType(MemberAccountDetailOperationTypeEnum.SHARING.getCode());
//        memberAccountDetail.setAmount(amount);
//        memberAccountDetail.setStatus(MemberAccountChangeEnum.FREEZE_SHARING.getCode());
//        memberAccountDetailService.save(memberAccountDetail);
//        return memberAccountDetail;
        return null;
    }
}
