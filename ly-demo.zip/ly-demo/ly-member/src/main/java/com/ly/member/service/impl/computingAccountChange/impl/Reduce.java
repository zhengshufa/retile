package com.ly.member.service.impl.computingAccountChange.impl;

import com.ly.constant.Constant;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IComputingAccountService;
import com.ly.member.service.impl.computingAccountChange.ComputingAccountChange;
import com.ly.utils.OrderNumberUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 10:16
 * @desc 扣减算力值（支付）
 */
@Service("ComputingAccountReduce")
@AllArgsConstructor
public class Reduce implements ComputingAccountChange {

    private final IComputingAccountDetailService computingAccountDetailService;

    private final IComputingAccountService computingAccountService;

    @Override
    public ComputingAccountDetail change(ComputingAccount computingAccount, BigDecimal amount, BigDecimal oldAmount, ComputingAccountDetail oldDetail,Integer operationType,String remark) {
        if(computingAccount.getAvailableAmount().compareTo(amount) < 0){
            throw new ServiceException(ResultCode.ACCOUNT_NOT_ENOUGH);
        }
        computingAccount.setAvailableAmount(computingAccount.getAvailableAmount().subtract(amount));
        computingAccountService.updateById(computingAccount);

        ComputingAccountDetail computingAccountDetail = new ComputingAccountDetail();
        computingAccountDetail.setMemberId(computingAccount.getMemberId());
        computingAccountDetail.setReferralCode(computingAccount.getReferralCode());
        computingAccountDetail.setOperationNo(Constant.COMPUTING_OPERATOR + OrderNumberUtils.generateOrderNumber());
        computingAccountDetail.setOperationType(operationType);
        computingAccountDetail.setAmount(amount);
        computingAccountDetail.setPayAmount(amount);
        computingAccountDetail.setStatus(ComputingAccountChangeEnum.REDUCE.getCode());
        computingAccountDetailService.save(computingAccountDetail);
        return computingAccountDetail;

    }
}
