package com.ly.member.mapstruct;


import com.ly.mapstruct.BaseMapStruct;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.VO.ComputingAccountAddVO;
import org.mapstruct.Mapper;

/**
 * @Author sean
 * @Date 2024/12/17 11:05
 * @desc
 */
@Mapper(componentModel = "spring")
public interface ComputingAccountAddVOMapStruct extends BaseMapStruct<ComputingAccountDetail, ComputingAccountAddVO> {

}
