package com.ly.member.service;

/**
 * packageName.className com.ly.pay.service.AuthService
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 9:57
 * @description
 */
public interface IAuthService {


    /**
     * 签名
     * @param inputStr
     * @return
     * @throws Exception
     */
    String vstEncode(String inputStr) throws Exception ;

    /**
     * 验证签名
     * @param sign
     * @param jsonStr
     * @return
     * @throws Exception
     */
    Boolean verifyAndDecode(String headerId,String sign,String jsonStr) throws Exception;
}