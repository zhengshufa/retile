package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.domain.api.R;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.DTO.ComputingAccountDTO;
import com.ly.member.entity.VO.*;

import java.math.BigDecimal;

/**
 * <p>
 * 算力账号表 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface IComputingAccountService extends IService<ComputingAccount> {

    R<ComputingAccountDTO> computingAccountDetail(ComputingAccountVO vo);

    R<String> computingAccountConsumption(ComputingAccountConsumptionVO vo);

    R<String> consumption(ComputingAccountConsumptionVO vo);

    R<String> computingAccountAdd(ComputingAccountAddVO vo);

    R<Page<ComputingAccountDTO>> computingAccountList(ComputingAccountPageVO vo);

    ComputingAccountDetail computingAccountChange(Long memberId, BigDecimal amount, BigDecimal oldAmount,ComputingAccountChangeEnum computingAccountChangeEnum,ComputingAccountDetail oldDetail,Integer operationType,String remark);

    R<Boolean> computingAccountCheck(ComputingAccountCheckVO vo);

    R<Boolean> computingAccountAiConsumption(AiConsumptionVO vo);

}
