package com.ly.member.service.impl.memberAccountChange.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.ly.constant.Constant;
import com.ly.constant.MemberAccountDetailOperationTypeEnum;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.service.IMemberAccountDetailService;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.impl.memberAccountChange.MemberAccountChange;
import com.ly.utils.OrderNumberUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/24 09:32
 * @desc 解除冻结的分佣金额（会员在会员过期时限内续费，则解除冻结的分佣金额，增加账号余额）
 */
@Service
@AllArgsConstructor
public class ThawFreezeSharing implements MemberAccountChange {

    private final IMemberAccountService memberAccountService;

    private final IMemberAccountDetailService memberAccountDetailService;

    @Override
    public MemberAccountDetail change(MemberAccount memberAccount, BigDecimal amount, BigDecimal oldAmount, MemberAccountDetail oldDetail, String billNo) {
        // 解除冻结的分佣金额（会员在会员过期时限内续费，则解除冻结的分佣金额，增加账号余额）
//        memberAccount.setAvailableAmount(memberAccount.getAvailableAmount().add(memberAccount.getFreezeAmount()));
//        memberAccount.setFreezeAmount(BigDecimal.ZERO);
//        memberAccountService.updateById(memberAccount);
//        //  更新该会员下的所有操作单---解冻
//        LambdaUpdateWrapper<MemberAccountDetail> lq = new LambdaUpdateWrapper<>();
//        lq.eq(MemberAccountDetail::getOperationType, MemberAccountDetailOperationTypeEnum.SHARING.getCode());
//        lq.eq(MemberAccountDetail::getStatus,MemberAccountChangeEnum.FREEZE_SHARING.getCode());
//        lq.eq(MemberAccountDetail::getMemberId,memberAccount.getMemberId());
//        lq.set(MemberAccountDetail::getStatus,MemberAccountChangeEnum.THAW_FREEZE_SHARING.getCode());
//        memberAccountDetailService.update(lq);
        return null;
    }
}
