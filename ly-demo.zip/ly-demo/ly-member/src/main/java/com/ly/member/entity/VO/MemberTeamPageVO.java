package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  获取团队信息VO
 */
@Schema (description = "获取团队信息VO")
@Data
public class MemberTeamPageVO {

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "查询类型（0-所有1代数据, 1-本周邀请的1代数据,2-专属推荐码）")
    private Integer type;

    @Schema(description = "一代推荐码")
    private String childReferralCode;

    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;

}
