package com.ly.member.service.impl.memberAccountChange;

import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 09:31
 * @desc
 */
public interface MemberAccountChange {

    MemberAccountDetail change(MemberAccount memberAccount, BigDecimal amount, BigDecimal oldAmount, MemberAccountDetail oldDetail, String billNo);
}
