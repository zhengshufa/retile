package com.ly.member.service.impl.sharingQualification;

import com.ly.member.entity.MemberConfig;
import com.ly.member.entity.SyncOrder;

import java.util.List;

/**
 * @Author sean
 * @Date 2025/1/10 17:19
 * @desc
 */
public interface SharingQualification {

    void sharing(SyncOrder syncOrder);
}
