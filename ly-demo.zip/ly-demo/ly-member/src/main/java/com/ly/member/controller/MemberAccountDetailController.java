package com.ly.member.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberAccountDetailDTO;
import com.ly.member.entity.VO.MemberAccountDetailPageVO;
import com.ly.member.service.IMemberAccountDetailService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    会员账户详情相关接口
 */
@RestController
@RequestMapping("memberAccountDetail")
@Schema(title = "会员账户详情相关接口")
@AllArgsConstructor
public class MemberAccountDetailController {

    private final IMemberAccountDetailService memberAccountDetailService;

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员账户明细查询(分页)
     */
    @PostMapping("memberAccountDetailPage")
    @Operation(summary = "会员账户明细查询（分页）")
    public R<Page<MemberAccountDetailDTO>> memberAccountDetailPage(@RequestBody MemberAccountDetailPageVO vo){
        return memberAccountDetailService.memberAccountDetailPage(vo);
    }

}
