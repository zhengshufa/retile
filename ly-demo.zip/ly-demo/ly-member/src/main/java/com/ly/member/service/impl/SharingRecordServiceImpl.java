package com.ly.member.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.SharingRecordStatusEnum;
import com.ly.constant.YesOrNoEnum;
import com.ly.domain.api.R;
import com.ly.member.constant.BillTypeEnum;
import com.ly.member.entity.DTO.*;
import com.ly.member.entity.Member;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.SharingRecord;
import com.ly.member.entity.VO.*;
import com.ly.member.mapper.SharingRecordMapper;
import com.ly.member.mapstruct.MemberIncomeDetailDTOMapStruct;
import com.ly.member.mapstruct.SharingRecordDetailDTOMapStruct;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.IMemberService;
import com.ly.member.service.ISharingRecordService;
import com.ly.utils.PageBeanUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.BiConsumer;

/**
 * <p>
 * 分佣记录 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
public class SharingRecordServiceImpl extends ServiceImpl<SharingRecordMapper, SharingRecord> implements ISharingRecordService {

    private final IMemberAccountService memberAccountService;

    private final MemberIncomeDetailDTOMapStruct memberIncomeDetailDTOMapStruct;

    private final SharingRecordDetailDTOMapStruct sharingRecordDetailDTOMapStruct;

    private final IMemberService memberService;

    @Override
    public R<MemberIncomeDTO> memberIncome(MemberIncomeVO vo) {
        // 会员收益（分佣）
        MemberAccount memberAccount = memberAccountService.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(memberAccount)) {
            return R.data(null);
        }
        MemberIncomeDTO memberIncomeDTO = new MemberIncomeDTO();
        memberIncomeDTO.setUserId(vo.getUserId());
        memberIncomeDTO.setReferralCode(vo.getReferralCode());
        memberIncomeDTO.setAmount(memberAccount.getAmount());
        memberIncomeDTO.setAvailableAmount(memberAccount.getAvailableAmount());
        //周数据
        QueryWrapper<SharingRecord> queryWrapper = Wrappers.query();
        queryWrapper.eq("beneficiary_member_id", memberAccount.getMemberId())
                .eq("status", SharingRecordStatusEnum.YES.getCode())
                .ge("update_time", DateUtil.beginOfWeek(new Date()))
                .select("sum(amount) as amount")
                .groupBy("beneficiary_member_id");
        SharingRecord week = this.getOne(queryWrapper);
        //月数据
        queryWrapper.clear();
        queryWrapper.eq("beneficiary_member_id", memberAccount.getMemberId())
                .eq("status", SharingRecordStatusEnum.YES.getCode())
                .ge("update_time", DateUtil.beginOfMonth(new Date()))
                .select("sum(amount) as amount")
                .groupBy("beneficiary_member_id");
        SharingRecord month = this.getOne(queryWrapper);
        memberIncomeDTO.setWeekAmount(Objects.nonNull(week) ? week.getAmount() : BigDecimal.ZERO);
        memberIncomeDTO.setMonthAmount(Objects.nonNull(week) ? month.getAmount() : BigDecimal.ZERO);
        return R.data(memberIncomeDTO);
    }

    @Override
    public R<List<MemberIncomeDetailDTO>> memberIncomeDetailList(MemberIncomeDetailVO vo) {
        QueryWrapper<SharingRecord> queryWrapper = Wrappers.query();
        switch (vo.getType()) {
            //本周
            case 1:
                queryWrapper.ge("update_time", DateUtil.beginOfWeek(new Date()));
                break;
            //本月
            case 2:
                queryWrapper.ge("update_time", DateUtil.beginOfMonth(new Date()));
                break;
            //本年
            case 3:
                queryWrapper.ge("update_time", DateUtil.beginOfYear(new Date()));
                break;
            //全部
            case 4:
                break;
            default:
                break;
        }
        queryWrapper.eq("beneficiary_referral_code", vo.getReferralCode())
                .eq("status", SharingRecordStatusEnum.YES.getCode())
                .select("sum(amount) as amount,bill_type")
                .groupBy("beneficiary_member_id", "bill_type");
        List<SharingRecord> recordList = this.list(queryWrapper);
        return R.data(memberIncomeDetailDTOMapStruct.toDtoList(recordList));
    }

    @Override
    public R<Page<SharingRecordDetailDTO>> sharingRecordDetailPage(SharingRecordDetailVO vo) {
        LambdaQueryWrapper<SharingRecord> lw = new LambdaQueryWrapper<>();
        lw.eq(SharingRecord::getBeneficiaryReferralCode, vo.getReferralCode());
//        lw.eq(SharingRecord::getStatus, SharingRecordStatusEnum.YES.getCode());
        lw.eq(Objects.nonNull(vo.getBillType()), SharingRecord::getBillType, vo.getBillType());
        if (Objects.nonNull(vo.getStartTime()) && Objects.nonNull(vo.getEndTime())) {
            lw.ge(SharingRecord::getCreateTime, vo.getStartTime());
            lw.le(SharingRecord::getCreateTime, vo.getEndTime());
        }
        Page<SharingRecord> sharingRecordPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lw);
        return R.data(PageBeanUtils.copyProperties(sharingRecordPage, sharingRecordDetailDTOMapStruct));
    }


    @Override
    public R<Page<MemberTotalIncomeDTO>> memberTotalIncome(MemberTotalIncomeVO vo) {
        // 先分页出10条数据
        LambdaQueryWrapper<Member> lq = new LambdaQueryWrapper<>();
        lq.eq(Objects.nonNull(vo.getReferralCode()), Member::getReferralCode, vo.getReferralCode());
        lq.eq(Objects.nonNull(vo.getEmail()), Member::getEmail, vo.getEmail());
        lq.eq(Objects.nonNull(vo.getOpenType()), Member::getOpenType, vo.getOpenType());
        lq.eq(Objects.nonNull(vo.getReferralType()), Member::getReferralType, vo.getReferralType());
        lq.orderByDesc(Member::getId);  // 按id 降序排序
        Page<Member> mamberPage = memberService.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lq);
        Page<MemberTotalIncomeDTO> page = new Page<>();
        page.setCurrent(mamberPage.getCurrent());
        page.setSize(mamberPage.getSize());
        page.setTotal(mamberPage.getTotal());
        List<MemberTotalIncomeDTO> list = mamberPage.getRecords().stream().map(this::total).toList();
        page.setRecords(list);
        return R.data(page);
    }

    MemberTotalIncomeDTO total(Member member) {
        MemberTotalIncomeDTO memberTotalIncomeDTO = new MemberTotalIncomeDTO();
        memberTotalIncomeDTO.setReferralCode(member.getReferralCode());
        //查询所属的数据 根据订单类型,分佣状态分组
        LambdaQueryWrapper<SharingRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(SharingRecord::getBeneficiaryReferralCode, member.getReferralCode());
        queryWrapper.groupBy(SharingRecord::getBillType, SharingRecord::getStatus);
        List<SharingRecord> recordList = this.list(queryWrapper);
        recordList.forEach(record -> {
            BillTypeEnum billTypeEnum = BillTypeEnum.fromCode(record.getBillType());
            if (Objects.isNull(billTypeEnum)) {
                return;
            }
            Map<BillTypeEnum, BiConsumer<MemberTotalIncomeDTO, BigDecimal>> handlers = createBillTypeHandlers();
            if (Objects.equals(record.getStatus(), YesOrNoEnum.YES.getCode())) {
                memberTotalIncomeDTO.setSharingAmount(memberTotalIncomeDTO.getSharingAmount().add(record.getAmount()));
                handlers.get(billTypeEnum).accept(memberTotalIncomeDTO, record.getAmount());
            } else {
                memberTotalIncomeDTO.setNonSharingAmount(memberTotalIncomeDTO.getNonSharingAmount().add(record.getAmount()));
            }
        });
        return memberTotalIncomeDTO;
    }

    private Map<BillTypeEnum, BiConsumer<MemberTotalIncomeDTO, BigDecimal>> createBillTypeHandlers() {
        Map<BillTypeEnum, BiConsumer<MemberTotalIncomeDTO, BigDecimal>> handlers = new HashMap<>(15);
        handlers.put(BillTypeEnum.MEMBER, (dto, amount) -> dto.setMemberSharingAmount(dto.getMemberSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.RENEW_MEMBER, (dto, amount) -> dto.setRenewMemberSharingAmount(dto.getRenewMemberSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.CLASS, (dto, amount) -> dto.setClassSharingAmount(dto.getClassSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.COMPUTING, (dto, amount) -> dto.setComputingSharingAmount(dto.getComputingSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.TV_ANCHOR, (dto, amount) -> dto.setTvAnchorSharingAmount(dto.getTvAnchorSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.MENTOR, (dto, amount) -> dto.setMentorSharingAmount(dto.getMentorSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.SELL, (dto, amount) -> dto.setSellSharingAmount(dto.getSellSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.STORE_SELL, (dto, amount) -> dto.setStoreSellSharingAmount(dto.getStoreSellSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.ONLINE_STORE, (dto, amount) -> dto.setOnlineStoreSharingAmount(dto.getOnlineStoreSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.MEMBER_TV_ANCHOR, (dto, amount) -> dto.setMemberTvAnchorSharingAmount(dto.getMemberTvAnchorSharingAmount().add(amount)));
        handlers.put(BillTypeEnum.ADDITIONAL_LIVE, (dto, amount) -> dto.setAdditionalLiveSharingAmount(dto.getAdditionalLiveSharingAmount().add(amount)));
        return handlers;
    }


    @Override
    public R<Page<MemberTotalByTypeIncomeDTO>> memberTotalByTypeIncome(MemberTotalByTypeIncomeVO vo) {
        LambdaQueryWrapper<Member> lq = new LambdaQueryWrapper<>();
        lq.eq(Objects.nonNull(vo.getReferralCode()), Member::getReferralCode, vo.getReferralCode());
        lq.eq(Objects.nonNull(vo.getEmail()), Member::getEmail, vo.getEmail());
        lq.orderByDesc(Member::getId);  // 按id 降序排序
        Page<Member> mamberPage = memberService.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lq);
        Page<MemberTotalByTypeIncomeDTO> page = new Page<>();
        page.setCurrent(mamberPage.getCurrent());
        page.setSize(mamberPage.getSize());
        page.setTotal(mamberPage.getTotal());
        List<MemberTotalByTypeIncomeDTO> list = mamberPage.getRecords().stream().map(item->{
            MemberTotalByTypeIncomeDTO memberTotalByTypeIncomeDTO = new MemberTotalByTypeIncomeDTO();
            memberTotalByTypeIncomeDTO.setReferralCode(item.getReferralCode());
            memberTotalByTypeIncomeDTO.setBillType(vo.getBillType());
            //查询所属的数据 根据分佣状态分组
            QueryWrapper<SharingRecord> queryWrapper = new QueryWrapper<>();
            queryWrapper.select("status", "sum(amount) as amount") // 聚合函数
                        .eq("beneficiary_referral_code", item.getReferralCode())
                        .eq("bill_type", vo.getBillType())
                        .groupBy("status"); // 按 status 字段分组
            List<SharingRecord> recordList = this.list(queryWrapper);
            recordList.forEach(record -> {
                if (Objects.equals(record.getStatus(), YesOrNoEnum.YES.getCode())) {
                    memberTotalByTypeIncomeDTO.setSharingAmount(memberTotalByTypeIncomeDTO.getSharingAmount().add(record.getAmount()));
                } else {
                    memberTotalByTypeIncomeDTO.setNonSharingAmount(memberTotalByTypeIncomeDTO.getNonSharingAmount().add(record.getAmount()));
                }
            });
        return memberTotalByTypeIncomeDTO;
        }).toList();
        page.setRecords(list);
        return R.data(page);
    }

    @Override
    public R<Page<SharingRecordDetailDTO>> recordDetailPage(RecordDetailVO vo) {
        LambdaQueryWrapper<SharingRecord> lw = new LambdaQueryWrapper<>();
        lw.eq(SharingRecord::getBeneficiaryReferralCode, vo.getReferralCode());
        lw.eq(Objects.nonNull(vo.getStatus()), SharingRecord::getStatus, vo.getStatus());
        lw.eq(Objects.nonNull(vo.getBillType()), SharingRecord::getBillType, vo.getBillType());
        lw.ge(Objects.nonNull(vo.getCreateStartTime()),SharingRecord::getCreateTime, vo.getCreateStartTime());
        lw.le(Objects.nonNull(vo.getCreateEndTime()),SharingRecord::getCreateTime, vo.getCreateEndTime());
        if (Objects.nonNull(vo.getUpdateStartTime()) || Objects.nonNull(vo.getUpdateEndTime())) {
            lw.ge(Objects.nonNull(vo.getUpdateStartTime()),SharingRecord::getUpdateTime, vo.getUpdateStartTime());
            lw.le(Objects.nonNull(vo.getUpdateEndTime()),SharingRecord::getUpdateTime, vo.getUpdateEndTime());
            lw.eq(SharingRecord::getStatus, YesOrNoEnum.YES.getCode());
        }
        Page<SharingRecord> sharingRecordPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lw);
        return R.data(PageBeanUtils.copyProperties(sharingRecordPage, sharingRecordDetailDTOMapStruct));
    }
}
