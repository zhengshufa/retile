package com.ly.member.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.*;
import com.ly.member.entity.VO.*;
import com.ly.member.service.ISharingRecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    会员分佣相关接口
 */
@RestController
@RequestMapping("sharingRecord")
@Schema(title = "会员分佣相关接口")
@AllArgsConstructor
public class SharingRecordController {

    private final ISharingRecordService sharingRecordService;



    /**
     * @author: sean
     * @date: 2024/12/12 17:00
     * @desc: 会员收益（分佣）
     */
    @PostMapping("memberIncome")
    @Operation(summary = "会员收益（分佣）")
    public R<MemberIncomeDTO> memberIncome(@RequestBody MemberIncomeVO vo){
        return sharingRecordService.memberIncome(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 17:02
     * @desc: 会员收益明细（分佣）
     */
    @PostMapping("memberIncomeDetailList")
    @Operation(summary = "会员收益明细（分佣）")
    public R<List<MemberIncomeDetailDTO>> memberIncomeDetailList(@RequestBody MemberIncomeDetailVO vo){
        return sharingRecordService.memberIncomeDetailList(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 17:02
     * @desc: 分佣明细列表
     */
    @PostMapping("sharingRecordDetailPage")
    @Operation(summary = "分佣明细列表（分页）")
    public R<Page<SharingRecordDetailDTO>> sharingRecordDetailPage(@RequestBody SharingRecordDetailVO vo){
        return sharingRecordService.sharingRecordDetailPage(vo);
    }


    /**
     * @author: sean
     * @date: 2024/12/12 17:02
     * @desc: 分佣明细列表(后台)
     */
    @PostMapping("recordDetailPage")
    @Operation(summary = "分佣明细列表(后台)（分页）")
    public R<Page<SharingRecordDetailDTO>> recordDetailPage(@RequestBody RecordDetailVO vo){
        return sharingRecordService.recordDetailPage(vo);
    }


    /**
    * @author: sean
    * @date: 2025/1/3 11:02
    * @desc: 会员总收益（后台）
    */
    @PostMapping("memberTotalIncome")
    @Operation(summary = "会员总收益（后台）")
    public R<Page<MemberTotalIncomeDTO>> memberTotalIncome(@RequestBody MemberTotalIncomeVO vo){
        return sharingRecordService.memberTotalIncome(vo);
    }


    /**
     * @author: sean
     * @date: 2025/1/3 11:02
     * @desc: 会员收益-对应类型（后台）
     */
    @PostMapping("memberTotalByTypeIncome")
    @Operation(summary = "会员收益-对应类型（后台）")
    public R<Page<MemberTotalByTypeIncomeDTO>> memberTotalByTypeIncome(@RequestBody MemberTotalByTypeIncomeVO vo){
        return sharingRecordService.memberTotalByTypeIncome(vo);
    }

}
