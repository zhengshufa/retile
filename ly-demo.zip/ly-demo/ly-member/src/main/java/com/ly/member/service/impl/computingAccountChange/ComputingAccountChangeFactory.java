package com.ly.member.service.impl.computingAccountChange;

import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.service.impl.memberAccountChange.MemberAccountChange;
import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * @Author sean
 * @Date 2024/12/24 09:38
 * @desc
 */
@Component
@AllArgsConstructor
public class ComputingAccountChangeFactory {

    private final ApplicationContext applicationContext;

    public ComputingAccountChange creator(ComputingAccountChangeEnum changeEnum) {
        return applicationContext.getBean(changeEnum.getClazz());
    }
}
