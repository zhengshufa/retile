package com.ly.member.mapper;

import com.ly.member.entity.Partner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-23-18 13：12：44
 */
public interface PartnerMapper extends BaseMapper<Partner> {

}
