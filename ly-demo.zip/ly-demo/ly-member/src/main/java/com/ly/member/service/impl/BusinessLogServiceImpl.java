package com.ly.member.service.impl;

import cn.hutool.core.date.DateUtil;
import com.ly.member.entity.BusinessLog;
import com.ly.member.mapper.BusinessLogMapper;
import com.ly.member.service.IBusinessLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.utils.CustomHttpResponseWrapper;
import com.ly.utils.ThreadPoolExecutorFactory;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * <p>
 * 第三方请求和业务处理日志表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-12-28 10:13:20
 */
@Service("iBusinessLogService")
public class BusinessLogServiceImpl extends ServiceImpl<BusinessLogMapper, BusinessLog> implements IBusinessLogService {

    ThreadPoolExecutor threadPoolExecutor = ThreadPoolExecutorFactory.threadPoolExecutorFactory("businessLog");


    @Override
    public void saveLogAsync(BusinessLog businessLog) {
        threadPoolExecutor.execute(() -> {
            try{
                businessLog.setProcessEndTime(new Date());
                businessLog.setElapsedTimeMs(DateUtil.betweenMs(businessLog.getProcessStartTime(),businessLog.getProcessEndTime()));
                this.save(businessLog);
            } catch (Exception e) {
                log.error("存储日志失败:",e);
            }
        });
    }
}
