package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户信息VO
 */

@Schema(description = "会员账户信息VO")
@Data
public class MemberAccountVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;
}
