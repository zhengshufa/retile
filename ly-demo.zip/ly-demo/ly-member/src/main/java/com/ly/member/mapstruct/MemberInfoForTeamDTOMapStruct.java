package com.ly.member.mapstruct;


import com.ly.mapstruct.BaseMapStruct;
import com.ly.member.entity.DTO.MemberInfoForTeamDTO;
import com.ly.member.entity.Member;
import org.mapstruct.Mapper;

/**
 * @Author sean
 * @Date 2024/12/17 11:05
 * @desc
 */
@Mapper(componentModel = "spring")
public interface MemberInfoForTeamDTOMapStruct extends BaseMapStruct<Member, MemberInfoForTeamDTO> {

}
