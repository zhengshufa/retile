package com.ly.member.entity.VO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益明细VO
 */

@Schema(description = "会员收益明细VO")
@Data
public class RecordDetailVO {

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "状态（0-未分佣，1-已分佣）,不传查全部")
    private Integer status;

    @Schema(description = "订单起始时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createStartTime;

    @Schema(description = "订单结束时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createEndTime;

    @Schema(description = "分佣起始时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date updateStartTime;

    @Schema(description = "分佣结束时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date updateEndTime;

    @Schema(description = "订单类型,不传查全部")
    private Integer billType;

    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;

}
