package com.ly.member.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.Constant;
import com.ly.constant.MemberStatusEnum;
import com.ly.constant.ReferralTypeEnum;
import com.ly.constant.YesOrNoEnum;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.entity.*;
import com.ly.member.entity.DTO.MemberInfoDTO;
import com.ly.member.entity.DTO.MemberInfoForTeamDTO;
import com.ly.member.entity.DTO.MemberMyTeamDTO;
import com.ly.member.entity.DTO.MemberTransferInfoDTO;
import com.ly.member.entity.VO.*;
import com.ly.member.mapper.ComputingAccountMapper;
import com.ly.member.mapper.MemberMapper;
import com.ly.member.mapper.TeamCountMapper;
import com.ly.member.mapstruct.MemberInfoDTOMapStruct;
import com.ly.member.mapstruct.MemberInfoForTeamDTOMapStruct;
import com.ly.member.mapstruct.MemberTransferInfoDTOMapStruct;
import com.ly.member.service.*;
import com.ly.utils.PageBeanUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
public class MemberServiceImpl extends ServiceImpl<MemberMapper, Member> implements IMemberService {

    private final MemberInfoDTOMapStruct memberInfoDTOMapstruct;

    private final MemberTransferInfoDTOMapStruct memberTransferInfoDTOMapstruct;

    private final MemberInfoForTeamDTOMapStruct memberInfoForTeamDTOMapStruct;

    private final ITeamCountService teamCountService;

    private final TeamCountMapper teamCountMapper;

    private final ITeamInviteCountService teamInviteCountService;

    private final IMemberAccountService memberAccountService;

    private final ComputingAccountMapper computingAccountMapper;

    private final IReferralCodeService referralCodeService;


    @Override
    @Transactional
    public R<String> memberRegister(MemberRegisterVO vo) {
        if(Objects.isNull(vo.getUserId())){
            return R.fail(ResultCode.PARAM_MISS);
        }

        if(Objects.isNull(vo.getReferralCode())){
            return R.fail(ResultCode.PARAM_MISS);
        }

        // 判断邮箱是否重复
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getEmail, vo.getEmail()).last("limit 1"));
        if(Objects.nonNull(member)){
            if(Objects.nonNull(member.getUserId())){
                return R.fail(ResultCode.EMAIL_EXIST);
            }else{
                // 判断该邮箱是否有一个未绑定的会员存在，若存在，则更新用户数据
                member.setUserId(vo.getUserId());
                this.updateById(member);
                return R.data(member.getReferralCode());
            }
        }
        // 会员注册接口 生成本人推荐码
        member = new Member();
        member.setEmail(vo.getEmail());
        member.setUserId(vo.getUserId());
        member.setNickname(vo.getNickname());
        member.setCountry(vo.getCountry());
        // 查询上级id
        Member parentMember = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(parentMember)){
            return R.fail(ResultCode.REFERRAL_NOT_EXIST);
        }
        if(Objects.equals(parentMember.getIsMember(), YesOrNoEnum.NO.getCode()) && !Objects.equals(vo.getReferralCode(), String.valueOf(Constant.COMPANY_REFERRED_CODE))){
            return R.fail(ResultCode.REFERRAL_CODE_NOT_MEMBER);
        }
        member.setReferralId(parentMember.getId());
        // 生成推荐码
        //判断上级是否是合作客户的推荐码，即推荐码是否纯数字，如果不是纯数字，则需要在生成的推荐码上加上国别
        String country = null;
        if(!parentMember.getReferralCode().matches("\\d+")){
            country = member.getCountry();
        }
        String referralCode = referralCodeService.referralCodeInit(country);
        //校验推荐码是否重复
        while (checkReferralCodeExist(referralCode)){
            referralCode = referralCodeService.referralCodeInit(country);
        }

        // 调用合作客户的接口,注册用户
        if(!referralCodeService.registerV(vo,referralCode)){
            throw new ServiceException(ResultCode.PARTNER_PAY_REGISTER_ERROR);
        }

        member.setReferralCode(referralCode);
        member.setReferralType(ReferralTypeEnum.NORMAL.getCode());
        this.save(member);
        // 新增会员账号和算力值账号
        createMemberAccount(member);

        // 团队人数新增
        try{
            teamInviteCountService.registerTeamInviteCount(member);
        } catch (Exception e) {
            log.error("团队人数新增失败！！！");
        }
        return R.data(member.getReferralCode());
    }

    boolean checkReferralCodeExist(String referralCode){
        return this.count(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, referralCode)) > 0;
    }

    @Override
    public R<String> memberSync(MemberSyncVO vo) {
        if(Objects.isNull(vo.getReferralCode())){
            return R.fail(ResultCode.PARAM_MISS);
        }
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Objects.nonNull(vo.getEmail()),Member::getEmail, vo.getEmail()).last("limit 1"));
        if(Objects.nonNull(member) && !Objects.equals(member.getReferralCode(),vo.getReferralCode())){
            return R.fail(ResultCode.EMAIL_EXIST);
        }
        member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(member)){
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }

        LambdaUpdateWrapper<Member> lu = new LambdaUpdateWrapper<>();
        lu.set(Objects.nonNull(vo.getNickname()),Member::getNickname,vo.getNickname());
        lu.set(Objects.nonNull(vo.getAnchorAuth()),Member::getAnchorAuth,vo.getNickname());
        lu.set(Objects.nonNull(vo.getEmail()),Member::getEmail,vo.getEmail());
        lu.set(Objects.nonNull(vo.getTenGenerations()),Member::getTenGenerations,vo.getTenGenerations());
        lu.eq(Member::getId,member.getId());
        this.update(lu);
        return R.data(member.getReferralCode());
    }


    @Override
    @Transactional
    public R<String> memberImport(MemberImportVO vo) {
        if(Objects.isNull(vo.getUserId())){
            return R.fail(ResultCode.PARAM_MISS);
        }
        if(Objects.isNull(vo.getReferralCode())){
            return R.fail(ResultCode.PARAM_MISS);
        }
        // 判断邮箱是否重复
//        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getEmail, vo.getEmail()).last("limit 1"));
//        if(Objects.nonNull(member)){
//            return R.fail(ResultCode.EMAIL_EXIST);
//        }
        // 会员注册接口 生成本人推荐码
        Member member = new Member();
        member.setEmail("");
        member.setUserId(vo.getUserId());
        member.setNickname(vo.getNickname());
        member.setCountry(vo.getCountry());
        // 查询上级id
        Member parentMember = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getRecommendCode()));
        if(Objects.isNull(parentMember)){
            return R.fail(ResultCode.REFERRAL_NOT_EXIST);
        }
        member.setReferralId(parentMember.getId());
        //校验推荐码是否重复
        if (checkReferralCodeExist(vo.getReferralCode())){
            return R.fail(ResultCode.MEMBER_EXIST);
        }
        member.setReferralCode(vo.getReferralCode());
        member.setReferralType(ReferralTypeEnum.NORMAL.getCode());
        member.setTenGenerations(YesOrNoEnum.YES.getCode());
        this.save(member);
        // 新增会员账号和算力值账号
        createMemberAccount(member);
        // 团队人数新增
        try{
            teamInviteCountService.registerTeamInviteCount(member);
        } catch (Exception e) {
            log.error("团队人数新增失败！！！");
        }
        return R.data(member.getReferralCode());
    }

    @Override
    public R<Page<MemberInfoDTO>> memberPage(MemberPageVO vo) {
        Page<Member> memberPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), new LambdaQueryWrapper<>());
        Page<MemberInfoDTO> page = PageBeanUtils.copyProperties(memberPage, memberInfoDTOMapstruct);
        return R.data(page);
    }

    @Override
    public R<MemberInfoDTO> memberInfo(MemberInfoVO vo) {
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Objects.nonNull(vo.getReferralCode()),Member::getReferralCode, vo.getReferralCode())
                .eq(Objects.nonNull(vo.getUserId()),Member::getUserId, vo.getUserId()));
        if(Objects.isNull(member)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        return R.data(memberInfoDTOMapstruct.toDto(member));
    }


    @Override
    public R<MemberTransferInfoDTO> transferInfo(MemberTransferInfoVO vo) {
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getEmail, vo.getEmail()).last("limit 1"));
        if(Objects.isNull(member)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        return R.data(memberTransferInfoDTOMapstruct.toDto(member));
    }

    @Override
    public R<String> referralChange(ReferralChangeVO vo) {
        //todo 改网：更改推荐人，存记录
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode,vo.getReferralCode()));
        if(Objects.isNull(member)){
            // 会员不存在
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        Member parentMember = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getRecommendCode()));
        if(Objects.isNull(parentMember)){
            // 推荐人不存在
            return R.fail(ResultCode.REFERRAL_NOT_EXIST);
        }
        member.setReferralId(parentMember.getId());
        this.update(new LambdaUpdateWrapper<Member>().eq(Member::getId,member.getId()).set(Member::getReferralId,parentMember.getId()));
        //todo 修改本周邀请和团队数量
        return R.success("操作成功");
    }

    @Override
    public R<Page<MemberInfoForTeamDTO>> getTeamInfoPage(MemberTeamPageVO vo) {
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode,vo.getReferralCode()));
        if(Objects.isNull(member)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        LambdaQueryWrapper<Member> lq = new LambdaQueryWrapper<>();
        lq.eq(Member::getReferralId, member.getId());
        lq.eq(Objects.nonNull(vo.getChildReferralCode()), Member::getReferralCode, vo.getChildReferralCode());
        switch (vo.getType()){
            // 0-所有1代数据
            case 0:
                break;
            // 1-本周邀请的1代数据 不包括特殊推荐码
            case 1:
                lq.ge(Member::getCreateTime,DateUtil.beginOfWeek(new Date()));
                lq.ne(Member::getReferralType,ReferralTypeEnum.SPECIAL.getCode());
                break;
            // 2-专属推荐码
            case 2:
                lq.and(w -> w.eq(Member::getReferralType, ReferralTypeEnum.SPECIAL.getCode())
                        .or()
                        .isNotNull(Member::getTransferMark));
                break;
            default:
                break;
        }
        Page<Member> memberPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lq);
        Page<MemberInfoForTeamDTO> page = PageBeanUtils.copyProperties(memberPage, memberInfoForTeamDTOMapStruct);
        page.getRecords().forEach(item -> {
           if(this.count(new LambdaQueryWrapper<Member>().eq(Member::getReferralId, item.getId())) > 0){
                item.setHasChild(YesOrNoEnum.YES.getCode());
           }else{
               item.setHasChild(YesOrNoEnum.NO.getCode());
           }
        });
        return R.data(page);
    }

    @Override
    public R<MemberMyTeamDTO> getMyTeamInfo(MemberMyTeamVO vo) {
        // 获取我的团队数量
        TeamCount teamCount = teamCountService.getById(vo.getReferralCode());
        // 获取本周邀请数量
        LambdaQueryWrapper<TeamInviteCount> lq = new LambdaQueryWrapper<>();
        lq.eq(TeamInviteCount::getReferralCode, vo.getReferralCode());
        lq.ge(TeamInviteCount::getCreateTime, DateUtil.beginOfWeek(new Date()));
        List<TeamInviteCount> teamInviteCountList = teamInviteCountService.list(lq);
        MemberMyTeamDTO dto = new MemberMyTeamDTO();
        dto.setTeamNum(Objects.isNull(teamCount) ? 0 : teamCount.getTeamCount());
        dto.setWeekNum(Objects.isNull(teamInviteCountList) ? 0 : teamInviteCountList.stream().mapToInt(TeamInviteCount::getCount).sum());
        return R.data(dto);
    }

    @Override
    @Transactional
    public R<String> beMember(BeMemberVO vo) {
        return beMemberImpl(vo);
    }

    @Override
    public R<String> beMemberImpl(BeMemberVO vo) {
        // 成为会员/续费会员，增加天数
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(member)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        if(Objects.equals(member.getIsMember(), YesOrNoEnum.YES.getCode())){
            //续费会员
            member.setExpireTime(DateUtil.offsetDay(member.getExpireTime(),vo.getDay()));
            member.setOpenType(MemberStatusEnum.RENEWED.getCode());
        }else{
            //开通会员
            member.setIsMember(YesOrNoEnum.YES.getCode());
            member.setExpireTime(com.ly.utils.DateUtil.getEndOfDay(DateUtil.offsetDay(new Date(),vo.getDay())));
            if(Objects.isNull(member.getFirstOpenTime())){
                member.setFirstOpenTime(new Date());
                member.setOpenType(MemberStatusEnum.ACTIVE.getCode());
            }else{
                member.setOpenType(MemberStatusEnum.RENEWED.getCode());
            }
        }
        this.updateById(member);
        return R.success();
    }

    @Override
    @Transactional
    public R<String> beMemberBatch(BeMemberBatchVO vo) {
        vo.getReferralCodeList().forEach(referralCode -> {
            BeMemberVO beMemberVO = new BeMemberVO();
            beMemberVO.setReferralCode(referralCode);
            beMemberVO.setDay(vo.getDay());
            beMemberImpl(beMemberVO);
        });
        return R.success();
    }

    @Override
    public R<String> transfer(MemberTransferVO vo) {
        // 会员转让
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getEmail, vo.getEmail()).last("limit 1"));
        if(Objects.nonNull(member)){
            return R.fail(ResultCode.EMAIL_EXIST);
        }
         member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(member)){
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        if(Objects.equals(member.getIsMember(),YesOrNoEnum.NO.getCode())){
            return R.fail(ResultCode.REFERRAL_CODE_NOT_MEMBER);
        }
        if(Objects.equals(member.getReferralType(),YesOrNoEnum.NO.getCode())){
            return R.fail(ResultCode.REFERRAL_CODE_NOT_SPECIAL);
        }
        LambdaUpdateWrapper<Member> lu = new LambdaUpdateWrapper<>();
        lu.eq(Member::getId,member.getId());
        lu.set(Member::getEmail,vo.getEmail());
        lu.set(Member::getUserId,null);
        lu.set(Member::getReferralType,ReferralTypeEnum.NORMAL.getCode());
        lu.set(Member::getTransferMark,new Date());
        this.update(lu);
        return R.success();
    }

    @Override
    @Transactional
    public R<List<String>> buyRecommendCode(BuySpecialMemberVO vo) {
        return buyRecommendCodeImpl(vo);
    }

    @Override
    public R<List<String>> buyRecommendCodeImpl(BuySpecialMemberVO vo){
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(member)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        if(this.count(new LambdaQueryWrapper<Member>().eq(Member::getReferralId,member.getId()).eq(Member::getReferralType,ReferralTypeEnum.SPECIAL.getCode())) > 0){
            // 如果该会员下已经有特殊推荐码则返回报错
            return R.fail(ResultCode.MEMBER_BUY_SPECIAL_MEMBER_EXIST);
        }
        List<String> referralCodes = new ArrayList<>();
        // 购买特殊推荐码（即生成10个会员）
        try{
            List<Member> newMembers = new ArrayList<>();
            Date expireTime = com.ly.utils.DateUtil.getEndOfDay(DateUtil.offsetDay(new Date(),vo.getDay()));

            String country = null;
            if(!member.getReferralCode().matches("\\d+")){
                country = member.getCountry();
            }

            for(int i =0 ;i<10;i++){
                Member newMember = new Member();
                newMember.setReferralCode(referralCodeService.referralCodeInit(country));
                newMember.setReferralType(ReferralTypeEnum.SPECIAL.getCode());
                newMember.setIsMember(YesOrNoEnum.YES.getCode());
                newMember.setOpenType(MemberStatusEnum.ACTIVE.getCode());
                newMember.setFirstOpenTime(new Date());
                newMember.setReferralId(member.getId());
                newMember.setExpireTime(expireTime);
                newMember.setNickname(member.getNickname());
                newMember.setEmail(member.getEmail());
                newMember.setUserId(member.getUserId());
                referralCodes.add(newMember.getReferralCode());
                newMembers.add(newMember);

                // 调用合作客户的接口,注册用户
                if(!referralCodeService.registerSpecial(newMember,vo.getReferralCode())){
                    throw new ServiceException(ResultCode.PARTNER_PAY_REGISTER_ERROR);
                }

                this.save(newMember);
            }
            // 生成10个会员账号和10个算力值账号
            newMembers.forEach(this::createMemberAccount);
            try{
                // 团队人数新增(本人的团队人数要加，但是团队邀请和上层不给加)
                TeamCount teamCount = new TeamCount();
                teamCount.setReferralCode(member.getReferralCode());
                teamCount.setTeamCount(10);
                teamCountMapper.insertOrUpdateTeamCount(teamCount);
            } catch (Exception e) {
                log.error("团队人数新增失败！！！");
            }
            // 返回10个特殊推荐码
            return R.data(referralCodes);
        }catch (Exception e){
            log.error("特殊推荐码会员生成失败:\n",e);
            return R.fail(ResultCode.FAILURE);
        }
    }


    @Override
    @Transactional
    public R<List<String>> beMemberAndBuyRecommendCode(BuySpecialMemberVO vo) {
        BeMemberVO beMemberVO = new BeMemberVO();
        beMemberVO.setReferralCode(vo.getReferralCode());
        beMemberVO.setDay(vo.getDay());
        if(R.isSuccess(beMemberImpl(beMemberVO))){
            return buyRecommendCodeImpl(vo);
        }
        return R.fail(ResultCode.FAILURE);
    }

    @Override
    public R<String> memberLogout(MemberLogoutVO vo) {
        MemberAccount account = memberAccountService.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, vo.getReferralCode()));
        if(Objects.isNull(account)){
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        //判断本人账号下是否有余额，提现冻结金额
        if(account.getAvailableAmount().compareTo(BigDecimal.ZERO) > 0 ){
            return R.fail(ResultCode.MEMBER_AMOUNT_NOT_EMPTY);
        }
        if(account.getWithdrawalFreezeAmount().compareTo(BigDecimal.ZERO) > 0){
            return R.fail(ResultCode.MEMBER_AMOUNT_NOT_EMPTY);
        }
        //判断本人账号下的特殊推荐码是否有余额，提现冻结金额
        LambdaQueryWrapper<Member> lq = new LambdaQueryWrapper<>();
        lq.eq(Member::getReferralId,account.getMemberId());
        lq.eq(Member::getReferralType, ReferralTypeEnum.SPECIAL.getCode());
        List<Member> specialMembers = this.list(lq);
        specialMembers.forEach(specialMember -> {
            MemberAccount a = memberAccountService.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, specialMember.getReferralCode()));
            if(a.getAvailableAmount().compareTo(BigDecimal.ZERO) > 0 ){
                throw new ServiceException(ResultCode.MEMBER_AMOUNT_NOT_EMPTY);
            }
            if(a.getWithdrawalFreezeAmount().compareTo(BigDecimal.ZERO) > 0){
                throw new ServiceException(ResultCode.MEMBER_AMOUNT_NOT_EMPTY);
            }
        });
        //然后把邮箱前缀加上vst，userId清除,并设为非会员（这样就不会进行分佣了）
        Member member = this.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode,vo.getReferralCode()));
        this.update(new LambdaUpdateWrapper<Member>().eq(Member::getId,member.getId()).set(Member::getUserId,null)
                            .set(Member::getEmail,"vst" + member.getEmail())
                            .set(Member::getIsMember,YesOrNoEnum.NO.getCode())
                            .set(Member::getStatus,2));
        return R.success("操作成功");
    }
    /**
    * @author: sean
    * @date: 2024/12/26 09:41
    * @desc: 生成会员账号和算力值账号
    */
    public void createMemberAccount(Member member){
        MemberAccount memberAccount = new MemberAccount();
        memberAccount.setMemberId(member.getId());
        memberAccount.setReferralCode(member.getReferralCode());
        memberAccountService.save(memberAccount);
        ComputingAccount computingAccount = new ComputingAccount();
        computingAccount.setMemberId(member.getId());
        computingAccount.setReferralCode(member.getReferralCode());
        computingAccountMapper.insert(computingAccount);
    }
}
