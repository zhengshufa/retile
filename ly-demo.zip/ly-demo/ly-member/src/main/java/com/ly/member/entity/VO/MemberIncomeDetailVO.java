package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益明细VO
 */

@Schema(description = "会员收益明细VO")
@Data
public class MemberIncomeDetailVO {

    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "类型(1-本周,2-本月,3-本年,4-累计)")
    private Integer type;
}
