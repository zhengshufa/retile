package com.ly.member.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.domain.BaseEntity;
import com.ly.utils.DateUtil;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.util.Date;

/**
 * <p>
 * 会员表
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Getter
@Setter
public class Member extends BaseEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 用户昵称
     */
    private String nickname;

    /**
     * 主播认证（0-不是，1-是）
     */
    private Integer anchorAuth;

    /**
     * 国别
     */
    private String country;

    /**
     * 语言设置
     */
    private String locale;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 推荐码类型（0-普通，1-特殊）
     */
    private Integer referralType;

    private Integer tenGenerations;

    /**
     * 是否会员（0-否，1-是）
     */
    private Integer isMember;

    /**
     * 开通类型（0-未开通（未激活），1-开通，2-续费，3-过期）
     */
    private Integer openType;

    /**
     * 首次开通时间
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date firstOpenTime;

    /**
     * 过期时间
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date expireTime;

    /**
     * 推荐人id
     */
    private Long referralId;

    /**
     * 转让时间
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date transferMark;
}
