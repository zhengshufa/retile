package com.ly.member.service.impl.jobService.impl;

import com.alibaba.fastjson.JSON;
import com.ly.constant.OrderStatusEnum;
import com.ly.constant.SharingRecordStatusEnum;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.BillTypeEnum;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.SharingRecord;
import com.ly.member.entity.SyncOrder;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.ISharingRecordService;
import com.ly.member.service.ISyncOrderService;
import com.ly.member.service.impl.jobService.JobService;
import com.ly.member.service.impl.sharingQualification.SharingQualificationFactory;
import com.ly.utils.ThreadPoolExecutorFactory;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

/**
 * @Author sean
 * @Date 2025/1/18 10:31
 * @desc
 */
@Service
@Slf4j
@AllArgsConstructor
public class JobServiceImpl implements JobService {

    private static final ExecutorService MEMBER_ORDER_COMMISSION_JOB_EXECUTOR = ThreadPoolExecutorFactory.threadPoolExecutorFactory("memberOrderCommissionJobExecutor");

    private final IMemberAccountService memberAccountService;

    private final ISharingRecordService sharingRecordService;

    private final ISyncOrderService syncOrderService;

    private final SharingQualificationFactory sharingQualificationFactory;


    @Override
    public void commission(List<SyncOrder> syncOrderList) {
        CountDownLatch latch = new CountDownLatch(syncOrderList.size());
        syncOrderList.forEach(syncOrder -> MEMBER_ORDER_COMMISSION_JOB_EXECUTOR.execute(() -> {
            try {
                BillTypeEnum billTypeEnum = BillTypeEnum.fromCode(syncOrder.getOperationType());

                if (billTypeEnum != null && syncOrder.getAmount().compareTo(BigDecimal.ZERO) > 0) {
                    sharingQualificationFactory.creator(billTypeEnum).sharing(syncOrder);
                } else {
                    log.error("syncOrder billType not exist : {}", syncOrder);
                }
                //更新订单
                syncOrder.setStatus(OrderStatusEnum.YES.getCode());
            } catch (Exception e) {
                // 记录异常日志
                log.error("memberOrderCommissionJob Error processing syncOrder: {}", syncOrder.getBillNo(), e);
                syncOrder.setStatus(OrderStatusEnum.FAIL.getCode());
                throw new ServiceException(ResultCode.INTERNAL_SERVER_ERROR);
            } finally {
                syncOrderService.updateById(syncOrder);
                latch.countDown();
            }
        }));
        try {
            latch.await(); // 等待所有子线程完成
        } catch (InterruptedException e) {
            log.error("Interrupted while waiting for tasks to complete", e);
            throw new ServiceException(ResultCode.INTERNAL_SERVER_ERROR);
        }
    }


    @Transactional
    @Override
    public void sharing(SharingRecord sharingRecord) {
        try{
            log.info("record:{}", JSON.toJSONString(sharingRecord));
            memberAccountService.memberAccountChange(sharingRecord.getBeneficiaryMemberId(), sharingRecord.getAmount(), null, MemberAccountChangeEnum.SHARING, null, sharingRecord.getBillNo());
            sharingRecord.setStatus(SharingRecordStatusEnum.YES.getCode());
        } catch (ServiceException e) {
            sharingRecord.setStatus(SharingRecordStatusEnum.FAIL.getCode());
            log.error("分佣任务业务失败",e);
            throw e;
        }catch (Exception e){
            sharingRecord.setStatus(SharingRecordStatusEnum.FAIL.getCode());
            log.error("sharing Error processing", e);
        }finally {
            sharingRecordService.updateById(sharingRecord);
        }
    }
}
