package com.ly.member.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.DTO.ComputingAccountDetailDTO;
import com.ly.member.entity.Member;
import com.ly.member.entity.VO.ComputingAccountDetailPageVO;
import com.ly.member.mapper.ComputingAccountDetailMapper;
import com.ly.member.mapstruct.ComputingAccountDetailDTOMapStruct;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IMemberService;
import com.ly.utils.PageBeanUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * <p>
 * 算力账号操作详情 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
public class ComputingAccountDetailServiceImpl extends ServiceImpl<ComputingAccountDetailMapper, ComputingAccountDetail> implements IComputingAccountDetailService {

    private final IMemberService memberService;

    private final ComputingAccountDetailDTOMapStruct computingAccountDetailDTOMapStruct;

    @Override
    public R<Page<ComputingAccountDetailDTO>> computingAccountDetailPage(ComputingAccountDetailPageVO vo) {
        Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        LambdaQueryWrapper<ComputingAccountDetail> lq = new LambdaQueryWrapper<>();
        lq.eq(ComputingAccountDetail::getReferralCode, member.getReferralCode());
        lq.eq(Objects.nonNull(vo.getOperationType()), ComputingAccountDetail::getOperationType, vo.getOperationType());
        lq.ge(Objects.nonNull(vo.getCreateTime()),ComputingAccountDetail::getCreateTime, vo.getCreateTime());
        lq.orderByDesc(ComputingAccountDetail::getCreateTime);
        Page<ComputingAccountDetail> computingAccountDetailPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), lq);
        return R.data(PageBeanUtils.copyProperties(computingAccountDetailPage, computingAccountDetailDTOMapStruct));
    }


}
