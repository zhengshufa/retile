package com.ly.member.entity.VO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户明细变动VO
 */

@Schema(description = "会员账户明细变动VO")
@Data
public class MemberAccountChangeVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "操作类型（1-分佣，2-提现，3-支付）")
    private Integer operationType;

    @Schema(description = "创建时间/操作时间/支付时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "金额")
    private BigDecimal amount;

    @Schema(description = "第三方订单号（提现和支付的情况下才有）")
    private String billNo;

    @Schema(description = "退款关联单号（仅在退款的时候有值，对应的是第三方单号）")
    private String refundTrackNo;

}
