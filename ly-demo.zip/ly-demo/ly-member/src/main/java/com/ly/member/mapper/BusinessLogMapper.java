package com.ly.member.mapper;

import com.ly.member.entity.BusinessLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 第三方请求和业务处理日志表 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-12-28 10:13:20
 */
public interface BusinessLogMapper extends BaseMapper<BusinessLog> {

}
