package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberInfoDTO;
import com.ly.member.entity.DTO.MemberInfoForTeamDTO;
import com.ly.member.entity.DTO.MemberMyTeamDTO;
import com.ly.member.entity.DTO.MemberTransferInfoDTO;
import com.ly.member.entity.Member;
import com.ly.member.entity.VO.*;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface IMemberService extends IService<Member> {


    R<String> memberRegister(MemberRegisterVO vo);

    R<String> memberSync(MemberSyncVO vo);

    R<String> memberImport(MemberImportVO vo);

    R<Page<MemberInfoDTO>> memberPage(MemberPageVO vo);

    R<MemberInfoDTO> memberInfo(MemberInfoVO vo);

    R<MemberTransferInfoDTO> transferInfo(MemberTransferInfoVO vo);

    R<String> referralChange(ReferralChangeVO vo);

    R<Page<MemberInfoForTeamDTO>> getTeamInfoPage(MemberTeamPageVO vo);

    R<MemberMyTeamDTO> getMyTeamInfo(MemberMyTeamVO vo);

    R<String> beMember(BeMemberVO vo);

    R<String> beMemberBatch(BeMemberBatchVO vo);

    R<String> beMemberImpl(BeMemberVO vo);

    R<String> transfer(MemberTransferVO vo);

    R<List<String>> buyRecommendCode(BuySpecialMemberVO vo);

    R<List<String>> buyRecommendCodeImpl(BuySpecialMemberVO vo);

    R<List<String>> beMemberAndBuyRecommendCode(BuySpecialMemberVO vo);

    R<String> memberLogout(MemberLogoutVO vo);

}
