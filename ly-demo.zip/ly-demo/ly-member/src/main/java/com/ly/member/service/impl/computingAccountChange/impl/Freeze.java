package com.ly.member.service.impl.computingAccountChange.impl;

import com.ly.constant.Constant;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IComputingAccountService;
import com.ly.member.service.impl.computingAccountChange.ComputingAccountChange;
import com.ly.utils.OrderNumberUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 10:16
 * @desc 冻结算力值
 */
@Service("ComputingAccountFreeze")
@AllArgsConstructor
public class Freeze implements ComputingAccountChange {

    private final IComputingAccountDetailService computingAccountDetailService;

    private final IComputingAccountService computingAccountService;

    @Override
    public ComputingAccountDetail change(ComputingAccount computingAccount, BigDecimal amount, BigDecimal oldAmount, ComputingAccountDetail oldDetail,Integer operationType,String remark) {
        if(computingAccount.getAmount().compareTo(amount) < 0){
            throw new ServiceException(ResultCode.ACCOUNT_NOT_ENOUGH);
        }
        computingAccount.setAvailableAmount(computingAccount.getAvailableAmount().subtract(amount));
        computingAccount.setFreezeAmount(computingAccount.getFreezeAmount().add(amount));
        computingAccountService.updateById(computingAccount);

        ComputingAccountDetail computingAccountDetail = new ComputingAccountDetail();
        computingAccountDetail.setMemberId(computingAccount.getMemberId());
        computingAccountDetail.setReferralCode(computingAccount.getReferralCode());
        computingAccountDetail.setOperationNo(Constant.COMPUTING_OPERATOR + OrderNumberUtils.generateOrderNumber());
        computingAccountDetail.setOperationType(operationType);
        computingAccountDetail.setAmount(amount);
        computingAccountDetail.setPayAmount(amount);
        computingAccountDetail.setStatus(ComputingAccountChangeEnum.FREEZE.getCode());
        computingAccountDetail.setRemark(remark);
        computingAccountDetailService.save(computingAccountDetail);
        return computingAccountDetail;


    }
}
