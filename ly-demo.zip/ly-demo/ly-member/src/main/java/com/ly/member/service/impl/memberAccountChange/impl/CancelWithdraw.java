package com.ly.member.service.impl.memberAccountChange.impl;

import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.service.IMemberAccountDetailService;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.impl.memberAccountChange.MemberAccountChange;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 09:32
 * @desc  取消提现（扣减冻结金额，增加账号余额）
 */
@Service
@AllArgsConstructor
@Slf4j
public class CancelWithdraw implements MemberAccountChange {


    private final IMemberAccountService memberAccountService;

    private final IMemberAccountDetailService memberAccountDetailService;

    @Override
    public MemberAccountDetail change(MemberAccount memberAccount, BigDecimal amount, BigDecimal oldAmount, MemberAccountDetail oldDetail, String billNo) {
        if(memberAccount.getWithdrawalFreezeAmount().compareTo(amount) < 0){
            log.error("冻结余额不足");
            throw new ServiceException(ResultCode.ACCOUNT_FREEZE_NOT_ENOUGH);
        }
        memberAccount.setAvailableAmount(memberAccount.getAvailableAmount().add(oldAmount));
        memberAccount.setWithdrawalFreezeAmount(memberAccount.getWithdrawalFreezeAmount().subtract(oldAmount));
        memberAccountService.updateById(memberAccount);
        //更新操作单
        oldDetail.setStatus(MemberAccountChangeEnum.CANCEL_WITHDRAW.getCode());
        memberAccountDetailService.updateById(oldDetail);
        return oldDetail;
    }
}
