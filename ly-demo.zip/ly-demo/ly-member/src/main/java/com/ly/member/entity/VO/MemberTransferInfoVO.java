package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  会员转让信息VO
 */
@Schema (description = "会员转让信息VO")
@Data
public class MemberTransferInfoVO {

    @Schema(description = "邮箱")
    private String email;

}
