package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户消费(AI经纪人专用)VO
 */

@Schema(description = "算力账户消费(AI经纪人专用)VO")
@Data
public class AiConsumptionVO {

    @Schema(description = "令牌")
    private String token;

    @Schema(description = "AI经纪人操作类型（1-消息发送）")
    private Integer type;

}
