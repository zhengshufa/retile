package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益明细（分佣）DTO
 */

@Schema(description = "会员收益明细（分佣）DTO")
@Data
public class MemberIncomeDetailDTO {


    @Schema(description = "总收益")
    private BigDecimal amount;

    @Schema(description = "订单类型(1-开通会员,2-续费会员,3-购买课程,4-充值算力值,5-主播奖励,6-导师服务奖励,7-产品销售奖励)")
    private Integer billType;


}
