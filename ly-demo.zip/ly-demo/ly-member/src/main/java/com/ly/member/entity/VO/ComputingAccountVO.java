package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户查询VO
 */

@Schema(description = "算力账户查询VO")
@Data
public class ComputingAccountVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;


}
