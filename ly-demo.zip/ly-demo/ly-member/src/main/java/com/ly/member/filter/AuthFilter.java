package com.ly.member.filter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.member.entity.BusinessLog;
import com.ly.member.service.IAuthService;
import com.ly.member.service.IBusinessLogService;
import com.ly.utils.StackTraceUtil;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

/**
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 9:29
 * @desc
 */
@Slf4j
@WebFilter(filterName = "AuthFilter", urlPatterns = "/*")
public class AuthFilter implements Filter, ApplicationContextAware {

    private ApplicationContext applicationContext;


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        if (request.getRequestURL() != null && request.getRequestURL().toString().contains("v3/api-docs")) {
            filterChain.doFilter(request, servletResponse);
            return;
        }

        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        int lastIndex = request.getRequestURI().lastIndexOf('.');
        if (lastIndex != -1) {
            String fileExtension = request.getRequestURI().substring(lastIndex + 1).toLowerCase();
            if ("js".equals(fileExtension) || "html".equals(fileExtension) || "css".equals(fileExtension)) {
                log.info("filter request===>method={},url={}", request.getMethod(), request.getRequestURL());
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }
        }



        // 获取请求头中的 sign
        String sign = request.getHeader("sign");
        String appId = request.getHeader("appId");

        ServletRequest requestWrapper = new BodyRequestWrapper(request);
        String body = HttpHelper.getBodyString(requestWrapper);
        //日志存储
        BusinessLog businessLog = new BusinessLog();
        businessLog.setAppId(appId);
        businessLog.setRequestId(request.getHeader("X-Request-ID"));
        businessLog.setRequestHeader(sign);
        businessLog.setProcessStartTime(new Date());

        businessLog.setEndpoint(request.getRequestURI());
        businessLog.setHttpMethod(request.getMethod());
        String responseStr = null;
        ResponseWrapper wrapperResponse = new ResponseWrapper(response);
        try {
            String requestParams = "";
            if ("GET".equals(request.getMethod())) {
                log.info("filter request===>method={},url={}", request.getMethod(), request.getRequestURL());
                Map<String, String[]> params = request.getParameterMap();
                if (!params.isEmpty()) {
                    StringBuilder str = new StringBuilder();
                    for (String key : params.keySet()) {
                        String[] values = params.get(key);
                        for (String value : values) {
                            str.append(key).append("=").append(value).append("&");
                        }
                    }
                    requestParams = str.toString();
                }
                filterChain.doFilter(requestWrapper, wrapperResponse);
                byte[] content = wrapperResponse.getContent();
                // 在这里对content进行签名操作
                responseStr = new String(content);
                response.getOutputStream().write(content);
                response.getOutputStream().flush();
                businessLog.setRequestPayload(requestParams);
                return;
            }
            businessLog.setRequestPayload(body);
            if (sign == null || sign.isEmpty()) {
                log.error("sign is blank!!");
                responseStr = writeOut(request, response, body);
                return;
            }
            if (appId == null || appId.isEmpty()) {
                log.error("appId is blank!!");
                responseStr = writeOut(request, response, body);
                return;
            }

            log.info("filter request===>method={},url={},body={}", request.getMethod(), request.getRequestURL(), body);
            IAuthService iAuthService = (IAuthService) applicationContext.getBean("authServiceImpl");
            if (!iAuthService.verifyAndDecode(appId, sign, body)) {
                responseStr = writeOut(request, response, body);
                return;
            }

            filterChain.doFilter(requestWrapper, wrapperResponse);
            log.info("after controller....");
            byte[] content = wrapperResponse.getContent();
            // 在这里对content进行签名操作
            responseStr = new String(content);
            if (StringUtils.hasLength(responseStr)) {
                JSONObject json = JSON.parseObject(content);
                log.info(json.toJSONString());
                try {
                    String responseSign = iAuthService.vstEncode(responseStr);
                    response.addHeader("sign", responseSign);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                    throw new RuntimeException(e);
                }
            }
            response.getOutputStream().write(content);
            response.getOutputStream().flush();
        } catch (Exception e) {
            businessLog.setErrorStack(StackTraceUtil.getStackTrace(e));
            throw new RuntimeException(e);
        } finally {
            businessLog.setResponsePayload(responseStr);
            businessLog.setResponseStatusCode(wrapperResponse.getStatus());
            IBusinessLogService businessLogService = (IBusinessLogService) applicationContext.getBean("iBusinessLogService");
            businessLogService.saveLogAsync(businessLog);
        }
    }

    /**
     * 没有权限
     *
     * @param request  请求对象
     * @param response 返回对象
     * @param jsonData 返回对象
     */
    public String writeOut(HttpServletRequest request, HttpServletResponse response, String jsonData) throws IOException {
        log.info("auth filter error, request===>method={},url={},body={}", request.getMethod(), request.getRequestURL(), jsonData);
        response.getWriter().print(JSON.toJSONString(R.fail(ResultCode.UN_AUTHORIZED)));
        response.getWriter().flush();
        return JSON.toJSONString(R.fail(ResultCode.UN_AUTHORIZED));
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }

    @Override
    public void setApplicationContext(@Nullable ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}