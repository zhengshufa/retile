package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户信息DTO
 */

@Schema(description = "会员账户信息DTO")
@Data
public class MemberAccountDTO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "用户昵称")
    private String nickname;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "总金额（总佣金）")
    private BigDecimal amount;

    @Schema(description = "可用余额")
    private BigDecimal availableAmount;

    @Schema(description = "已提现金额")
    private BigDecimal withdrawalAmount;

    @Schema(description = "状态")
    private Integer status;

}
