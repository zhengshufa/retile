package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户查询(分页)DTO
 */

@Schema(description = "算力账户查询(分页)DTO")
@Data
public class ComputingAccountPageDTO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "总额")
    private BigDecimal amount;

    @Schema(description = "可用余额")
    private BigDecimal availableAmount;

    @Schema(description = "冻结金额")
    private BigDecimal freezeAmount;

}
