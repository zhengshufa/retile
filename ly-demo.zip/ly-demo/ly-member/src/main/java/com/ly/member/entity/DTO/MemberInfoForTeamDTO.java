package com.ly.member.entity.DTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/13 9:49
 * @desc   团员信息查询DTO
 */

@Schema(description = "团员信息查询DTO")
@Data
public class MemberInfoForTeamDTO {

    @Schema(description = "id")
    private Long id;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "用户昵称")
    private String nickname;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "推荐码类型（0-普通，1-特殊）")
    private Integer referralType;

    @Schema(description = "是否会员（0-否，1-是）")
    private Integer isMember;

    @Schema(description = "开通类型（0-未开通（未激活），1-开通，2-续费，3-过期）")
    private Integer openType;

    @Schema(description = "首次开通时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date firstOpenTime;

    @Schema(description = "过期时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date expireTime;

    @Schema(description = "推荐人id")
    private String referralId;

    @Schema(description = "转让时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date transferMark;

    @Schema(description = "是否有下级(0-无，1-有)")
    private Integer hasChild;

}
