package com.ly.member.service;

import com.ly.member.entity.SyncOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 同步订单表（vst订单） 服务类
 * </p>
 *
 * @author sean
 * @since 2024-12-20 15:54:03
 */
public interface ISyncOrderService extends IService<SyncOrder> {

}
