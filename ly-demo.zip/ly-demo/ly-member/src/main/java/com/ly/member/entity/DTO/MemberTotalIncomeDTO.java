package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户DTO
 */

@Schema(description = "会员账户DTO")
@Data
public class MemberTotalIncomeDTO {

    @Schema(description = "收益方的推荐码")
    private String referralCode;

    @Schema(description = "已分佣金额")
    private BigDecimal sharingAmount = BigDecimal.ZERO;

    @Schema(description = "未分佣金额")
    private BigDecimal nonSharingAmount = BigDecimal.ZERO;

    @Schema(description = "会员订阅已分佣金额")
    private BigDecimal memberSharingAmount = BigDecimal.ZERO;

    @Schema(description = "会员续费已分佣金额")
    private BigDecimal renewMemberSharingAmount = BigDecimal.ZERO;

    @Schema(description = "知识付费已分佣金额")
    private BigDecimal classSharingAmount = BigDecimal.ZERO;

    @Schema(description = "充值算力值已分佣金额")
    private BigDecimal computingSharingAmount = BigDecimal.ZERO;

    @Schema(description = "个人直播奖励已分佣金额")
    private BigDecimal tvAnchorSharingAmount = BigDecimal.ZERO;

    @Schema(description = "导师服务奖励已分佣金额")
    private BigDecimal mentorSharingAmount = BigDecimal.ZERO;

    @Schema(description = "产品销售奖励已分佣金额")
    private BigDecimal sellSharingAmount = BigDecimal.ZERO;

    @Schema(description = "云连锁店购买已分佣金额")
    private BigDecimal onlineStoreSharingAmount = BigDecimal.ZERO;

    @Schema(description = "云连锁店卖货已分佣金额")
    private BigDecimal storeSellSharingAmount = BigDecimal.ZERO;

    @Schema(description = "直播团队奖励已分佣金额")
    private BigDecimal memberTvAnchorSharingAmount = BigDecimal.ZERO;

    @Schema(description = "额外直播奖励已分佣金额")
    private BigDecimal additionalLiveSharingAmount = BigDecimal.ZERO;

}
