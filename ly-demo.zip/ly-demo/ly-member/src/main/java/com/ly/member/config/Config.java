package com.ly.member.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @Author sean
 * @Date 2024/12/28 11:01
 * @desc
 */
@Component
@Getter
public class Config {

    @Value("${spring.application.name}")
    public  String serverName;

    @Value("${rsa.public-key}")
    public  String serverPublicKey;

    @Value("${rsa.private-key}")
    public  String serverPrivateKey;

    @Value("${viiva.auth-key}")
    private String authKey;

    @Value("${viiva.url}")
    private String url;

    @Value("${viiva.code-url}")
    private String codeUrl;

    @Value("${viiva.register-url}")
    private String registerUrl;



}
