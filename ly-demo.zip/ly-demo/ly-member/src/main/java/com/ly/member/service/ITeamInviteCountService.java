package com.ly.member.service;

import com.ly.member.entity.Member;
import com.ly.member.entity.TeamInviteCount;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 团队邀请数量统计（天） 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface ITeamInviteCountService extends IService<TeamInviteCount> {


    void registerTeamInviteCount(Member member);

}
