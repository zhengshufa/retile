package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户查询VO
 */

@Schema(description = "算力账户查询VO")
@Data
public class ComputingAccountPageVO {


    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;


}
