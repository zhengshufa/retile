package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益VO
 */

@Schema(description = "会员收益VO")
@Data
public class MemberTotalIncomeVO {


    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "开通类型（0-未开通（未激活），1-开通，2-续费，3-过期） 不传查全部")
    private Integer openType;

    @Schema(description = "推荐码类型（0-普通，1-特殊） 不传查全部")
    private Integer referralType;

    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;

}
