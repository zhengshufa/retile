package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 算力账号表
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Getter
@Setter
@TableName("computing_account")
public class ComputingAccount extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 会员id
     */
    private Long memberId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 总额
     */
    private BigDecimal amount;

    /**
     * 可用余额
     */
    private BigDecimal availableAmount;

    /**
     * 冻结金额
     */
    private BigDecimal freezeAmount;
}
