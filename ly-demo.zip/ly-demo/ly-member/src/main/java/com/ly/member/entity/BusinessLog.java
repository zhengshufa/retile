package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.util.Date;

import com.ly.utils.DateUtil;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 第三方请求和业务处理日志表
 * </p>
 *
 * @author sean
 * @since 2024-12-28 10:13:20
 */
@Getter
@Setter
@TableName("business_log")
public class BusinessLog extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一请求标识，用于追踪请求
     */
    private String requestId;

    /**
     * 第三方服务id
     */
    private String appId;

    /**
     * 请求的接口地址
     */
    private String endpoint;

    /**
     * HTTP 请求方法
     */
    private String httpMethod;

    /**
     * 请求报文内容
     */
    private String requestPayload;

    /**
     * 请求头
     */
    private String  requestHeader;

    /**
     * 响应报文内容
     */
    private String responsePayload;

    /**
     * HTTP 响应状态码
     */
    private Integer responseStatusCode;

    /**
     * 业务状态码，如自定义错误码
     */
    private String businessStatusCode;

    /**
     * 业务处理结果信息
     */
    private String businessMessage;

    /**
     * 处理开始时间
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date processStartTime;

    /**
     * 处理结束时间
     */
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date processEndTime;

    /**
     * 请求处理耗时（毫秒）
     */
    private Long elapsedTimeMs;

    /**
     * 第三方服务的 IP 地址
     */
    private String ipAddress;

    /**
     * 错误堆栈信息（如果有）
     */
    private String errorStack;
}
