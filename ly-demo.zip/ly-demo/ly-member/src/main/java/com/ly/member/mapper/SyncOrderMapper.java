package com.ly.member.mapper;

import com.ly.member.entity.SyncOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 同步订单表（vst订单） Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-12-20 15:54:03
 */
public interface SyncOrderMapper extends BaseMapper<SyncOrder> {

}
