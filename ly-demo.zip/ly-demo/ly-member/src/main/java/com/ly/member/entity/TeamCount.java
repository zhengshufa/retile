package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 团队数量统计
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Data
@TableName("team_count")
public class TeamCount implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * 推荐码
     */
    @TableId(value = "referral_code", type = IdType.NONE)
    private String referralCode;

    /**
     * 团队数量
     */
    private Integer teamCount;

    /**
     * 创建时间
     */

    @DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;


    /**
     * 更新时间
     */

    @DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    @TableField(condition = "update_time", updateStrategy = FieldStrategy.NEVER)
    private Date updateTime;

    /**
     * 状态[1:正常]
     */
    private Integer status;

    /**
     * 状态[0:未删除,1:删除]
     */
    @TableLogic
    private Integer isDeleted;
}
