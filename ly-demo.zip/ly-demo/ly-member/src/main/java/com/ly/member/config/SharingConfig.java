package com.ly.member.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Author sean
 * @Date 2025/1/20 11:16
 * @desc
 */
@Component
@Getter
@RefreshScope  // 配置变化时自动刷新
public class SharingConfig {

    @Value("${sharing.default.sharing-proportion}")
    private String defaultSharingProportion;

    @Value("${sharing.additional-live.sharing-proportion}")
    private String additionalLiveSharingProportion;

    @Value("${sharing.team-tv.sharing-proportion}")
    private String teamTvSharingProportion;

    @Value("${sharing.renew.sharing-proportion}")
    private String renewSharingProportion;

    @Value("${sharing.store-sell.sharing-proportion}")
    private String storeSellSharingProportion;

    @Value("${sharing.store-sell.company-proportion}")
    private String storeSellCompanyProportion;
}
