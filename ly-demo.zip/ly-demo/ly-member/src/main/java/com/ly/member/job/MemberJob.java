package com.ly.member.job;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.constant.*;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.entity.Member;
import com.ly.member.entity.MemberConfig;
import com.ly.member.entity.SharingRecord;
import com.ly.member.entity.SyncOrder;
import com.ly.member.kafka.KafkaProducerService;
import com.ly.member.service.IMemberConfigService;
import com.ly.member.service.IMemberService;
import com.ly.member.service.ISharingRecordService;
import com.ly.member.service.ISyncOrderService;
import com.ly.member.service.impl.jobService.JobService;
import com.ly.utils.ThreadPoolExecutorFactory;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import static com.ly.constant.Constant.MEMBER_EXPIRE_TOPIC;


/**
 * @Author sean
 * @Date 2024/12/23 16:25
 * @desc 会员定时任务
 */
@Component
@Slf4j
@AllArgsConstructor
public class MemberJob {

    private final JobService jobService;

    private static final ExecutorService MEMBER_COMMISSION_JOB_EXECUTOR = ThreadPoolExecutorFactory.threadPoolExecutorFactory("memberCommissionJob");

    private final IMemberService memberService;

    private final RedisTemplate<String, String> redisTemplate;

    private final IMemberConfigService memberConfigService;

    private final KafkaProducerService kafkaProducerService;

    private final ISyncOrderService syncOrderService;

    private final ISharingRecordService sharingRecordService;

    /**
     * @author: sean
     * @date: 2024/12/23 16:25
     * @desc: 会员过期定时任务
     */
    @XxlJob("memberExpireJob")
    public void memberExpireJob() {
        log.info("========== 会员过期定时任务start ==========");
        // 查出所有的会员，且过期时间是昨天的
        LambdaQueryWrapper<Member> lq = new LambdaQueryWrapper<>();
        lq.eq(Member::getIsMember, YesOrNoEnum.YES.getCode());
        lq.lt(Member::getExpireTime, DateUtil.today());
        List<Member> memberList = memberService.list(lq);
        if(!memberList.isEmpty()){
            memberList.forEach(member -> {
                member.setIsMember(YesOrNoEnum.NO.getCode());
                member.setOpenType(MemberStatusEnum.EXPIRE.getCode());
            });
            memberService.updateBatchById(memberList);
            kafkaProducerService.sendMessage(JSON.toJSONString(memberList), MEMBER_EXPIRE_TOPIC);
            log.info("========== 推送过期消息 ==========");
        }

        log.info("========== 会员过期定时任务end ==========");
    }

    /**
     * @author: sean
     * @date: 2024/12/24 16:33
     * @desc: 订单转分佣记录定时任务
     */
    @XxlJob("memberOrderCommissionJob")
    public void memberOrderCommissionJob() {
        log.info("========== 订单转分佣记录定时任务start ==========");
        // 每个订单已分的钱和未分成的钱以及无需分成的钱做记录
        // 订单转分佣记录定时任务
        // 查出所有订单
        LambdaQueryWrapper<SyncOrder> lq = new LambdaQueryWrapper<>();
        lq.eq(SyncOrder::getStatus, OrderStatusEnum.NO.getCode());
        lq.lt(SyncOrder::getCreateTime, DateUtil.offsetMinute(new Date(),-20));
        lq.last("limit 1000");
        while (true) {
            List<SyncOrder> syncOrderList = syncOrderService.list(lq);
            if (syncOrderList == null || syncOrderList.isEmpty()) {
                return;
            }
            jobService.commission(syncOrderList);
        }
    }


    /**
     * @author: sean
     * @date: 2024/12/23 16:40
     * @desc: 会员分佣定时任务
     */
    @XxlJob("memberCommissionJob")
    public void memberCommissionJob() {
        try{
            log.info("========== 会员分佣定时任务start ==========");
            // 获取配置项
            MemberConfig config = JSON.parseObject(redisTemplate.opsForValue().get(Constant.MEMBER_CONFIG), MemberConfig.class);
            if (Objects.isNull(config)) {
                config = memberConfigService.getOne(new LambdaQueryWrapper<>());
            }
            int sharingTime = config.getSharingTime() + 1;
            // 查询sharingTime天前的分佣记录，然后进行分佣
            LambdaQueryWrapper<SharingRecord> lq = new LambdaQueryWrapper<>();
            lq.eq(SharingRecord::getStatus, SharingRecordStatusEnum.NO.getCode());
            lq.lt(SharingRecord::getCreateTime, com.ly.utils.DateUtil.getEndOfDay(DateUtil.offsetDay(new Date(), -sharingTime)));
            lq.last("limit 1000");
            while (true) {
                List<SharingRecord> sharingRecordList = sharingRecordService.list(lq);
                if (sharingRecordList.isEmpty()) {
                    return;
                }
                CountDownLatch latch = new CountDownLatch(sharingRecordList.size());
                sharingRecordList.forEach(sharingRecord -> MEMBER_COMMISSION_JOB_EXECUTOR.execute(() ->{
                    try {
                        jobService.sharing(sharingRecord);
                    }finally {
                        latch.countDown();
                    }
                }));
                try {
                    latch.await(); // 等待所有子线程完成
                } catch (InterruptedException e) {
                    log.error("Interrupted while waiting for tasks to complete", e);
                    throw new ServiceException(ResultCode.INTERNAL_SERVER_ERROR);
                }
                ThreadUtil.sleep(500);
            }
        }catch (Exception e){
            log.error("memberCommissionJob Error processing", e);
            throw new ServiceException(ResultCode.INTERNAL_SERVER_ERROR);
        }
    }



}
