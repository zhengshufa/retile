package com.ly.member.kafka;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.ly.constant.Constant;
import com.ly.distribute.DistributeLock;
import com.ly.member.entity.Member;
import com.ly.member.entity.SyncOrder;
import com.ly.member.entity.VO.MemberSyncVO;
import com.ly.member.service.IMemberService;
import com.ly.member.service.ISyncOrderService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @Author sean
 * @Date 2024/12/24 15:12
 * @desc
 */


@Component
@Slf4j
@AllArgsConstructor
public class MemberKafkaConsumer {

    private final ISyncOrderService syncOrderService;

    private final DistributeLock distributeLock;

    private final IMemberService memberService;



    @KafkaListener(topics = "memberSyncOrder" ,groupId = "memberGroup")
    public void memberSyncOrderListen(String message) {
        log.info("==============接收到订单信息,开始处理.message: {}",message);
        try{
            SyncOrder syncOrder = JSON.parseObject(message, SyncOrder.class);
            log.info("==============接收到订单信息,开始处理.syncOrder: {}",JSON.toJSONString(syncOrder));
            String lockKey = Constant.SYNC_ORDER + syncOrder.getBillNo() + syncOrder.getReferralCode();
            boolean isLock = false;
            try {
                isLock = distributeLock.tryLock(lockKey, 1000);
                if (isLock) {
                    //账号金额修改
                    if(syncOrderService.count(new LambdaQueryWrapper<SyncOrder>().eq(SyncOrder::getBillNo, syncOrder.getBillNo()).eq(SyncOrder::getReferralCode,syncOrder.getReferralCode())) > 0){
                        return ;
                    }
                    syncOrderService.save(syncOrder);
                }
            } finally {
                if (isLock) {
                    distributeLock.unlock(lockKey);
                }
            }
        }catch (Exception e){
            log.error("同步订单失败",e);
        }
    }

    @KafkaListener(topics = "memberInfoSync" ,groupId = "memberGroup")
    public void memberInfoSyncListen(String message) {
        log.info("==============接收到用户信息,开始处理.message: {}",message);
        try{
            MemberSyncVO vo = JSON.parseObject(message, MemberSyncVO.class);
            if(Objects.isNull(vo.getReferralCode())){
                log.error("请求参数：推荐码为空");
                return ;
            }
            Member member = memberService.getOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
            if(Objects.isNull(member)){
                log.error("会员不存在");
                return ;
            }
            LambdaUpdateWrapper<Member> lu = new LambdaUpdateWrapper<>();
            lu.set(Objects.nonNull(vo.getNickname()),Member::getNickname,vo.getNickname());
            lu.set(Objects.nonNull(vo.getAnchorAuth()),Member::getAnchorAuth,vo.getAnchorAuth());
            lu.set(Objects.nonNull(vo.getEmail()),Member::getEmail,vo.getEmail());
            lu.set(Objects.nonNull(vo.getTenGenerations()),Member::getTenGenerations,vo.getTenGenerations());
            lu.eq(Member::getId,member.getId());
            memberService.update(lu);
        }catch (Exception e){
            log.error("同步用户信息失败",e);
        }
    }



    @KafkaListener(topics = "shopData" ,groupId = "memberGroup")
    public void shopData(String message) {
        log.info("==============接收到店铺数据,开始处理.message: {}",message);
        try{
            //todo 处理店铺数据

        }catch (Exception e){
            log.error("处理店铺数据失败",e);
        }
    }
}
