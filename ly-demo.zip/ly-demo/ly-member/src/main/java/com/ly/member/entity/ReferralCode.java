package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 推荐码生成表
 * </p>
 *
 * @author sean
 * @since 2024-12-27 10:28:04
 */
@Getter
@Setter
@TableName("referral_code")
public class ReferralCode extends BaseEntity {

    private static final long serialVersionUID = 1L;
}
