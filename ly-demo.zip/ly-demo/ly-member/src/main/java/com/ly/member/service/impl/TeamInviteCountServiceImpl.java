package com.ly.member.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.ReferralTypeEnum;
import com.ly.member.entity.Member;
import com.ly.member.entity.TeamCount;
import com.ly.member.entity.TeamInviteCount;
import com.ly.member.mapper.MemberMapper;
import com.ly.member.mapper.TeamCountMapper;
import com.ly.member.mapper.TeamInviteCountMapper;
import com.ly.member.service.ITeamInviteCountService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Objects;

/**
 * <p>
 * 团队邀请数量统计（天） 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
@Slf4j
public class TeamInviteCountServiceImpl extends ServiceImpl<TeamInviteCountMapper, TeamInviteCount> implements ITeamInviteCountService {

    private final MemberMapper memberMapper;

    private final TeamCountMapper teamCountMapper;



    @Override
    public void registerTeamInviteCount(Member member) {
        //会员注册
        if (member == null) {
            log.info("成员对象为空");
            return;
        }
        Date date = DateUtil.beginOfDay(new Date());
        // 递归
        while (true){
            if(Objects.isNull(member.getReferralId())){
                log.info("无上级");
                return ;
            }
            Member upper = memberMapper.selectById(member.getReferralId());
            if(Objects.isNull(upper)){
                log.info("上级不存在");
                return ;
            }
            // 根据会员上级添加上级的邀请人数
            TeamInviteCount teamInviteCount = new TeamInviteCount();
            teamInviteCount.setDate(date);
            teamInviteCount.setReferralCode(upper.getReferralCode());
            teamInviteCount.setCount(1);
            baseMapper.insertOrUpdateTeamInviteCount(teamInviteCount);
            // 根据会员上级添加团队人数
            TeamCount teamCount = new TeamCount();
            teamCount.setReferralCode(upper.getReferralCode());
            teamCount.setTeamCount(1);
            teamCountMapper.insertOrUpdateTeamCount(teamCount);
            // 如果本级是特殊推荐人的话,那么只加上级
            if(Objects.equals(member.getReferralType(), ReferralTypeEnum.SPECIAL.getCode())){
                log.info("本级为特殊推荐码,则循环停止,只加到上级过");
                return ;
            }
            member = upper;
        }
    }
}
