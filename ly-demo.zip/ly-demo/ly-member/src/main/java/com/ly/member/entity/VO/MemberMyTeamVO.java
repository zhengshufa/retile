package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  获取我的团队信息VO
 */
@Schema(description = "获取我的团队信息VO")
@Data
public class MemberMyTeamVO {

    @Schema(description = "推荐码")
    private String referralCode;

}
