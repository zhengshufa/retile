package com.ly.member.entity.DTO;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益明细（分佣）DTO
 */

@Schema(description = "会员收益明细（分佣）DTO")
@Data
public class SharingRecordDetailDTO {

    @Schema(description = "来源方的推荐码")
    private String sourceReferralCode;

    @Schema(description = "受益方的推荐码")
    private String beneficiaryReferralCode;

    @Schema(description = "金额")
    private BigDecimal amount;

    @Schema(description = "订单编号（支付单编号）")
    private String billNo;

    @Schema(description = "订单类型")
    private Integer billType;

    @Schema(description = "支付/订单时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "收益到账时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date updateTime;

    @Schema(description = "分佣记录状态（0-未分佣，1-已分佣）")
    private Integer status;
}
