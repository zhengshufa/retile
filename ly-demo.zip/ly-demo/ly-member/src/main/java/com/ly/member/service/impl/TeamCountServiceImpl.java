package com.ly.member.service.impl;

import com.ly.member.entity.TeamCount;
import com.ly.member.mapper.TeamCountMapper;
import com.ly.member.service.ITeamCountService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 团队数量统计 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
public class TeamCountServiceImpl extends ServiceImpl<TeamCountMapper, TeamCount> implements ITeamCountService {

}
