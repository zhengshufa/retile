package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.domain.api.R;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.DTO.MemberAccountDTO;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.entity.VO.*;

import java.math.BigDecimal;

/**
 * <p>
 * 会员账号表 服务类 test
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface IMemberAccountService extends IService<MemberAccount> {

    R<Page<MemberAccountDTO>> memberAccountPage(MemberAccountPageVO vo);

    R<MemberAccountDTO> memberAccount(MemberAccountVO vo);

    R<String> memberAccountWithdraw(MemberAccountWithdrawVO vo);

    MemberAccountDetail memberAccountChange(Long memberId, BigDecimal amount, BigDecimal oldAmount, MemberAccountChangeEnum memberAccountChangeEnum, MemberAccountDetail oldDetail,String billNo);

    R<String> memberAccountWithdrawChange(MemberAccountWithdrawChangeVO vo);

    R<String> memberAccountPay(MemberAccountChangeVO vo);

    R<String> memberAccountAdd(MemberAccountAddVO vo);

}
