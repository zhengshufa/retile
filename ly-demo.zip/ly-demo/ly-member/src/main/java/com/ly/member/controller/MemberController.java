package com.ly.member.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberInfoDTO;
import com.ly.member.entity.DTO.MemberInfoForTeamDTO;
import com.ly.member.entity.DTO.MemberMyTeamDTO;
import com.ly.member.entity.DTO.MemberTransferInfoDTO;
import com.ly.member.entity.VO.*;
import com.ly.member.service.IMemberService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/12 16:56
 * @desc    会员信息相关接口
 */

@RestController
@RequestMapping("member")
@Schema(title = "会员信息相关接口")
@AllArgsConstructor
public class MemberController {


    private final IMemberService memberService;


    /**
    * @author: sean
    * @date: 2024/12/12 16:30
    * @desc: 会员注册接口
    */
    @PostMapping("memberRegister")
    @Operation(summary = "会员注册接口")
    public R<String> memberRegister(@RequestBody MemberRegisterVO vo){
        return memberService.memberRegister(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员信息同步
     */
    @PostMapping("memberSync")
    @Operation(summary = "会员信息同步")
    public R<String> memberSync(@RequestBody MemberSyncVO vo){
        return memberService.memberSync(vo);
    }

    /**
    * @author: sean
    * @date: 2025/1/15 13:20
    * @desc: 合作伙伴会员导入
    */
    @PostMapping("memberImport")
    @Operation(summary = "合作伙伴会员导入")
    public R<String> memberImport(@RequestBody MemberImportVO vo){
        return memberService.memberImport(vo);
    }



    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员列表查询接口(分页)
     */
    @PostMapping("memberPage")
    @Operation(summary = "会员列表查询接口(分页)")
    public R<Page<MemberInfoDTO>> memberPage(@RequestBody MemberPageVO vo){
        return memberService.memberPage(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/12 16:30
    * @desc: 会员信息查询接口
    */
    @PostMapping("memberInfo")
    @Operation(summary = "会员信息查询接口")
    public R<MemberInfoDTO> memberInfo(@RequestBody MemberInfoVO vo){
        return memberService.memberInfo(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/12 16:30
    * @desc: 会员转让
    */
    @PostMapping("transfer")
    @Operation(summary = "会员转让")
    public R<String> transfer(@RequestBody MemberTransferVO vo){
        return memberService.transfer(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:30
     * @desc: 会员转让信息查询接口
     */
    @PostMapping("transferInfo")
    @Operation(summary = "会员转让信息查询接口")
    public R<MemberTransferInfoDTO> transferInfo(@RequestBody MemberTransferInfoVO vo){
        return memberService.transferInfo(vo);
    }

    /**
    * @author: sean
    * @date: 2025/1/21 20:41
    * @desc: 会员改网（变更推荐人）
    */
    @PostMapping("referralChange")
    @Operation(summary = "会员改网（变更推荐人）")
    public R<String> referralChange(@RequestBody ReferralChangeVO vo){
        return memberService.referralChange(vo);
    }


    /**
    * @author: sean
    * @date: 2024/12/12 16:37
    * @desc: 成为会员
    */
    @PostMapping("beMember")
    @Operation(summary = "成为会员")
    public R<String> beMember(@RequestBody BeMemberVO vo){
        return memberService.beMember(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:37
     * @desc: 成为会员(批量)
     */
    @PostMapping("beMemberBatch")
    @Operation(summary = "成为会员(批量)")
    public R<String> beMemberBatch(@RequestBody BeMemberBatchVO vo){
        return memberService.beMemberBatch(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/12 16:39
    * @desc: 购买特殊推荐码（即生成10个会员）
    */
    @PostMapping("buyRecommendCode")
    @Operation(summary = "购买特殊推荐码（即生成10个会员）")
    public R<List<String>> buyRecommendCode(@RequestBody BuySpecialMemberVO vo){
        return memberService.buyRecommendCode(vo);
    }

    /**
     * @author: sean
     * @date: 2024/12/12 16:39
     * @desc: 本身购买会员 + 购买特殊推荐码（即生成10个会员）
     */
    @PostMapping("beMemberAndBuyRecommendCode")
    @Operation(summary = "本身购买会员 + 购买特殊推荐码（即生成10个会员））")
    public R<List<String>> beMemberAndBuyRecommendCode(@RequestBody BuySpecialMemberVO vo){
        return memberService.beMemberAndBuyRecommendCode(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/12 16:40
    * @desc: 获取团队信息（即获取1代数据）(分页)
    */
    @PostMapping("getTeamInfoPage")
    @Operation(summary = "获取团队信息（即获取1代数据）(分页)")
    public R<Page<MemberInfoForTeamDTO>> getTeamInfoPage(@RequestBody MemberTeamPageVO vo){
        return memberService.getTeamInfoPage(vo);
    }

    /**
    * @author: sean
    * @date: 2024/12/12 16:40
    * @desc: 获取我的团队数据（本周邀请，我的团队数量）
    */
    @PostMapping("getMyTeamInfo")
    @Operation(summary = "获取我的团队数据（本周邀请，我的团队数量）")
    public R<MemberMyTeamDTO> getMyTeamInfo(@RequestBody MemberMyTeamVO vo){
        return memberService.getMyTeamInfo(vo);
    }

    /**
    * @author: sean
    * @date: 2025/1/18 16:42
    * @desc: 会员注销
    */
    @PostMapping("memberLogout")
    @Operation(summary = "会员注销")
    public R<String> memberLogout(@RequestBody MemberLogoutVO vo){
        return memberService.memberLogout(vo);
    }


}

