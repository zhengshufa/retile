package com.ly.member.mapstruct;


import com.ly.mapstruct.BaseMapStruct;
import com.ly.member.entity.DTO.SharingRecordDetailDTO;
import com.ly.member.entity.SharingRecord;
import org.mapstruct.Mapper;

/**
 * @Author sean
 * @Date 2024/12/17 11:05
 * @desc
 */
@Mapper(componentModel = "spring")
public interface SharingRecordDetailDTOMapStruct extends BaseMapStruct<SharingRecord, SharingRecordDetailDTO> {

}
