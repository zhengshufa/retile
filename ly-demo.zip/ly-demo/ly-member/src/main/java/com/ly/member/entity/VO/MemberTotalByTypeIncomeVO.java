package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员收益VO
 */

@Schema(description = "会员收益VO")
@Data
public class MemberTotalByTypeIncomeVO {


    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "订单类型")
    private Integer billType;

    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;

}
