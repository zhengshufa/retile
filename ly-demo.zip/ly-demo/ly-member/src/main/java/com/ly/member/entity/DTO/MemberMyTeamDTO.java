package com.ly.member.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/13 9:49
 * @desc   我的团队信息DTO
 */

@Schema(description = "我的团队信息DTO")
@Data
public class MemberMyTeamDTO {

    @Schema(description = "本周邀请数量")
    private Integer weekNum;

    @Schema(description = "我的团队数量")
    private Integer teamNum;

}
