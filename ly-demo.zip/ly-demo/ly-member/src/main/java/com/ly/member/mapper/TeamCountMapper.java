package com.ly.member.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ly.member.entity.TeamCount;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.executor.BatchResult;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 团队数量统计 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface TeamCountMapper extends BaseMapper<TeamCount> {
    void insertOrUpdateTeamCount(TeamCount teamCount);

}
