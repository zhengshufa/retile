package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 17:24
 * @desc  会员信息同步VO
 */
@Schema (description = "会员信息同步VO")
@Data
public class MemberSyncVO {

    @Schema(description = "用户昵称")
    private String nickname;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "主播认证（0-不是，1-是）")
    private Integer anchorAuth;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "满拨标识")
    private Integer tenGenerations;
}
