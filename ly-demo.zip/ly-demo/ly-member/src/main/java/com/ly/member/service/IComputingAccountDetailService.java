package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.domain.api.R;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.DTO.ComputingAccountDetailDTO;
import com.ly.member.entity.VO.ComputingAccountAddVO;
import com.ly.member.entity.VO.ComputingAccountConsumptionVO;
import com.ly.member.entity.VO.ComputingAccountDetailPageVO;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * <p>
 * 算力账号操作详情 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface IComputingAccountDetailService extends IService<ComputingAccountDetail> {


    R<Page<ComputingAccountDetailDTO>> computingAccountDetailPage(ComputingAccountDetailPageVO vo);


}
