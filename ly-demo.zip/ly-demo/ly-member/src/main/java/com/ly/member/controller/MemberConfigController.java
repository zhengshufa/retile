package com.ly.member.controller;

import com.ly.domain.api.R;
import com.ly.member.service.IMemberConfigService;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author sean
 * @Date 2025/1/21 09:39
 * @desc 配置
 */
@RestController
@RequestMapping("memberConfig")
@Schema(title = "配置相关")
@AllArgsConstructor
public class MemberConfigController {

    private final IMemberConfigService memberConfigService;


     /**
     * @author: sean
     * @date: 2025/1/21 09:40
     * @desc: 刷新配置
     */
     @GetMapping("refresh")
    public R<String> refreshConfig(){
         return memberConfigService.refreshConfig();
    }

}
