package com.ly.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 会员账号操作详情
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Getter
@Setter
@TableName("member_account_detail")
public class MemberAccountDetail extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 会员id
     */
    private Long memberId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 操作单号
     */
    private String operationNo;

    /**
     * 操作类型（1-分佣，2-提现，3-支付）
     */
    private Integer operationType;

    /**
     * 金额
     */
    private BigDecimal amount;

    /**
     * 第三方订单号（提现和支付的情况下才有）
     */
    private String billNo;

    /**
     * 退款关联单号（仅在退款的时候有值，对应的是第三方单号）
     */
    private String refundTrackNo;


    /**
     * 备注
     */
    private String remark;
}
