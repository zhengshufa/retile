package com.ly.member.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.member.entity.Member;
import com.ly.member.entity.ReferralCode;
import com.ly.member.entity.VO.MemberRegisterVO;

/**
 * <p>
 * 推荐码生成表 服务类
 * </p>
 *
 * @author sean
 * @since 2024-12-27 10:28:04
 */
public interface IReferralCodeService extends IService<ReferralCode> {

    String referralCodeInit(String country);

    boolean registerV(MemberRegisterVO vo, String referralCode);

    boolean registerSpecial(Member member, String referralCode);

}
