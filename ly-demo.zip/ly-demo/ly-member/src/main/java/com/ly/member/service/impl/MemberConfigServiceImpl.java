package com.ly.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.constant.Constant;
import com.ly.domain.api.R;
import com.ly.member.entity.MemberConfig;
import com.ly.member.mapper.MemberConfigMapper;
import com.ly.member.service.IMemberConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 配置表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-12-25 11:43:40
 */
@Service
@AllArgsConstructor
public class MemberConfigServiceImpl extends ServiceImpl<MemberConfigMapper, MemberConfig> implements IMemberConfigService {

    private final RedisTemplate<String,String> redisTemplate;

    @Override
    public R<String> refreshConfig() {
        MemberConfig config = this.getOne(new LambdaQueryWrapper<>());
        redisTemplate.opsForValue().set(Constant.MEMBER_CONFIG, JSON.toJSONString(config));
        return R.success("刷新成功");
    }
}
