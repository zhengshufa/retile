package com.ly.member.entity.VO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2025/2/11 13:41
 * @desc 店铺数据
 */
@Data
public class ShopData {

    private String id;

    private Integer shopStatus;


    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date bindTime;

    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date startTime;

    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date endTime;

    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private BigDecimal income;

}
