package com.ly.member.service.impl.computingAccountChange.impl;

import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.ComputingAccountChangeEnum;
import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.service.IComputingAccountDetailService;
import com.ly.member.service.IComputingAccountService;
import com.ly.member.service.impl.computingAccountChange.ComputingAccountChange;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 10:16
 * @desc 解冻算力值（取消支付）
 */
@Service("ComputingAccountThaw")
@AllArgsConstructor
public class Thaw implements ComputingAccountChange {

    private final IComputingAccountDetailService computingAccountDetailService;

    private final IComputingAccountService computingAccountService;

    @Override
    public ComputingAccountDetail change(ComputingAccount computingAccount, BigDecimal amount, BigDecimal oldAmount, ComputingAccountDetail oldDetail,Integer operationType,String remark) {
        if(computingAccount.getFreezeAmount().compareTo(amount) < 0){
            throw new ServiceException(ResultCode.ACCOUNT_FREEZE_NOT_ENOUGH);
        }
        computingAccount.setAvailableAmount(computingAccount.getAvailableAmount().add(oldAmount));
        computingAccount.setFreezeAmount(computingAccount.getFreezeAmount().subtract(oldAmount));

        computingAccountService.updateById(computingAccount);
        oldDetail.setStatus(ComputingAccountChangeEnum.THAW.getCode());
        //更新账单支付金额
        oldDetail.setPayAmount(amount);
        computingAccountDetailService.updateById(oldDetail);
        return oldDetail;
    }
}
