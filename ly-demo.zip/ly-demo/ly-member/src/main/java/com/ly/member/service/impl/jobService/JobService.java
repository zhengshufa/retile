package com.ly.member.service.impl.jobService;

import com.ly.member.entity.MemberConfig;
import com.ly.member.entity.SharingRecord;
import com.ly.member.entity.SyncOrder;

import java.util.List;

/**
 * @Author sean
 * @Date 2025/1/18 10:31
 * @desc
 */
public interface JobService {

    void commission(List<SyncOrder> syncOrderList);

    void sharing(SharingRecord sharingRecord);
}
