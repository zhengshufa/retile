package com.ly.member.entity.VO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户新增（充值，任务，课程观看）
 */

@Schema(description = "算力账户明细变动VO")
@Data
public class ComputingAccountAddVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "操作类型（1-充值，2-任务，4-AI经纪人-消息发送，5-AI数字人-视频创作，6-AI数字人-形象,7-AI数字人-声音,98-确认支付,99-取消支付）")
    private Integer operationType;

    @Schema(description = "创建时间/操作时间/支付时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "金额")
    private BigDecimal amount;

    @Schema(description = "支付金额")
    private BigDecimal payAmount;

    @Schema(description = "第三方订单号（提现和支付的情况下才有）")
    private String billNo;

    @Schema(description = "备注（细化任务备注）")
    private String remark;

}
