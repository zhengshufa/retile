package com.ly.member.mapstruct;


import com.ly.mapstruct.BaseMapStruct;
import com.ly.member.entity.ComputingAccountDetail;
import com.ly.member.entity.DTO.ComputingAccountDetailDTO;
import com.ly.member.entity.DTO.MemberIncomeDetailDTO;
import com.ly.member.entity.SharingRecord;
import org.mapstruct.Mapper;

/**
 * @Author sean
 * @Date 2024/12/17 11:05
 * @desc
 */
@Mapper(componentModel = "spring")
public interface MemberIncomeDetailDTOMapStruct extends BaseMapStruct<SharingRecord, MemberIncomeDetailDTO> {

}
