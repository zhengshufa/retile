package com.ly.member.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.constant.Constant;
import com.ly.constant.YesOrNoEnum;
import com.ly.distribute.DistributeLock;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.ServiceException;
import com.ly.member.constant.MemberAccountChangeEnum;
import com.ly.member.entity.DTO.MemberAccountDTO;
import com.ly.member.entity.Member;
import com.ly.member.entity.MemberAccount;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.entity.VO.*;
import com.ly.member.mapper.MemberAccountMapper;
import com.ly.member.mapper.MemberMapper;
import com.ly.member.mapstruct.MemberAccountDTOMapStruct;
import com.ly.member.service.IMemberAccountDetailService;
import com.ly.member.service.IMemberAccountService;
import com.ly.member.service.impl.memberAccountChange.MemberAccountChangeFactory;
import com.ly.utils.PageBeanUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * <p>
 * 会员账号表 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
@Slf4j
public class MemberAccountServiceImpl extends ServiceImpl<MemberAccountMapper, MemberAccount> implements IMemberAccountService {

    private final MemberAccountDTOMapStruct memberAccountDTOMapStruct;

    private final MemberMapper memberMapper;

    private final IMemberAccountDetailService memberAccountDetailService;

    private final DistributeLock distributeLock;

    private final MemberAccountChangeFactory memberAccountChangeFactory;

    @Override
    public R<Page<MemberAccountDTO>> memberAccountPage(MemberAccountPageVO vo) {
        Page<MemberAccount> memberAccountPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()), new LambdaQueryWrapper<>());
        Page<MemberAccountDTO> page = PageBeanUtils.copyProperties(memberAccountPage, memberAccountDTOMapStruct);
        return R.data(page);
    }

    @Override
    public R<MemberAccountDTO> memberAccount(MemberAccountVO vo) {
        Member member = memberMapper.selectOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            // 推荐码下无会员信息
            return R.fail(ResultCode.MEMBER_NOT_EXIST);
        }
        MemberAccount memberAccount = this.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, member.getReferralCode()));
        return R.data(memberAccountDTOMapStruct.toDto(memberAccount));
    }

    @Override
    @Transactional
    public R<String> memberAccountWithdraw(MemberAccountWithdrawVO vo) {
        if (vo.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ServiceException(ResultCode.AMOUNT_MUST_GREATER_THAN_ZERO);
        }
        MemberAccount memberAccount = this.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(memberAccount)) {
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }
        // 冻结金额
        try {
            MemberAccountDetail memberAccountDetail = memberAccountChange(memberAccount.getMemberId(), vo.getAmount(), null, MemberAccountChangeEnum.FREEZE, null, null);
            return R.data(memberAccountDetail.getOperationNo());
        } catch (ServiceException e) {
            log.error("会员账号提现申请失败");
            throw e;
        }catch (Exception e) {
            log.error("充值接口未知异常",e);
            throw new ServiceException(ResultCode.FAILURE);
        }

    }

    @Override
    @Transactional
    public R<String> memberAccountWithdrawChange(MemberAccountWithdrawChangeVO vo) {
        MemberAccount memberAccount = this.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, vo.getReferralCode()));
        MemberAccountDetail oldDetail = memberAccountDetailService.getOne(new LambdaQueryWrapper<MemberAccountDetail>()
                .eq(MemberAccountDetail::getOperationNo, vo.getOperationNo())
                .eq(MemberAccountDetail::getStatus, MemberAccountChangeEnum.FREEZE.getCode()));
        if (Objects.isNull(memberAccount)) {
            // 会员不存在
            log.error("会员不存在");
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }

        MemberAccountChangeEnum memberAccountChangeEnum = Objects.equals(vo.getResult(), YesOrNoEnum.YES.getCode()) ? MemberAccountChangeEnum.CANCEL_WITHDRAW : MemberAccountChangeEnum.CONFIRM_WITHDRAW;
        try {
            MemberAccountDetail memberAccountDetail = memberAccountChange(memberAccount.getMemberId(), oldDetail.getAmount(), null, memberAccountChangeEnum, oldDetail, null);
            return R.data(memberAccountDetail.getOperationNo());
        } catch (ServiceException e) {
            log.error("提现失败");
            throw e;
        }catch (Exception e) {
            log.error("充值接口未知异常",e);
            throw new ServiceException(ResultCode.FAILURE);
        }
    }


    @Override
    @Transactional
    public R<String> memberAccountPay(MemberAccountChangeVO vo) {
        if (vo.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ServiceException(ResultCode.AMOUNT_MUST_GREATER_THAN_ZERO);
        }
        MemberAccount memberAccount = this.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(memberAccount)) {
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }
        // 支付金额
        try {
            MemberAccountDetail memberAccountDetail = memberAccountChange(memberAccount.getMemberId(), vo.getAmount(), null, MemberAccountChangeEnum.REDUCE, null, vo.getBillNo());
            return R.data(memberAccountDetail.getOperationNo());

        } catch (ServiceException e) {
            log.error("会员账户支付失败");
            throw e;
        }catch (Exception e) {
            log.error("充值接口未知异常",e);
            throw new ServiceException(ResultCode.FAILURE);
        }
    }


    @Override
    @Transactional
    public R<String> memberAccountAdd(MemberAccountAddVO vo) {
        if (vo.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ServiceException(ResultCode.AMOUNT_MUST_GREATER_THAN_ZERO);
        }
        Member member = memberMapper.selectOne(new LambdaQueryWrapper<Member>().eq(Member::getReferralCode, vo.getReferralCode()));
        if (Objects.isNull(member)) {
            throw new ServiceException(ResultCode.MEMBER_NOT_EXIST);
        }
        if(Objects.equals(member.getReferralType(),YesOrNoEnum.YES.getCode())){
            //充值限制：只能给普通推荐码充值
            throw new ServiceException(ResultCode.REFERRAL_CODE_CAN_NOT_RECHARGE);
        }
        try {
            MemberAccountDetail memberAccountDetail = memberAccountChange(member.getId(), vo.getAmount(), null, MemberAccountChangeEnum.ADD, null, vo.getBillNo());
            return R.data(memberAccountDetail.getOperationNo());
        }catch (ServiceException e){
            log.error("充值接口业务失败",e);
            throw e;
        }catch (Exception e) {
            log.error("充值接口未知异常",e);
            throw new ServiceException(ResultCode.FAILURE);
        }

    }

    /**
     * @param memberId                会员id
     * @param amount                  金额
     * @param memberAccountChangeEnum 账户变动类型
     * @author: sean
     * @date: 2024/12/18 15:05
     * @desc: 会员账号改变余额方法（所有改变会员账号余额的都调用这个方法）
     */
    @Override
    public MemberAccountDetail memberAccountChange(Long memberId, BigDecimal amount, BigDecimal oldAmount, MemberAccountChangeEnum memberAccountChangeEnum, MemberAccountDetail oldDetail, String billNo) {
        //3、分布式锁，防止重复提交
        String lockKey = Constant.MEMBER_ACCOUNT + memberId;
        boolean isLock = false;
        try {
            isLock = distributeLock.tryLock(lockKey, 10000);
            if (isLock) {
                //账号金额修改
                //判断订单号是否已存在
                if (Objects.nonNull(billNo) && !Objects.equals(memberAccountChangeEnum,MemberAccountChangeEnum.SHARING)) {
                    if (memberAccountDetailService.count(new LambdaQueryWrapper<MemberAccountDetail>().eq(MemberAccountDetail::getBillNo, billNo)) > 0) {
                        log.error("第三方订单号已存在,billNo:{}", billNo);
                        throw new ServiceException(ResultCode.PARTNER_PAY_ORDER_BILL_EXIST);
                    }
                }
                if (Objects.isNull(oldDetail) && (Objects.equals(MemberAccountChangeEnum.CONFIRM_WITHDRAW, memberAccountChangeEnum) || Objects.equals(MemberAccountChangeEnum.CANCEL_WITHDRAW, memberAccountChangeEnum))) {
                    // 提现记录不存在
                    log.error("account detail not exist");
                    throw new ServiceException(ResultCode.ACCOUNT_DETAIL_NOT_EXIST);
                }
                log.info("memberAccountChange========================");
                MemberAccount memberAccount = this.getOne(new LambdaQueryWrapper<MemberAccount>().eq(MemberAccount::getMemberId, memberId));
                if (memberAccountChangeEnum != null) {
                    MemberAccountDetail memberAccountDetail = memberAccountChangeFactory.creator(memberAccountChangeEnum).change(memberAccount, amount, oldAmount, oldDetail, billNo);
                    if (memberAccountDetail == null) {
                        log.error("会员账号余额修改失败，未生成详情记录, memberId: {}, amount: {}, enum: {}", memberId, amount, memberAccountChangeEnum);
                        throw new ServiceException(ResultCode.FAILURE);
                    }
                    return memberAccountDetail;
                }
            }
        }
        finally {
            if (isLock) {
                distributeLock.unlock(lockKey);
            }
        }
        log.error("会员账号修改余额方法失败,billNo:{}", billNo);
        throw new ServiceException(ResultCode.FAILURE);
    }
}
