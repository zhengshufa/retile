package com.ly.member.entity.VO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  算力账户明细查询VO
 */

@Schema(description = "算力账户明细查询VO")
@Data
public class ComputingAccountDetailPageVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "操作类型（1-充值，2-任务，4-AI经纪人-消息发送，5-AI数字人-视频创作，6-AI数字人-形象,7-AI数字人-声音）,不传查全部")
    private Integer operationType;

    @Schema(description = "创建时间/操作时间/支付时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "页码")
    private Integer pageNum;

    @Schema(description = "每页数量")
    private Integer pageSize;

}
