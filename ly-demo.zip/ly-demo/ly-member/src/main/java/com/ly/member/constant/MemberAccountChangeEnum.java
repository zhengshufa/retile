package com.ly.member.constant;

import com.ly.member.service.impl.memberAccountChange.MemberAccountChange;
import com.ly.member.service.impl.memberAccountChange.impl.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 会员账号操作类型
 */
@Getter
@AllArgsConstructor
public enum MemberAccountChangeEnum {

    //会员账号操作类型
    ADD(0,"充值", Add.class),
    REDUCE(1,"扣款", Reduce.class),
    FREEZE(2,"提现冻结", Freeze.class),
    CONFIRM_WITHDRAW(5,"确认提现", ConfirmWithdraw.class),
    CANCEL_WITHDRAW(6,"取消提现", CancelWithdraw.class),
//    FREEZE_SHARING(7,"冻结分佣金额", FreezeSharing.class),
//    THAW_FREEZE_SHARING(8,"解除冻结的分佣金额", ThawFreezeSharing.class),
//    UNAVAILABLE_AMOUNT(9,"转入不用金额", UnavailableAmount.class),
    SHARING(10,"分佣", Sharing.class),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    final Class<? extends MemberAccountChange> clazz;

    public static MemberAccountChangeEnum fromCode(int code) {
        for (MemberAccountChangeEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
