package com.ly.member.mapper;

import com.ly.member.entity.MemberAccountDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会员账号操作详情 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface MemberAccountDetailMapper extends BaseMapper<MemberAccountDetail> {

}
