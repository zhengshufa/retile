package com.ly.member.service;

import com.ly.domain.api.R;
import com.ly.member.entity.MemberConfig;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 配置表 服务类
 * </p>
 *
 * @author sean
 * @since 2024-12-25 11:43:40
 */
public interface IMemberConfigService extends IService<MemberConfig> {

    R<String> refreshConfig();

}
