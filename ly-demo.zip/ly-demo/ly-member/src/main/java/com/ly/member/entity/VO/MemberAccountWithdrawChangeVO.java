package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author sean
 * @Date 2024/12/12 18:01
 * @desc  会员账户提现审核结果VO test
 */

@Schema(description = "会员账户提现审核结果VO")
@Data
public class MemberAccountWithdrawChangeVO {

    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "第三方订单号（提现和支付的情况下才有）")
    private String billNo;

    @Schema(description = "操作单号")
    private String operationNo;

    @Schema(description = "提现结果:0-驳回,1-通过（不传则默认为0）")
    private Integer result;


}
