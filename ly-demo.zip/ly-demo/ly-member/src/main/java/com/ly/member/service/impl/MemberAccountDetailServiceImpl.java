package com.ly.member.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberAccountDetailDTO;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.entity.VO.MemberAccountDetailPageVO;
import com.ly.member.mapper.MemberAccountDetailMapper;
import com.ly.member.mapstruct.MemberAccountDetailDTOMapStruct;
import com.ly.member.service.IMemberAccountDetailService;
import com.ly.utils.PageBeanUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * <p>
 * 会员账号操作详情 服务实现类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
@Service
@AllArgsConstructor
public class MemberAccountDetailServiceImpl extends ServiceImpl<MemberAccountDetailMapper, MemberAccountDetail> implements IMemberAccountDetailService {

    private final MemberAccountDetailDTOMapStruct memberAccountDetailDTOMapStruct;


    @Override
    public R<Page<MemberAccountDetailDTO>> memberAccountDetailPage(MemberAccountDetailPageVO vo) {
        LambdaQueryWrapper<MemberAccountDetail> lq = new LambdaQueryWrapper<>();
        lq.eq(MemberAccountDetail::getReferralCode,vo.getReferralCode());
        lq.eq(Objects.nonNull(vo.getOperationType()),MemberAccountDetail::getOperationType,vo.getOperationType());
        lq.ge(Objects.nonNull(vo.getCreateTime()),MemberAccountDetail::getCreateTime,vo.getCreateTime());
        Page<MemberAccountDetail> detailPage = this.page(new Page<>(vo.getPageNum(), vo.getPageSize()),lq);
        return R.data(PageBeanUtils.copyProperties(detailPage,memberAccountDetailDTOMapStruct));
    }
}
