package com.ly.member.mapper;

import com.ly.member.entity.TeamInviteCount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 团队邀请数量统计（天） Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface TeamInviteCountMapper extends BaseMapper<TeamInviteCount> {


    void insertOrUpdateTeamInviteCount(TeamInviteCount teamInviteCount);


}
