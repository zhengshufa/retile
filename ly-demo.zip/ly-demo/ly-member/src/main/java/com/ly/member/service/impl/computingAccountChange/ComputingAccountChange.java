package com.ly.member.service.impl.computingAccountChange;

import com.ly.member.entity.ComputingAccount;
import com.ly.member.entity.ComputingAccountDetail;

import java.math.BigDecimal;

/**
 * @Author sean
 * @Date 2024/12/24 09:31
 * @desc
 */
public interface ComputingAccountChange {

    ComputingAccountDetail change(ComputingAccount computingAccount, BigDecimal amount, BigDecimal oldAmount,ComputingAccountDetail oldDetail,Integer operationType,String remark);
}
