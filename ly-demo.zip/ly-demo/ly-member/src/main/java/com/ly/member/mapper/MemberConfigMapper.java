package com.ly.member.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ly.member.entity.MemberConfig;

/**
 * <p>
 * 配置表 Mapper 接口
 * </p>
 *
 * @author sean
 * @since 2024-12-25 11:43:40
 */
public interface MemberConfigMapper extends BaseMapper<MemberConfig> {

}
