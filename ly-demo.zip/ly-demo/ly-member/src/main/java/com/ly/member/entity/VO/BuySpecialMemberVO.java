package com.ly.member.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/12 18:07
 * @desc  购买特殊推荐码
 */

@Schema (description = "购买特殊推荐码")
@Data
public class BuySpecialMemberVO {


    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "天数")
    private Integer day;
}
