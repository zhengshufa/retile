package com.ly.member.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.domain.api.R;
import com.ly.member.entity.DTO.MemberAccountDetailDTO;
import com.ly.member.entity.MemberAccountDetail;
import com.ly.member.entity.VO.MemberAccountDetailPageVO;

/**
 * <p>
 * 会员账号操作详情 服务类
 * </p>
 *
 * @author sean
 * @since 2024-33-17 10：12：04
 */
public interface IMemberAccountDetailService extends IService<MemberAccountDetail> {

    R<Page<MemberAccountDetailDTO>> memberAccountDetailPage(MemberAccountDetailPageVO vo);

}
