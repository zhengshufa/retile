package com.ly.member.config;

import cn.hutool.cache.Cache;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.constant.Constant;
import com.ly.member.entity.MemberConfig;
import com.ly.member.entity.Partner;
import com.ly.member.service.IMemberConfigService;
import com.ly.member.service.IPartnerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/19 09:20
 * @desc
 */
@Component
@AllArgsConstructor
@Slf4j
public class StartupRunner implements CommandLineRunner {

    private final IMemberConfigService memberConfigService;

    private final IPartnerService partnerService;

    private final RedisTemplate<String,String> redisTemplate;

    private final Cache<String,String> guavaCacheConfig;

    @Override
    public void run(String... args) {
        // init 项目配置项
        // 加载会员配置
        MemberConfig config = memberConfigService.getOne(new LambdaQueryWrapper<>());
        redisTemplate.opsForValue().set(Constant.MEMBER_CONFIG, JSON.toJSONString(config));
        List<Partner> partnerList = partnerService.list();
        // 加载partner配置
        for(Partner partner : partnerList){
            guavaCacheConfig.put(Constant.MEMBER_PARTNER + partner.getPartnerCode(), partner.getPublicKey());
        }
        log.info("Application has started!");
    }
}
