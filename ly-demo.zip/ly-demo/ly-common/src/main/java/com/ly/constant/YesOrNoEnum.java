package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc yes or no
 */
@Getter
@AllArgsConstructor
public enum YesOrNoEnum {

    NO(0,"否"),
    YES(1,"是"),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    public static YesOrNoEnum fromCode(int code) {
        for (YesOrNoEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
