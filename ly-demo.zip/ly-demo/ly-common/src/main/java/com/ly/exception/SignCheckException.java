package com.ly.exception;


/**
 * packageName.className com.ly.exception.SignCheckException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description TODO
 */
public class SignCheckException extends RuntimeException{

    public SignCheckException(String message) {
        super(message);
    }

    public SignCheckException(String message, Throwable cause) {
        super(message, cause);
    }

    public SignCheckException(Throwable cause) {
        super(cause);
    }
}
