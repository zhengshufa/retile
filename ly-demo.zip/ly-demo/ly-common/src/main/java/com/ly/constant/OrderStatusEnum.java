package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 分佣状态枚举
 */
@Getter
@AllArgsConstructor
public enum OrderStatusEnum {

    NO(0,"未处理"),
    YES(1,"已处理"),
    FAIL(2,"异常"),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

}
