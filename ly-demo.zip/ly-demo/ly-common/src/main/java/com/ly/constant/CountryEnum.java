package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 国家枚举
 */
@Getter
@AllArgsConstructor
public enum CountryEnum {

    KR("KR","韩国"),
    CL("CL","智利"),
    PT("PT","葡萄牙"),
    MM("MM","缅甸"),
    ES("ES","西班牙"),
    PL("PL","波兰"),
    KH("KH","柬埔寨"),
    MO("MO","中国澳门"),
    IN("IN","印度"),
    KZ("KZ","哈萨克斯坦"),
    ID("ID","印尼"),
    SG("SG","新加坡"),
    MY("MY","马来西亚"),
    EC("EC","厄瓜多尔"),
    CO("CO","哥伦比亚"),
    MX("MX","墨西哥"),
    BO("BO","玻利维亚"),
    TH("TH","泰国"),
    CA("CA","加拿大"),
    VN("VN","越南"),
    JP("JP","日本"),
    PH("PH","菲律宾"),
    TW("TW","中国台湾"),
    US("US","美国"),
    HK("HK","中国香港"),
     ;

    /**
     * code编码
     */
    final String code;
    /**
     * 中文信息描述
     */
    final String name;



    public static CountryEnum fromCode(String code) {
        for (CountryEnum unit : values()) {
            if (Objects.equals(code, unit.getCode())) {
                return unit;
            }
        }
        return null;
    }


}
