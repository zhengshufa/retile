package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 算力账号操作类型
 */
@Getter
@AllArgsConstructor
public enum ComputingAccountOperationTypeEnum {

    RECHARGE(1,"充值"),
    TASK(2,"任务"),   //细化的任务放到备注里
    AI_BROKER_MSG(4,"AI经纪人-消息发送"),
    AI_DIGITAL_VIDEO(5,"AI数字人-视频创作"),
    AI_DIGITAL_IMAGE(6,"AI数字人-形象"),
    AI_DIGITAL_VOICE(7,"AI数字人-声音"),
    TUTOR_APPOINTMENT(8,"导师预约"),

    CONFIRM_PAY(98,"确认支付"),
    CANCEL_PAY(99,"取消支付"),

    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    public static ComputingAccountOperationTypeEnum fromCode(int code) {
        for (ComputingAccountOperationTypeEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
