package com.ly.utils;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * @Author sean
 * @Date 2024/12/28 09:58
 * @desc 堆栈工具类
 */
public class StackTraceUtil {

    // 工具方法：获取异常堆栈信息
    public static String getStackTrace(Throwable throwable) {
        StringWriter sw = new StringWriter();
        try (PrintWriter pw = new PrintWriter(sw)) {
            throwable.printStackTrace(pw);
            return sw.toString();
        }
    }
}
