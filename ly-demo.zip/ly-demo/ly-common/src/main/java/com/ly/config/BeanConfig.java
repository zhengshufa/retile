package com.ly.config;

import cn.hutool.cache.Cache;
import cn.hutool.cache.CacheUtil;
import com.ly.distribute.DistributeLock;
import com.ly.distribute.RedisDistributeLock;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.config.BeanConfig
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 14:55
 * @desc TODO
 */
@Component
public class BeanConfig {

    @Bean
    public DistributeLock distributeLock(RedisTemplate<String, String> redisTemplate){
        return new RedisDistributeLock( redisTemplate);
    }

    @Bean
    public Cache<String,String> cacheService() {
        return CacheUtil.newFIFOCache(100);
    }

}