/**
 * Copyright (c) 2018-2099, Chill Zhuang 庄骞 (bladejava@qq.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ly.domain.api;

import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 业务代码枚举
 *
 * @author Chill
 */
@Getter
@AllArgsConstructor
public enum ResultCode implements IResultCode {

    /**
     * 操作成功
     */
    SUCCESS(HttpServletResponse.SC_OK, "request success"),

    /**
     * 业务异常
     */
    FAILURE(HttpServletResponse.SC_BAD_REQUEST, "bad request"),

    /**
     * 请求未授权
     */
    UN_AUTHORIZED(HttpServletResponse.SC_UNAUTHORIZED, "unauthorized"),

    /**
     * 404 没找到请求
     */
    NOT_FOUND(HttpServletResponse.SC_NOT_FOUND, "404 not find"),

    /**
     * 消息不能读取
     */
    MSG_NOT_READABLE(HttpServletResponse.SC_BAD_REQUEST, "msg not readable"),

    /**
     * 不支持当前请求方法
     */
    METHOD_NOT_SUPPORTED(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "The current request method is not supported."),

    /**
     * 不支持当前媒体类型
     */
    MEDIA_TYPE_NOT_SUPPORTED(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE, "The current media type is not supported."),

    /**
     * 请求被拒绝
     */
    REQ_REJECT(HttpServletResponse.SC_FORBIDDEN, "The request was rejected."),

    /**
     * 服务器异常
     */
    INTERNAL_SERVER_ERROR(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error"),

    /**
     * 缺少必要的请求参数
     */
    PARAM_MISS(HttpServletResponse.SC_BAD_REQUEST, "The necessary request parameters are missing."),

    /**
     * 请求参数类型错误
     */
    PARAM_TYPE_ERROR(HttpServletResponse.SC_BAD_REQUEST, "The type of the request parameter is incorrect."),

    /**
     * 请求参数绑定错误
     */
    PARAM_BIND_ERROR(HttpServletResponse.SC_BAD_REQUEST, "Request parameter binding error."),

    /**
     * 参数校验失败
     */
    PARAM_VALID_ERROR(HttpServletResponse.SC_BAD_REQUEST, "Parameter verification failed."),
    /**
     * 邮箱已存在
     */
    EMAIL_EXIST(2000, "The email address already exists."),

    /**
     * 会员不存在
     */
    MEMBER_NOT_EXIST(2001, "The member does not exist."),

    /**
     * 余额不足
     */
    ACCOUNT_NOT_ENOUGH(2002, "Insufficient balance."),

    /**
     * 冻结余额不足
     */
    ACCOUNT_FREEZE_NOT_ENOUGH(2003, "The frozen balance is insufficient."),

    /**
     * 账号详情单不存在
     */
    ACCOUNT_DETAIL_NOT_EXIST(2006, "account detail not exist"),

    /**
     * 金额必须大于0
     */
    AMOUNT_MUST_GREATER_THAN_ZERO(2007, "amount must greater than zero"),


    /**
     * 推荐人不存在
     */
    REFERRAL_NOT_EXIST(2009, "referral not exist"),

    /**
     * 非特殊推荐码
     */
    REFERRAL_CODE_NOT_SPECIAL(2010, "referral code not special"),
    /**
     * 该推荐码不是会员
     */
    REFERRAL_CODE_NOT_MEMBER(2011, "referral code not member"),


    /**
     * 订单已存在
     */
    PARTNER_PAY_ORDER_EXIST(1000, "The order already exists."),

    /**
     * 特殊推荐码已存在，不能重复购买
     */
    MEMBER_BUY_SPECIAL_MEMBER_EXIST(2012, "special member exist"),

    /**
     * 第三方订单号已存在
     */
    PARTNER_PAY_ORDER_BILL_EXIST(2013, "The third-party order number already exists."),

    /**
     * 会员已存在
     */
    MEMBER_EXIST(2014, "The member exist."),

    /**
     * 特殊推荐码无法充值
     */
    REFERRAL_CODE_CAN_NOT_RECHARGE(2015, "special member can not recharge"),

    /**
     * 获取第三方推荐码失败
     */
    REFERRAL_CODE_CAN_NOT_GET(2016, "referral code can not get"),

    /**
     * 会员可用余额或提现冻结金额不为空
     */
    MEMBER_AMOUNT_NOT_EMPTY(2017, "member amount not empty"),

    /**
     * 调用第三方注册接口失败
     */
    PARTNER_PAY_REGISTER_ERROR(2018, "The third-party register interface error"),

    /**
     * 订单已完成
     */
    PARTNER_PAY_ORDER_FINISHED(1001, "The order has been completed."),
    /**
     * 支付方式不存在
     */
    PARTNER_PAY_WAY_NOT_FIND(1002, "The payment way does not exist or has not been configured."),
    /**
     * 支付渠道不存在
     */
    PARTNER_PAY_CHANNEL_NOT_FIND(1003, "The payment channel does not exist or has not been configured."),




    /**
     * appId 不能为空
     */
    APP_ID_IS_NULL(1004, "The appId cannot be left blank."),

    /**
     * 订单不存在
     */
    ORDER_NOT_EXIST(1005, "order not exist"),

    /**
     * 余额支付错误
     */
    BALANCE_PAY_ERROR(1006, "balance pay error"),
    /**
     * 充值请求已超时
     */
    REQUEST_IS_EXPIRED(1007, "this request is expired"),
    /**
     * 接口每天充值次数限制
     */
    MAX_COUNT_OF_DAY(1008, "the maximum count times per day limit"),
    /**
     * 接口充值每次额度限制
     */
    MAX_AMOUNT_OF_CHARGE(1009, "the maximum recharge amount limit"),


    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    /**
     * 根据
     */
    public static ResultCode codeOf(int code) {
        for (ResultCode resultCode : ResultCode.values()) {
			if(resultCode.getCode()==code){
                return resultCode;
            }
        }
        return null;
    }
}
