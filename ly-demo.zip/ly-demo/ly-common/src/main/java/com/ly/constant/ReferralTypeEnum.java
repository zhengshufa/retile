package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 推荐码类型枚举
 */
@Getter
@AllArgsConstructor
public enum ReferralTypeEnum {

    NORMAL(0,"普通"),
    SPECIAL(1,"特殊"),
    SPECIAL_TO_NORMAL(2,"特殊转普通"),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

}
