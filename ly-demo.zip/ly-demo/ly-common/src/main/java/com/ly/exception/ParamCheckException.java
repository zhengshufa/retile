package com.ly.exception;

/**
 * packageName.className com.ly.exception.ParamCheckException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description
 */
public class ParamCheckException extends RuntimeException{

    public ParamCheckException(String message) {
        super(message);
    }

    public ParamCheckException(String message, Throwable cause) {
        super(message, cause);
    }

    public ParamCheckException(Throwable cause) {
        super(cause);
    }
}
