//package com.ly.config;
//
//import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
//import io.swagger.v3.core.converter.AnnotatedType;
//import io.swagger.v3.core.converter.ModelConverter;
//import io.swagger.v3.core.converter.ModelConverterContext;
//import io.swagger.v3.core.converter.ModelConverters;
//import io.swagger.v3.oas.models.media.ArraySchema;
//import io.swagger.v3.oas.models.media.IntegerSchema;
//import io.swagger.v3.oas.models.media.Schema;
//import io.swagger.v3.oas.models.media.ObjectSchema;
//import jakarta.annotation.PostConstruct;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component;
//
//import java.lang.reflect.ParameterizedType;
//import java.lang.reflect.Type;
//import java.util.Iterator;
//import java.util.Map;
//
//
///**
// * @Author sean
// * @Date 2024/12/23 09:28
// * @desc 全局配置字段过滤器
// */
//@Configuration
//@Slf4j
//public class OpenApiConfig implements ModelConverter {
//    @PostConstruct
//    public void init() {
//        log.info("------------》OpenApiConfig initialized《--------------");
//        ModelConverters.getInstance().addConverter(this);
//        log.info("------------》OpenApiConfig register《--------------");
//    }
//    @Override
//    public Schema resolve(AnnotatedType var1, ModelConverterContext context, Iterator<ModelConverter> var3) {
//        Type type = var1.getType();
//        // 判断是否是 Page 类型
//        log.info("--------------------Resolving type: {}", type);
//        if (type instanceof Class) {
//            Class<?> rawType = (Class<?>) type;
//            // 如果是 Page 类型，手动提取泛型信息
//            if (rawType.equals(Page.class)) {
//                // 创建一个新的 ObjectSchema 并手动定义需要的属性
//                return new ObjectSchema()
//                        .addProperty("current", new IntegerSchema())
//                        .addProperty("size", new IntegerSchema())
//                        .addProperty("pages", new IntegerSchema())
//                        .addProperty("total", new IntegerSchema())
//                        .addProperty("records", new ArraySchema().items(new ObjectSchema()));
//            }
//
//        }
//        return var3.hasNext() ? var3.next().resolve(var1, context, var3) : null;
//    }
//
//    @Override
//    public boolean isOpenapi31() {
//        return ModelConverter.super.isOpenapi31();
//    }
//}
