package com.ly.exception;

import com.ly.domain.api.ResultCode;

/**
 * packageName.className com.ly.exception.BusinessException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description
 */
public class BusinessException extends RuntimeException{


    private ResultCode resultCode;
    
    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }

    public BusinessException(ResultCode resultCode) {
        super(resultCode.getMessage());
        this.resultCode = resultCode;
    }
    public ResultCode getResultCode() {
        return resultCode;
    }
}
