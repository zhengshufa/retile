package com.ly.exception;

/**
 * packageName.className com.ly.exception.NotFindIDCheckException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description
 */
public class NotFindIDCheckException extends RuntimeException{

    public NotFindIDCheckException(String message) {
        super(message);
    }

    public NotFindIDCheckException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotFindIDCheckException(Throwable cause) {
        super(cause);
    }
}
