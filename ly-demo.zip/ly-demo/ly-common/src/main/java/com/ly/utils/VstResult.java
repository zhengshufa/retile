package com.ly.utils;

import lombok.Data;
import lombok.ToString;

/**
 * packageName.className com.ly.pay.entity.POJO.VstResult
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-25 11:27
 * @description TODO
 */
@Data
@ToString
public class VstResult{

    private Integer code;
    private String msg;
    private String data;

}