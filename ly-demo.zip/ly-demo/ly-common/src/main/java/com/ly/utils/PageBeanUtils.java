package com.ly.utils;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.mapstruct.BaseMapStruct;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;


/**
 * @author hpdata
 * @DATE 2023/8/2416:24
 */
@Slf4j
public class PageBeanUtils {


	/**
	 * 将源PageBean的属性拷贝到目标PageBean中，并返回目标PageBean对象
	 *
	 * @param source      源PageBean对象
	 * @return 目标PageBean对象
	 */
	public static <S, T> Page<T> copyProperties(Page<S> source, BaseMapStruct<S, T> mapStruct) {
		Page<T> target = new Page<>();
		target.setRecords(mapStruct.toDtoList(source.getRecords()));
		target.setCurrent(source.getCurrent());
		target.setSize(source.getSize());
		target.setTotal(source.getTotal());
		return target;
	}

}
