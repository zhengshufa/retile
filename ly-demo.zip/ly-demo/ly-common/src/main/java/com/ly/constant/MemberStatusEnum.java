package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 会员状态枚举
 */
@Getter
@AllArgsConstructor
public enum MemberStatusEnum {

    UNACTIVATED(0,"未激活"),
    ACTIVE(1,"开通"),
    RENEWED(2,"续费"),
    EXPIRE(3,"过期");

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

}
