package com.ly.distribute;

import com.alibaba.nacos.shaded.com.google.common.base.Preconditions;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;


/**
 * packageName.className com.ly.pay.config.BeanConfig
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 14:55
 * @description 利用redisTemplate 实现分布式锁
 */
@Slf4j
public class RedisDistributeLock implements DistributeLock {

    /**
     * 每秒的毫秒数
     */
    private static final int MILLIS_PER_SECOND = 1000;
    /**
     * 0值
     */
    private static final int INT_ZERO = 0;
    /**
     * 1值
     */
    private static final int INT_ONE = 1;

    /**
     * 使用的是redisTemplate
     */
    private final RedisTemplate<String,String> redisTemplate;



    /**
     * 使用jedisCluster来操作
     */
    public RedisDistributeLock(RedisTemplate<String,String> redisTemplate) {
        Preconditions.checkNotNull(redisTemplate, "redisTemplate invalid");
        this.redisTemplate = redisTemplate;
    }

    /**
     * @see DistributeLock#tryLock(String, long)
     */
    @Override
    public boolean tryLock(String lock, long requestTimeoutMS) {
        return this.tryLock(lock, DEFAULT_LOCK_EXPIRE_TIME_MS, requestTimeoutMS);
    }

    /**
     * @see DistributeLock#tryLock(String, long, long)
     */
    @Override
    public boolean tryLock(String lock, long lockExpireTimeMS, long requestTimeoutMS) {
        Preconditions.checkArgument(StringUtils.isNotBlank(lock), "lock invalid");
        Preconditions.checkArgument(lockExpireTimeMS > INT_ZERO, "lockExpireTimeMS invalid");
        Preconditions.checkArgument(requestTimeoutMS > INT_ZERO, "requestTimeoutMS invalid");
        while (requestTimeoutMS > INT_ZERO) {
            String expire = String.valueOf(System.currentTimeMillis() + lockExpireTimeMS + INT_ONE);

            Boolean result = this.redisSetnx(lock, expire);
            if (result) {
                //目前没有线程占用此锁
                this.redisExpire(lock, (int) (lockExpireTimeMS / MILLIS_PER_SECOND));
                return true;
            }
            String currentValue = this.redisGet(lock);
            if (null == currentValue) {
                //锁已经被其他线程删除马上重试获取锁
                continue;
            } else if (Long.parseLong(currentValue) < System.currentTimeMillis()) {
                //此处判断出锁已经超过了其有效的存活时间
                String oldValue = this.redisGetSet(lock, expire);
                if (null == oldValue || oldValue.equals(currentValue)) {
                    //1.如果拿到的旧值是空则说明在此线程做getSet之前已经有线程将锁删除，由于此线程getSet操作之后已经对锁设置了值，实际上相当于它已经占有了锁
                    //2.如果拿到的旧值不为空且等于前面查到的值，则说明在此线程进行getSet操作之前没有其他线程对锁设置了值,则此线程是第一个占有锁的
                    this.redisExpire(lock, (int) (lockExpireTimeMS / MILLIS_PER_SECOND));
                    return true;
                }
            }
            long sleepTime;
            if (requestTimeoutMS > DEFAULT_SLEEP_TIME_MS) {
                sleepTime = DEFAULT_SLEEP_TIME_MS;
                requestTimeoutMS -= DEFAULT_SLEEP_TIME_MS;
            } else {
                sleepTime = requestTimeoutMS;
                requestTimeoutMS = INT_ZERO;
            }
            try {
                TimeUnit.MILLISECONDS.sleep(sleepTime);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return false;
    }

    /**
     * @see DistributeLock#unlock(String)
     */
    @Override
    public void unlock(String lock) {
        String value = this.redisGet(lock);
        if (null != value && Long.parseLong(value) > System.currentTimeMillis()) {
            //如果锁还存在并且还在有效时间则进行删除
            this.redisDel(lock);
        }
    }

    /**
     * redis.setnx
     */
    private Boolean redisSetnx(String key, String value) {

            return redisTemplate.opsForValue().setIfAbsent(key, value);

    }

    /**
     * redis.expire
     */
    private void redisExpire(String key, int seconds) {
        redisTemplate.expire(key, seconds, TimeUnit.SECONDS);

    }

    /**
     * redis.getSet
     */
    private String redisGetSet(String key, String value) {

            Object objValue = redisTemplate.opsForValue().getAndSet(key, value);
            return null == objValue ? null : objValue.toString();

    }

    /**
     * redis.get
     */
    private String redisGet(String key) {

            Object objValue = redisTemplate.opsForValue().get(key);
            return null == objValue ? null : objValue.toString();

    }

    /**
     * redis.del
     */
    @SuppressWarnings("unchecked")
    private void redisDel(String key) {

            redisTemplate.delete(key);

    }

}