package com.ly.utils;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author sean
 * @Date 2024/12/19 16:10
 * @desc 线程池定义
 */
public class ThreadPoolExecutorFactory {

    public static ThreadPoolExecutor threadPoolExecutorFactory(String poolName){
        // 自定义线程名称的格式为test-序号
        return new ThreadPoolExecutor(
                4,
                4,
                60,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(10000),
                r -> {
                    // 自定义线程名称的格式为test-序号
                    return new Thread(r, poolName + "-" + Thread.currentThread().getThreadGroup().activeCount());
                }
        );
    }
}
