package com.ly.exception;

import com.ly.domain.api.ResultCode;

/**
 * packageName.className com.ly.exception.BusinessException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description
 */
public class PayBusinessException extends BusinessException{


    public PayBusinessException(String message) {
        super(message);
    }

    public PayBusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public PayBusinessException(Throwable cause) {
        super(cause);
    }

    public PayBusinessException(ResultCode resultCode) {
        super(resultCode);
    }
}
