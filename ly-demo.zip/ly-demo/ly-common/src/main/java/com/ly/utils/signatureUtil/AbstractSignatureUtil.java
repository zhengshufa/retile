package com.ly.utils.signatureUtil;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.utils.HttpUtils;
import com.ly.utils.VstResult;
import com.ly.utils.signatureUtil.rsa.RSACoder;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

/**
 * @Author sean
 * @Date 2024/12/14 13:13
 * @desc
 */
@Slf4j
public abstract class AbstractSignatureUtil<T> {


    /**
     * 请求封装类
     *
     * @param paramMap
     * @param tClass
     * @throws Exception
     */
    public T vstRequest(Map<String, Object> paramMap, Class<T> tClass, String requestUrl,String appId, String requestId) throws Exception {
        String  respStr = send(paramMap, appId,requestUrl, requestId);
        VstResult vstResult = JSON.parseObject(respStr, VstResult.class);
        //通知vst 结果返回 0代表成功，跟会员系统返回的不一样，所以这里需要特殊处理
        if(vstResult == null || !vstResult.getCode().equals(0)){
            log.error("vstRequest paramMap={},result={}",paramMap,respStr);
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
        JSONObject jsonObject = JSON.parseObject(respStr);
        String jsonStr =jsonObject.getString("data");
        if(tClass == String.class){
            return (T)jsonStr;
        }
        return JSON.parseObject(jsonStr, tClass);
    }

    /**
     * 发送
     * @param paramMap
     * @param appId
     * @param requestId
     * @return
     * @throws Exception
     */
    private String send(Map<String, Object> paramMap,String appId, String requestUrl,String requestId) throws Exception {
        TreeMap<String, Object> treeMap = new TreeMap<>(paramMap);
        StringBuilder sb = new StringBuilder();
        treeMap.forEach((k, v) -> sb.append(k).append("=").append(v).append("&"));
        log.info("source ===>{}",sb.toString());
        String sign = RSACoder.sign(sb.toString().getBytes(StandardCharsets.UTF_8), getPrivateKey());
        log.info("req.sign:{}", sign);
        requestUrl = requestUrl == null?getInterPath():requestUrl;
        String respStr = HttpUtils.sendPost(requestUrl, paramMap, sign, appId, requestId);
        log.info("resp===>{}",respStr);
        return respStr;
    }



    /**
     * 请求封装类
     *
     * @param paramMap
     * @param tClass
     * @throws Exception
     */
    public T request(Map<String, Object> paramMap, Class<T> tClass, String appId, String requestId) throws Exception {
        String  respStr = send(paramMap, appId,null, requestId);
        VstResult vstResult = JSON.parseObject(respStr, VstResult.class);
        valid(vstResult,paramMap,respStr);
        JSONObject jsonObject = JSON.parseObject(respStr);
        String jsonStr =jsonObject.getString("data");
        if(tClass == String.class){
            return (T)jsonStr;
        }
        return JSON.parseObject(jsonStr, tClass);
    }

private void valid(VstResult vstResult,Map<String, Object> paramMap,String  respStr ){
    if(vstResult == null ){
        log.error("vst result is null, paramMap={},result={}",paramMap,respStr);
        throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
    }
    if(!vstResult.getCode().equals(200)){
        log.error("code is not 200, paramMap={},result={}",paramMap,respStr);
        ResultCode resultCode = ResultCode.codeOf(vstResult.getCode());
        if(resultCode == null){
            resultCode = ResultCode.INTERNAL_SERVER_ERROR;
        }
        throw new PayBusinessException(resultCode);
    }
}
    /**
     *  这个方法用于requestUrl是动态的逻辑
     * @param paramMap
     * @param requestUrl
     * @param tClass
     * @param appId
     * @param requestId
     * @return
     * @throws Exception
     */
    public T request(Map<String, Object> paramMap,String requestUrl, Class<T> tClass, String appId, String requestId) throws Exception {
        String  respStr = send(paramMap, appId,null,requestId);
        VstResult vstResult = JSON.parseObject(respStr, VstResult.class);
        valid(vstResult,paramMap,respStr);
        JSONObject jsonObject = JSON.parseObject(respStr);
        String jsonStr =jsonObject.getString("data");
        if(tClass == String.class){
            return (T)jsonStr;
        }
        return JSON.parseObject(respStr, tClass);
    }

    /**
     * 获取请求地址
     * @return
     */
    public abstract String getInterPath();

    /**
     * 获取加密的key
     * @return
     */
    public abstract String getPrivateKey();

}
