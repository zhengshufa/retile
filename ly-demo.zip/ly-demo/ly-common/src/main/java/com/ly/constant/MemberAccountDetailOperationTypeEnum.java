package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 会员账号操作类型
 */
@Getter
@AllArgsConstructor
public enum MemberAccountDetailOperationTypeEnum {

    SHARING(1,"分佣"),
    WITHDRAW(2,"提现"),   //细化的任务放到备注里
    PAY(3,"支付"),   //取消支付
    ADD(4,"充值")
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

    public static MemberAccountDetailOperationTypeEnum fromCode(int code) {
        for (MemberAccountDetailOperationTypeEnum unit : values()) {
            if (code == unit.getCode()) {
                return unit;
            }
        }
        return null;
    }


}
