package com.ly.mapstruct;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Author sean
 * @Date 2024/12/17 11:55
 * @desc
 */


public interface BaseMapStruct<E,D> {

    /**
    * @author: sean
    * @date: 2024/12/17 12:00
    * @desc: 将实体 E 转换为 DTO D
    */
    D toDto(E entity);

    /**
    * @author: sean
    * @date: 2024/12/17 12:00
    * @desc: 将实体列表 E 转换为 DTO 列表 D
    */
    List<D> toDtoList(List<E> entities);

    /**
     * @author: sean
     * @date: 2024/12/17 12:00
     * @desc: 将DTO D 转换为 实体 E
     */
    E toEntity(D dto);

    /**
     * @author: sean
     * @date: 2024/12/17 12:00
     * @desc: 将DTO列表 D 转换为 实体列表 E
     */
    List<E> toEntityList(List<D> dtoList);
}
