package com.ly.utils;

import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Random;
@Slf4j
public class OrderNumberUtils {


    /**
     * 生成订单号的方法
     * 格式大致为：时间戳（精确到毫秒） + 本机IP地址后3位 + 4位随机数字
     * @return 生成的订单号字符串
     */
    public static String generateOrderNumber() {
        StringBuilder orderNumber = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        // 获取当前时间的时间戳（精确到毫秒）
        String timestamp = sdf.format(new Date());
        orderNumber.append(timestamp);

        // 获取本机IP地址后3位（尝试获取非回环地址的IP）
        String ipAddressLastTwoDigits = getLocalIpAddressLastTwoDigits();
        if (ipAddressLastTwoDigits!= null) {
            orderNumber.append(ipAddressLastTwoDigits);
        }
        Random random = new Random();
        // 生成几位随机数字，这里示例生成4位随机数，你可以根据需求调整位数
        for (int i = 0; i < 4; i++) {
            orderNumber.append(random.nextInt(10));
        }

        return orderNumber.toString();
    }

    /**
     * 获取本机IP地址的后两位数字（十六进制形式转换为十进制后取后两位）
     * 如果获取失败则返回null
     * @return 本机IP地址后两位数字组成的字符串（十进制）或者null
     */
    private static String getLocalIpAddressLastTwoDigits() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = inetAddresses.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress.getAddress().length == 4) {
                        byte[] ipAddressBytes = inetAddress.getAddress();
                        byte lastByte = ipAddressBytes[3];
                        return StrUtil.padPre(Byte.toString(lastByte),3,'0');
                    }
                }
            }
        } catch (Exception e) {
           log.info("获取机器ip生成三位数字失败");
        }
        return "000";
    }

    /**
     * 简单数字生成方面
     * @return
     */
    public static String generateSimpleNumber(){
        Long na =  System.nanoTime();
        StringBuilder orderNumber = new StringBuilder();
        orderNumber.append(na);
        Random random = new Random();
        for (int i = 0; i < 4; i++) {
            orderNumber.append(random.nextInt(10));
        }
        return orderNumber.toString();
    }



    public static void main(String[] args) {
        String orderNumber = OrderNumberUtils.generateSimpleNumber();
        System.out.println("生成的订单号: " + orderNumber);
    }
}