package com.ly.exception;

/**
 * packageName.className com.ly.exception.UnallowedIPException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description TODO
 */
public class UnallowedIPException extends RuntimeException{

    public UnallowedIPException(String message) {
        super(message);
    }

    public UnallowedIPException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnallowedIPException(Throwable cause) {
        super(cause);
    }
}
