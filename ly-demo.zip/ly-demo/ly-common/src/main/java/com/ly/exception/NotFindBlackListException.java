package com.ly.exception;

/**
 * packageName.className com.ly.exception.NotFindBlackListException
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description
 */
public class NotFindBlackListException extends RuntimeException{

    public NotFindBlackListException(String message) {
        super(message);
    }

    public NotFindBlackListException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotFindBlackListException(Throwable cause) {
        super(cause);
    }
}
