package com.ly.config;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.*;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.transaction.TransactionException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * packageName.className com.ly.exception.ControllerExceptionHandler
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-12 15:28
 * @description TODO
 */
@ControllerAdvice(annotations = Controller.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class ControllerExceptionHandler {

    /**
     *  黑名单未找到
     */
    @ExceptionHandler(NotFindBlackListException.class)
    @ResponseBody
    public R handleOrderExistException(Exception e, HttpServletResponse response) {
        log.error("NotFindBlackListException:",e);
        return R.fail(ResultCode.REQ_REJECT);
    }
    /**
     *  简单身份验证
     */
    @ExceptionHandler(NotFindIDCheckException.class)
    @ResponseBody
    public R handleNotFindIDCheckException(Exception e, HttpServletResponse response) {
        log.error("NotFindIDCheckException:",e);
        return R.fail(ResultCode.UN_AUTHORIZED);
    }


    /**
     *  ip地址不允许访问
     */
    @ExceptionHandler(UnallowedIPException.class)
    @ResponseBody
    public R handleUnAllowedIPException(Exception e, HttpServletResponse response) {
        log.error("UnAllowedIPException:",e);
        return R.fail(ResultCode.REQ_REJECT);
    }



    /**
     * 业务异常
     */
    @ExceptionHandler(BusinessException.class)
    @ResponseBody
    public R handleBusinessException(Exception e, HttpServletResponse response) {
        log.error("BusinessException:",e);
        return R.fail(ResultCode.FAILURE);
    }

    /**
     *  事务
     */
    @ExceptionHandler({TransactionException.class})
    @ResponseBody
    public R handleTransactionException(Exception e, HttpServletResponse response) {
        log.error("TransactionException:",e);
        return R.fail(ResultCode.INTERNAL_SERVER_ERROR);
    }

    /**
     *  数据库访问异常
     */
    @ExceptionHandler(DataAccessException.class)
    @ResponseBody
    public R handleDataAccessException(Exception e) {
        log.error("DataAccessException:",e);
        return R.fail(ResultCode.INTERNAL_SERVER_ERROR);
    }

    /**
     *  数据库访问异常
     */
    @ExceptionHandler(ServiceException.class)
    @ResponseBody
    public R handleServiceException(ServiceException e) {
        log.error("ServiceException:",e);
        return R.fail(e.getResultCode());
    }

    /**
     * 未知异常
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public R handleException(Exception e) {
        log.error("Exception:", e);
        return R.fail(ResultCode.INTERNAL_SERVER_ERROR);

    }

}
