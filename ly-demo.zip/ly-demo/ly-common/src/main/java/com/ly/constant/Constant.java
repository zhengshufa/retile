package com.ly.constant;

import lombok.Data;

/**
 * @Author sean
 * @Date 2024/12/18 15:07
 * @desc constant
 */
@Data
public class Constant {

    public static final String COMPUTING_ACCOUNT = ":computing_account";

    public static final String COMPUTING_ACCOUNT_DETAIL = ":computing_account_detail";

    public static final String MEMBER_ACCOUNT = ":member_account";

    public static final String SYNC_ORDER = ":sync_order";

    public static final String MEMBER_CONFIG = ":member_config";

    public static final String MEMBER_PARTNER = "member_partner";

    public static final String MEMBER_OPERATOR = "mo";

    public static final String COMPUTING_OPERATOR = "sl";

    public static final Long COMPANY_REFERRED_CODE = 8888888888L;

    public static final String MEMBER_EXPIRE_TOPIC = "memberExpire";

    public static final String REFERRAL_CODE_POOL_KEY = "referral_code_pool";

}
