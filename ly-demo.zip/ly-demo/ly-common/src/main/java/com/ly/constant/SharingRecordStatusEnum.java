package com.ly.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author sean
 * @Date 2024/12/17 09:23
 * @desc 分佣状态枚举
 */
@Getter
@AllArgsConstructor
public enum SharingRecordStatusEnum {

    NO(0,"未分佣"),
    YES(1,"已分佣"),
    FAIL(2,"分佣失败"),
    ;

    /**
     * code编码
     */
    final int code;
    /**
     * 中文信息描述
     */
    final String message;

}
