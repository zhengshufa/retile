
package com.ly.utils;


import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.JSON;
import com.ly.domain.api.ResultCode;
import com.ly.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.Map;


@Slf4j
public class HttpUtils {

    /**
     * 发送POST请求
     *
     * @param urlStr  请求的URL地址
     * @param paramMap   POST请求的参数，格式如 "param1=value1&param2=value2"
     * @param sign   签名
     * @return 服务器响应的内容
     */
    public static String sendPost(String urlStr, Map<String,Object> paramMap, String sign,String appId,String requestId) {
        StringBuilder response = new StringBuilder();
        try {
            // 创建 URL 对象
            URL obj = new URL(urlStr);
            // 打开连接
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            // 设置请求方法为 POST
            con.setRequestMethod("POST");
            // 设置请求头
            con.setRequestProperty("Content-Type", "application/json"); // 设置请求体类型为 JSON
            con.setRequestProperty("Accept", "application/json"); // 设置响应体类型为 JSON
            con.setRequestProperty("X-Request-ID",requestId );  // 设置请求唯一id
            con.setRequestProperty("appId",appId);          //设置appId
            con.setRequestProperty("sign",sign);            //签名
            // 启用输入输出流
            con.setDoOutput(true);
            // 写入请求体
            try (OutputStream os = con.getOutputStream()) {
                byte[] input = JSON.toJSONString(paramMap, SerializerFeature.WriteMapNullValue).getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
            // 读取响应数据
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                log.info("Response: {}", response);
            }
            // 关闭连接
            con.disconnect();
        } catch (IOException e) {
            log.error("request process error, url={},params={},sign={},appId={},requestId={}",urlStr,paramMap,sign,appId,requestId,e);
            throw new BusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }

        return response.toString();
    }

    public static String sendGetRequest(String requestUrl) throws Exception {
        URL url = new URL(requestUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return response.toString();
    }

    public static void trustAllCertificates() {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                }
        };

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = (hostname, session) -> true;

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }
}