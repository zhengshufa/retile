//package com.ly.gateway.filter;
//
//import com.alibaba.fastjson.JSON;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.ly.gateway.domain.R;
//import com.ly.gateway.domain.ResultCode;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.cloud.gateway.filter.GatewayFilterChain;
//import org.springframework.cloud.gateway.filter.GlobalFilter;
//import org.springframework.core.io.buffer.DataBufferUtils;
//import org.springframework.http.server.reactive.ServerHttpRequest;
//import org.springframework.http.server.reactive.ServerHttpResponse;
//import org.springframework.stereotype.Component;
//import org.springframework.web.server.ServerWebExchange;
//import reactor.core.publisher.Mono;
//import utils.signatureUtil.RsaUtil;
//
//import java.nio.charset.StandardCharsets;
//import java.util.HashMap;
//import java.util.Map;
//
//@Slf4j
////@Component
//public class RequestLoggingGlobalFilter implements GlobalFilter {
//
//
//
//    @Override
//    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
//        // 获取请求头中的 sign
//        String sign = exchange.getRequest().getHeaders().getFirst("sign");
//
//        String appId = exchange.getRequest().getHeaders().getFirst("appId");
//
//        if (sign == null || sign.isEmpty()) {
//            return sendErrorResponse(exchange, new HashMap<>(), ResultCode.PARAM_MISS);
//        }
//        if (appId == null || appId.isEmpty()) {
//            return sendErrorResponse(exchange, new HashMap<>(), ResultCode.PARAM_MISS);
//        }
//
//        // 获取请求体中的所有参数
//        return exchange.getRequest().getBody()
//                .collectList()  // 收集所有请求体数据
//                .flatMap(dataBuffers -> {
//                    String bodyContent = dataBuffers.stream()
//                            .map(dataBuffer -> {
//                                String body = StandardCharsets.UTF_8.decode(dataBuffer.asByteBuffer()).toString();
//                                // 使用 DataBufferUtils 来释放资源
//                                DataBufferUtils.release(dataBuffer);
//                                return body;
//                            })
//                            .reduce("", String::concat);
//
//                    // 将请求体转换为 JSON
//                    ObjectMapper objectMapper = new ObjectMapper();
//                    JsonNode requestBodyJson;
//                    try {
//                        log.debug("Request body content: {}", bodyContent);
//                        requestBodyJson = objectMapper.readTree(bodyContent);
//                        // 将请求体中的所有参数转换为 Map
//                        Map<String, String> requestParams = new HashMap<>();
//                        requestBodyJson.fields().forEachRemaining(field -> requestParams.put(field.getKey(), field.getValue().asText()));
//
//                        // 获取请求体的参数和 sign 进行校验
//                        if(generateSign(sign,requestParams)){
//                            // 校验通过，继续处理请求
//                            ServerHttpRequest mutatedRequest = exchange.getRequest().mutate()
//                                    .build();
//                            // 将 mutatedRequest 传递给后续过滤器
//                            return chain.filter(exchange.mutate().request(mutatedRequest).build());
//                        } else {
//                            // 校验失败，返回统一错误响应
//                            return sendErrorResponse(exchange, requestParams,ResultCode.UN_AUTHORIZED);
//                        }
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                        log.error("Failed to parse request body: {}", bodyContent, e);
//                        return sendErrorResponse(exchange, new HashMap<>(),ResultCode.INTERNAL_SERVER_ERROR);
//                    }
//                });
//    }
//
//    // 生成签名的逻辑（示例，使用请求参数和密钥生成签名）
//    private Boolean generateSign(String sign,Map<String, String> requestParams) throws Exception {
//        // 假设签名规则是：将所有参数按键排序，并拼接成字符串再加密
//        StringBuilder sb = new StringBuilder();
//        requestParams.forEach((key, value) -> sb.append(key).append("=").append(value).append("&"));
//        return RsaUtil.verifyAndDecode(sign, sb.toString());
//        // 这里可以使用加密算法，比如 MD5 或 SHA256
//    }
//
//    // 返回统一的错误响应
//    private Mono<Void> sendErrorResponse(ServerWebExchange exchange, Map<String, String> requestParams,ResultCode code) {
//        ServerHttpResponse response = exchange.getResponse();
//        ServerHttpRequest request = exchange.getRequest();
//        R<String> r = new R<>();
//        R.fail(code);
//        log.info("filter not allow,method={},URI={},params={},errorCode={},errorMsg={}",request.getMethod(),request.getURI().getPath(),JSON.toJSONString(requestParams),code.getCode(),code.getMessage());
//        return response.writeWith(Mono.just(response.bufferFactory().wrap(JSON.toJSONBytes(r))));
//    }
//
//
//
//
//}