
package com.ly.gateway.config;

import com.alibaba.fastjson.JSON;
import com.ly.gateway.api.R;
import com.ly.gateway.api.ResultCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebExceptionHandler;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;

/**
 * @Author sean
 * @Date 2025/1/10 14:40
 * @desc
 */
@Order(-1)
@Configuration
@Slf4j
public class GatewayErrorConfig implements WebExceptionHandler {

    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {
        log.info("CustomErrorWebExceptionHandler.handle called with exception: {}", ex.getClass().getName());
        log.error("Exception details:", ex);

        // 设置响应状态码为 200
        exchange.getResponse().setStatusCode(HttpStatus.OK);

        // 设置响应体，返回自定义错误消息
        exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
        String errorResponse = JSON.toJSONString(R.fail(ResultCode.INTERNAL_SERVER_ERROR, ex.getMessage()));

        byte[] bytes = errorResponse.getBytes(StandardCharsets.UTF_8);
        return exchange.getResponse().writeWith(Mono.just(exchange.getResponse().bufferFactory().wrap(bytes)));
    }
}