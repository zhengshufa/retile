package com.ly.gateway.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * packageName.className com.ly.gateway.controller.HealthController
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-27 13:03
 * @description TODO
 */
@RestController
@RequestMapping("health")
@Slf4j
public class HealthController {


    @GetMapping
    public String health(){
        return "success";
    }


}