create table business_log
(
    id                   bigint auto_increment comment '主键 ID'
        primary key,
    request_id           varchar(64)                        null comment '唯一请求标识，用于追踪请求',
    app_id               varchar(128)                       null comment '第三方服务id',
    endpoint             varchar(256)                       null comment '请求的接口地址',
    http_method          varchar(20)                        null comment 'HTTP 请求方法',
    request_payload      text                               null comment '请求报文内容',
    request_header       text                               null comment '请求头数据',
    response_payload     text                               null comment '响应报文内容',
    response_status_code int                                null comment 'HTTP 响应状态码',
    business_status_code varchar(32)                        null comment '业务状态码，如自定义错误码',
    business_message     varchar(256)                       null comment '业务处理结果信息',
    process_start_time   datetime                           null comment '处理开始时间',
    process_end_time     datetime                           null comment '处理结束时间',
    elapsed_time_ms      bigint                             null comment '请求处理耗时（毫秒）',
    ip_address           varchar(64)                        null comment '第三方服务的 IP 地址',
    error_stack          text                               null comment '错误堆栈信息（如果有）',
    create_time          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time          datetime default CURRENT_TIMESTAMP not null comment '更新时间',
    status               int      default 0                 not null comment '状态',
    is_deleted           int      default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '第三方请求和业务处理日志表';

create table computing_account
(
    id               bigint auto_increment comment '主键id'
        primary key,
    member_id        bigint                                   not null comment '会员id',
    referral_code    varchar(100)                             not null comment '推荐码',
    amount           decimal(16, 2) default 0.00              not null comment '总额',
    available_amount decimal(16, 2) default 0.00              not null comment '可用余额',
    freeze_amount    decimal(16, 2) default 0.00              not null comment '冻结金额',
    create_time      datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time      datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status           int            default 0                 not null comment '状态',
    is_deleted       int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '算力账号表';

create table computing_account_detail
(
    id             bigint auto_increment comment '主键id'
        primary key,
    member_id      bigint                                   not null comment '会员id',
    referral_code  varchar(100)                             not null comment '推荐码',
    operation_no   varchar(200)                             not null comment '操作单号',
    operation_type int                                      not null comment '操作类型（1-充值，2-任务，3-课程观看，4-AI经纪人，5-数字主播视频，6-AI经纪人模型）',
    amount         decimal(16, 2) default 0.00              not null comment '金额',
    pay_amount     decimal(16, 2) default 0.00              not null comment '支付金额',
    bill_no        varchar(200)                             null comment '第三方订单号（支付的情况下才有）',
    remake         varchar(200)   default ''                not null comment '备注',
    create_time    datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time    datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status         int            default 0                 not null comment '状态(0-正常支付单，1-冻结支付单，2-取消支付单)',
    is_deleted     int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '算力账号操作详情';

create table member
(
    id              bigint auto_increment comment '主键'
        primary key,
    email           varchar(100) charset utf8mb4       not null comment '邮箱',
    user_id         bigint                             null comment '用户id',
    nickname        varchar(200) charset utf8mb4       null comment '用户昵称',
    anchor_auth     int      default 0                 null comment '主播认证（0-不是，1-是）',
    referral_code   varchar(100) charset utf8mb4       not null comment '推荐码',
    referral_type   int      default 0                 not null comment '推荐码类型（0-普通，1-特殊）',
    ten_generations int      default 0                 not null comment '',
    is_member       int      default 0                 not null comment '是否会员（0-否，1-是）',
    open_type       int      default 0                 not null comment '开通类型（0-未开通（未激活），1-开通，2-续费，3-过期）',
    first_open_time datetime                           null comment '首次开通时间',
    expire_time     datetime                           null comment '过期时间',
    referral_id     bigint                             not null comment '推荐人id',
    transfer_mark   datetime                           null comment '转让时间',
    create_time     datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time     datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    status          int      default 1                 not null comment '状态',
    is_deleted      int      default 0                 not null comment '是否删除（0-未删除，1-已删除）'
)
    comment '会员表';

create table member_account
(
    id                       bigint auto_increment comment '主键id'
        primary key,
    member_id                bigint                                   not null comment '会员id',
    referral_code            varchar(100)                             not null comment '推荐码',
    amount                   decimal(16, 2) default 0.00              not null comment '总金额（总佣金）',
    available_amount         decimal(16, 2) default 0.00              not null comment '可用余额',
    withdrawal_amount        decimal(16, 2) default 0.00              not null comment '已提现金额',
    freeze_amount            decimal(16, 2) default 0.00              not null comment '冻结分佣金额',
    withdrawal_freeze_amount decimal(16, 2) default 0.00              not null comment '提现冻结金额（发起提现的时候使用）',
    unavailable_amount       decimal(16, 2) default 0.00              not null comment '不可用金额',
    create_time              datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time              datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status                   int            default 0                 not null comment '状态',
    is_deleted               int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '会员账号表';

create table member_account_detail
(
    id              bigint auto_increment comment '主键id'
        primary key,
    member_id       bigint                                   not null comment '会员id',
    referral_code   varchar(100)                             not null comment '推荐码',
    operation_no    varchar(200)                             not null comment '操作单号',
    operation_type  int                                      not null comment '操作类型（1-分佣，2-提现，3-支付）',
    amount          decimal(16, 2) default 0.00              not null comment '金额',
    bill_no         varchar(200)                             null comment '第三方订单号（提现和支付的情况下才有）',
    refund_track_no varchar(200)                             null comment '退款关联单号（仅在退款的时候有值，对应的是第三方单号）',
    create_time     datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time     datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status          int            default 0                 not null comment '状态',
    remake          varchar(100)   default ''                not null comment '备注',
    is_deleted      int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '会员账号操作详情';

create table member_account_withdraw
(
    id            bigint auto_increment comment '主键id'
        primary key,
    member_id     bigint                                   not null comment '会员id',
    referral_code varchar(100)                             not null comment '推荐码',
    amount        decimal(16, 2) default 0.00              not null comment '金额',
    operation_no  varchar(200)                             not null comment '操作单号',
    create_time   datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time   datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status        int            default 0                 not null comment '状态（0-未提现，1-已提现）',
    is_deleted    int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '会员账号提现审核表';

create table member_config
(
    id                       bigint auto_increment comment '主键id'
        primary key,
    sharing_time             int                          default 7                       not null comment '分佣时限配置(天)',
    member_expire_time       int                          default 15                      not null comment '会员过期分佣时限配置项（单位：天。该时间内过期会将分佣金额放到分佣冻结金额里，该时间外过期会将分佣金额放到不可用金额里）',
    sharing_proportion       varchar(100)                 default '30,5,5,5,5,5,5,5,5,5'  not null comment '个人分佣比例，从直系上级开始往上',
    tv_sharing_proportion    varchar(100) charset utf8mb4 default '5,6,1,1,1,1,1,1,1,1,1' not null comment '额外主播收入个人分佣比例，从直系上级开始往上(本人1级，然后往上10级)',
    tv_sharing_amount        decimal(16, 2)               default 50.00                   not null comment '额外主播收入分佣必须大于设定的美金',
    renew_sharing_proportion varchar(100)                 default '3,1,1,1,1,1,1,1,1,1'   null comment '额外主播收入个人分佣佣金，从直系上级开始往上(本人1级，然后往上10级)',
    ai_broker_msg_fee        varchar(50)                  default '10,20'                 not null comment 'AI经纪人消息发送价格(前面的是会员价格，后面的是非会员价格)',
    create_time              datetime                     default CURRENT_TIMESTAMP       not null comment '创建时间',
    update_time              datetime                     default CURRENT_TIMESTAMP       not null comment '更新时间',
    status                   int                          default 1                       not null comment '状态',
    is_deleted               int                          default 0                       not null comment '是否删除（0-未删除，1-已删除）'
)
    comment '配置表';

create table partner
(
    id           bigint auto_increment comment '主键'
        primary key,
    partner_name varchar(32)                        null comment '合作商/业务线名称',
    partner_code varchar(32)                        null comment '合作商/业务线编号',
    public_key   varchar(512)                       null comment '接入业务的公钥',
    create_time  datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    status       int      default 1                 not null comment '状态',
    is_deleted   int      default 0                 not null comment '是否删除（0-未删除，1-已删除）'
);

create table referral_code
(
    id          bigint auto_increment comment '主键（推荐码）'
        primary key,
    create_time datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time datetime default CURRENT_TIMESTAMP not null comment '更新时间',
    status      int      default 0                 not null comment '状态',
    is_deleted  int      default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '推荐码生成表';

create table sharing_record
(
    id                        bigint auto_increment comment '主键'
        primary key,
    source_member_id          bigint                                   not null comment '来源方的会员id',
    source_referral_code      varchar(100)                             not null comment '来源方的推荐码',
    beneficiary_member_id     bigint                                   not null comment '受益方的会员id',
    beneficiary_referral_code varchar(100)                             not null comment '收益方的推荐码',
    amount                    decimal(16, 2) default 0.00              not null comment '金额',
    bill_no                   varchar(200)                             not null comment '订单编号（支付单编号）',
    bill_type                 int            default 0                 not null comment '订单类型',
    status                    int            default 0                 not null comment '分佣状态（0-未分佣，1-已分佣）',
    create_time               datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time               datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    is_deleted                int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '分佣记录';

create table sync_order
(
    id                              bigint auto_increment comment '主键id'
        primary key,
    referral_code                   varchar(100)                             not null comment '推荐码',
    operation_type                  int                                      not null comment '操作类型',
    amount                          decimal(16, 2) default 0.00              not null comment '金额',
    bill_no                         varchar(200)                             null comment '第三方订单号',
    sharing_amount                  decimal(16, 2) default 0.00              null comment '分佣金额',
    non_sharing_amount              decimal(16, 2) default 0.00              null comment '无需分佣金额',
    sharing_generation              int                                      null comment '分佣代数',
    sharing_first_generation_amount decimal(16, 2) default 0.00              null comment '初代分润金额',
    create_time                     datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time                     datetime       default CURRENT_TIMESTAMP not null comment '更新时间',
    status                          int            default 0                 not null comment '状态（0-未分佣，1-已分佣）',
    remake                          varchar(100)   default ''                not null comment '备注',
    is_deleted                      int            default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '同步订单表（vst订单）';

create table team_count
(
    referral_code varchar(200)                       not null comment '推荐码'
        primary key,
    team_count    int      default 0                 not null comment '团队数量',
    status        int      default 0                 not null comment '状态',
    create_time   datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time   datetime default CURRENT_TIMESTAMP not null comment '更新时间',
    is_deleted    int      default 0                 not null comment '是否已删除（0-未删除，1-已删除）'
)
    comment '团队数量统计';

create table team_invite_count
(
    referral_code varchar(200)                       not null comment '推荐码',
    count         int      default 0                 not null comment '数量',
    date          datetime                           not null comment '日期',
    status        int      default 0                 not null comment '状态',
    create_time   datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time   datetime default CURRENT_TIMESTAMP not null comment '更新时间',
    is_deleted    int      default 0                 not null comment '是否已删除（0-未删除，1-已删除）',
    constraint unique_fields
        unique (referral_code, date)
)
    comment '团队邀请数量统计（天）';


# 分佣配置
INSERT INTO vst_member.member_config (id, sharing_time, member_expire_time, ai_broker_msg_fee, create_time, update_time, status, is_deleted) VALUES (1, -1, 15, '10,20', '2024-12-27 10:20:39', '2024-12-27 10:20:39', 1, 0);
# 合作appId配置
INSERT INTO vst_member.partner (id, partner_name, partner_code, public_key, create_time, update_time, status, is_deleted) VALUES (1, 'VST', 'E10ADC3949BA59ABBE56E057F20F883E', 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCyWm+4D/uI/VJrVpC8NZMvNAKEd/PPqEBIhji2cMqialWAmKmkH/dd9GdaVwXN7B6O3vUragTZylSzSRh9+Pks0gr81vCX0NCcI7LCIodKLB5Je0wBlWQPbhhYkp3Ro66kANVKJwb1aL3rv2kN2Yke1XXM8/6/BQ5gR9dQTqoe5wIDAQAB', '2024-12-27 16:57:11', '2024-12-27 16:57:11', 1, 0);
INSERT INTO vst_member.partner (id, partner_name, partner_code, public_key, create_time, update_time, status, is_deleted) VALUES (2, 'AI', 'E10ADC3949BA59ABBE56E057F20F883F', 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCJF4XCCqWJuv1xNFySC5qItlCjHs0nZIVV6rGTbnHd1y5mldzvWk/AhcHfGONMiiyv6XKldRkhn8j+NmAbY5jLkYnxobKIDSPHMQXU9iqsnl4j/WgcGUAN53+hnYd/9xmmZZlsRTHJrmfo3vr0Lgb1QgjeF6ayo8UGpbgnAH5mwwIDAQAB', '2024-12-30 11:59:02', '2024-12-30 11:59:02', 1, 0);
INSERT INTO vst_member.partner (id, partner_name, partner_code, public_key, create_time, update_time, status, is_deleted) VALUES (3, 'PAY', '786DD087BA329A75D69CA775AFDB2051', 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCJCpKM6ayKqtQEWyri+ahbB7MWDdZbaB680QIbz7fydqnniFRPrl0WhJU6vWacv6KiPzF7EwQCCoxrzkbkl7zDPM27/xwXHyLRpmUnxvuYFUM1IwzZFpL+n/mH1DDOdQstxxXZg6ryJPNfW80fNJVPLvhtZljfHThIxbYq82nmbwIDAQAB', '2024-12-30 18:42:18', '2024-12-31 11:31:09', 1, 0);
# 公司节点预设
INSERT INTO vst_member.member (id, email, user_id, nickname, referral_code, referral_type, ten_generations, is_member, open_type, first_open_time, expire_time, referral_id, transfer_mark, create_time, update_time, status, is_deleted) VALUES (1, 'ly@gmain.com', 0, '龙予', '8888888888', 0, 0, 0, 0, null, null, 0, null, '2024-12-12 15:23:32', '2025-01-06 12:55:03', 1, 0);

create index referral_code_index
    on computing_account (referral_code);

create index referral_code_index
    on computing_account_detail (referral_code);

create index referral_code_index
    on member (referral_code);

create index referral_code_index
    on member_account (referral_code);

create index referral_code_index
    on member_account_detail (referral_code);

create index beneficiary_referral_code__index
    on sharing_record (beneficiary_referral_code);

create index source_referral_code_index
    on sharing_record (source_referral_code);

create index create_time_index
    on sync_order (create_time);

create index referral_code_index
    on sync_order (referral_code);

alter table team_count
    add constraint referral_code_index
        unique (referral_code);

