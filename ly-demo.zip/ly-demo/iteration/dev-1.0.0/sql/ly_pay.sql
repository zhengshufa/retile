/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.30 : Database - vst_pay
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`vst_pay` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `vst_pay`;

/*Table structure for table `vst_cash_out` */

DROP TABLE IF EXISTS `vst_cash_out`;

CREATE TABLE `vst_cash_out` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` BIGINT DEFAULT NULL COMMENT '用户id',
  `partner_no` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务线业务编号',
  `request_order_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求订单号',
  `callback_url` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通知地址',
  `pay_order_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付系统订单号',
  `amount` DECIMAL(16,2) DEFAULT NULL COMMENT '提现金额',
  `currency` VARCHAR(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '币种',
  `bank_card_no` VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行卡',
  `status` INT DEFAULT NULL COMMENT '状态 0-默认 1-提现中 2-提现成功 3-提现失败 4-已退回',
  `client_ip` VARCHAR(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户端ip地址',
  `ext_params` VARCHAR(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '扩展参数',
  `remark` VARCHAR(3000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vst_cash_out` */

/*Table structure for table `vst_merchant` */

DROP TABLE IF EXISTS `vst_merchant`;

CREATE TABLE `vst_merchant` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `merchant_name` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户名称',
  `merchant_code` VARCHAR(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户编码',
  `merchant_desc` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户描述',
  `merchant_invoke_url` VARCHAR(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求地址',
  `merchant_query_url` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '查询地址',
  `token` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求使用的token',
  `status` INT DEFAULT '0' COMMENT '状态 默认0正常',
  `is_deleted` INT DEFAULT '0' COMMENT '是否删除0-未删除 1-删除',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vst_merchant` */

INSERT  INTO `vst_merchant`(`id`,`merchant_name`,`merchant_code`,`merchant_desc`,`merchant_invoke_url`,`merchant_query_url`,`token`,`status`,`is_deleted`,`create_time`,`update_time`) VALUES
(1,'nihao_wechatPay','1001','wechat pay of nihao pay ','https://apitest.nihaopay.com/v1.2/transactions/securepay','','53a594c6b1e7d535884beadc8eb959c596472a7d3204e632d3186027fad66dbb',0,0,'2024-12-18 11:18:00','2024-12-27 16:22:24'),
(2,'nihao_alipay','1002','alipay of nihao pay ','https://apitest.nihaopay.com/v1.2/transactions/securepay','','53a594c6b1e7d535884beadc8eb959c596472a7d3204e632d3186027fad66dbb',0,0,'2024-12-18 11:18:14','2024-12-27 16:22:21'),
(3,'nihao_unionPay','1003','unionPay of nihao pay ','https://apitest.nihaopay.com/v1.2/transactions/securepay','','53a594c6b1e7d535884beadc8eb959c596472a7d3204e632d3186027fad66dbb',0,0,'2024-12-18 11:18:29','2024-12-27 16:22:20'),
(4,'nihao_paypal','1004','paypal of nihao pay ','https://apitest.nihaopay.com/v1.2/transactions/securepay','','53a594c6b1e7d535884beadc8eb959c596472a7d3204e632d3186027fad66dbb',0,0,'2024-12-18 11:18:40','2024-12-20 10:11:01'),
(5,'stripe_bank_card','1005','bank card of stripe',NULL,NULL,NULL,0,0,'2024-12-24 14:04:54','2024-12-24 14:07:39');

/*Table structure for table `vst_partner` */

DROP TABLE IF EXISTS `vst_partner`;

CREATE TABLE `vst_partner` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `partner_name` VARCHAR(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '合作商/业务线名称',
  `partner_code` VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '合作商/业务线编号',
  `partner_token` VARCHAR(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pay生成的token',
  `public_key` VARCHAR(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接入业务的公钥',
  `callbcak_url` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '对调地址，可为空',
  `status` INT DEFAULT '0' COMMENT '状态 默认为0',
  `is_deleted` INT DEFAULT '0' COMMENT '默认0-正常 1-删除',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vst_partner` */

INSERT  INTO `vst_partner`(`id`,`partner_name`,`partner_code`,`partner_token`,`public_key`,`callbcak_url`,`status`,`is_deleted`,`create_time`,`update_time`) VALUES
(1,'vst_11','1001','E10ADC3949BA59ABBE56E057F20F883E','MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCyWm+4D/uI/VJrVpC8NZMvNAKEd/PPqEBIhji2cMqialWAmKmkH/dd9GdaVwXN7B6O3vUragTZylSzSRh9+Pks0gr81vCX0NCcI7LCIodKLB5Je0wBlWQPbhhYkp3Ro66kANVKJwb1aL3rv2kN2Yke1XXM8/6/BQ5gR9dQTqoe5wIDAQAB','1',0,0,'2024-12-17 11:19:29','2024-12-19 17:49:18');

/*Table structure for table `vst_partner_merchant` */

DROP TABLE IF EXISTS `vst_partner_merchant`;

CREATE TABLE `vst_partner_merchant` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `partner_code` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务方编码',
  `merchant_code` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付厂商编码',
  `vendor` INT DEFAULT NULL COMMENT '现金支付的渠道 1-微信 2-支付宝 3-银联 4-paypal 5-Visa 6-Master',
  `diversion_ratio` INT DEFAULT NULL COMMENT '分流比例0-100',
  `status` INT DEFAULT '0' COMMENT '状态：默认0 0-开启 1-关闭',
  `is_deleted` INT DEFAULT '0' COMMENT '是否删除默认0 -未删除 1-删除',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_partner_vendor` (`partner_code`,`vendor`)
) ENGINE=INNODB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vst_partner_merchant` */

INSERT  INTO `vst_partner_merchant`(`id`,`partner_code`,`merchant_code`,`vendor`,`diversion_ratio`,`status`,`is_deleted`,`create_time`,`update_time`) VALUES
(1,'1001','1001',1,100,0,0,'2024-12-19 11:38:30','2024-12-19 11:47:19'),
(2,'1001','1002',2,100,0,0,'2024-12-19 11:41:15','2024-12-19 11:47:23'),
(3,'1001','1003',3,100,0,0,'2024-12-19 11:45:41','2024-12-19 11:47:35'),
(4,'1001','1004',4,100,0,0,'2024-12-19 11:48:29','2024-12-19 11:48:29'),
(5,'1001','1005',5,100,0,0,'2024-12-24 14:06:33','2024-12-24 14:06:33');

/*Table structure for table `vst_pay_order` */

DROP TABLE IF EXISTS `vst_pay_order`;

CREATE TABLE `vst_pay_order` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT DEFAULT NULL COMMENT '用户id',
  `pay_order_no` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付订单号',
  `partner_order_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务方订单号',
  `partner_callback_url` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务方回调地址',
  `redirect_url` VARCHAR(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '页面重定向地址',
  `merchant_order_no` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户订单号',
  `partner_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务方编号',
  `merchant_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户id',
  `pay_type` INT DEFAULT NULL COMMENT '1-余额支付 2-算力支付 3-现金支付',
  `vendor` INT DEFAULT NULL COMMENT '现金支付的回复方式1-微信 2-支付宝 3-银联 4-paypal',
  `amount` DECIMAL(16,2) DEFAULT '0.00' COMMENT '单价',
  `count` INT DEFAULT NULL COMMENT '数量',
  `total_amount` DECIMAL(16,2) DEFAULT NULL COMMENT '总价',
  `currency` VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '币种',
  `title` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付标题',
  `note` VARCHAR(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `extend_params` VARCHAR(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '扩展字段',
  `os_type` INT DEFAULT NULL COMMENT '1-ANDROID 2-IOS 3-wap 4-pc',
  `timeout` INT DEFAULT NULL COMMENT '订单超时时间',
  `status` INT DEFAULT '0' COMMENT '默认0-创建订单 1-支付中 2-支付成功 3-支付失败 4-已退款',
  `is_deleted` INT DEFAULT '0' COMMENT '0-默认 1-删除',
  `remark` VARCHAR(3000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_partner_order_no` (`partner_order_no`,`partner_no`),
  KEY `idx_pay_order` (`pay_order_no`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=INNODB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `vst_pay_task`;

CREATE TABLE `vst_pay_task` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增',
  `pay_order_no` VARCHAR(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '支付订单号',
  `next_process_time` DATETIME DEFAULT NULL COMMENT '下次执行时间',
  `process_times` INT DEFAULT '0' COMMENT '处理次数',
  `busi_type` INT DEFAULT NULL COMMENT '1-支付,2-提现',
  `status` INT DEFAULT '0' COMMENT '0-待执行 1-执行成功 3-执行失败',
  `is_deleted` INT DEFAULT '0' COMMENT '是否删除 0默认 1删除',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_` (`next_process_time`,`status`)
) ENGINE=INNODB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vst_pay_task` */

INSERT  INTO `vst_pay_task`(`id`,`pay_order_no`,`next_process_time`,`process_times`,`busi_type`,`status`,`is_deleted`,`create_time`,`update_time`) VALUES
(1,'202412311746268390109375','2024-12-31 09:49:16',1,1,0,0,'2024-12-31 17:48:19','2024-12-31 17:48:19'),
(2,'202412311746268390109375','2024-12-31 09:49:28',1,1,0,0,'2024-12-31 17:48:29','2024-12-31 17:48:29'),
(3,'202412311758213390105857','2024-12-31 10:06:21',1,1,0,0,'2024-12-31 18:05:23','2024-12-31 18:05:23'),
(4,'202412311758213390105857','2024-12-31 10:08:01',1,1,0,0,'2024-12-31 18:07:02','2024-12-31 18:07:02'),
(5,'202412311818537400102560','2024-12-31 10:22:39',1,1,0,0,'2024-12-31 18:21:40','2024-12-31 18:21:40');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
