package com.ly.pay.service;

import com.ly.pay.entity.Merchant;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-12-18 16：54：49
 */
public interface IMerchantService extends IService<Merchant> {


    Merchant findByCode(String code);
}
