package com.ly.pay.service;

import com.ly.pay.entity.PayTask;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public interface IPayTaskService extends IService<PayTask> {


    /**
     * 根据下次查询时间查询
     * @return
     */
    List<PayTask> queryByNextTime(Integer busiType);

}
