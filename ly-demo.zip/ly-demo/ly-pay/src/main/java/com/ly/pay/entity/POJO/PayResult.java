package com.ly.pay.entity.POJO;

import lombok.Data;

/**
 * packageName.className com.ly.pay.entity.POJO.PayOderPOJO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 14:36
 * @description TODO
 */
@Data
public class PayResult {

    private String orderInfo;

    private String redirectUrl;

}