package com.ly.pay.controller;

import com.ly.domain.api.R;
import com.ly.pay.common.enums.VendorEnum;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.DTO.PayWayDTO;
import com.ly.pay.entity.VO.PayOderVO;
import com.ly.pay.entity.VO.QueryOrderStatusVO;
import com.ly.pay.service.IPayService;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * packageName.className com.ly.pay.controller.PayController
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:59
 * @description niHaoPay通知回调类
 */
@RestController
@RequestMapping("pay")
@Schema(title = "支付相关接口类")
@Slf4j
public class PayController {


    @Autowired
    private IPayService payService;

    /**
     * <p>
     *  支付请求接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping("pay")
    public R<PayOrderDTO> pay(@RequestBody PayOderVO payRequestVO) {
        R<PayOrderDTO> r= payService.pay(payRequestVO);
        log.info("====>data={}",r.getData());
        return r;
    }


    /**
     * <p>
     * 支付方式查询接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @GetMapping("payWay")
    public R<List<PayWayDTO>> queryPayWay(@RequestParam  @Schema(description = "购买用户userId 必须")String accountId) {
        return payService.queryPayWay(accountId);
    }


    /**
     * <p>
     * 查询支付结果
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping("payStatus")
    public R<PayOrderDTO> queryPayStatus(QueryOrderStatusVO queryOrderStatusVO) {
        return payService.queryPayStatus(queryOrderStatusVO.getOrderNo());
    }



}

