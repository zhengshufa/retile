package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2024-12-23 16：27：30
 */
@Getter
@Setter
@TableName("vst_pay_task")
public class PayTask extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 支付订单号
     */
    private String payOrderNo;

    /**
     * 下次执行时间
     */
    private Date nextProcessTime;

    /**
     * 处理次数
     */
    private Integer processTimes;

    /**
     * 1-支付,2-提现
     */
    private Integer busiType;
}
