package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2025-01-21 09：34：59
 */
@Getter
@Setter
@TableName("vst_charge")
public class Charge extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 支付系统充值订单号
     */
    private String payChargeNo;

    /**
     * 业务方充值订单号
     */
    private String partnerChargeNo;

    /**
     * 业务方编号
     */
    private String partnerNo;

    /**
     * 支付厂商订单号
     */
    private String merchantChargeNo;

    /**
     * 支付厂商编号
     */
    private String merchantNo;

    /**
     * 会员系统订单号
     */
    private String memberChargeOrder;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 金额 最小单位：分
     */
    private BigDecimal amount;

    /**
     * 币种3位代码，如USD
     */
    private String currency;

    /**
     * 请求时间戳
     */
    private Long timestamp;

    /**
     * 支付标题
     */
    private String title;

    /**
     * 扩展参数 json
     */
    private String extParams;
}
