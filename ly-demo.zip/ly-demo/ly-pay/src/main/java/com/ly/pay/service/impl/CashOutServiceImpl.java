package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.distribute.DistributeLock;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.common.enums.CashOutOrderStatusEnum;
import com.ly.pay.common.utils.PartnerHolder;
import com.ly.pay.entity.CashOut;
import com.ly.pay.entity.DTO.CashOutDTO;
import com.ly.pay.entity.Partner;
import com.ly.pay.entity.VO.CashOutVO;
import com.ly.pay.entity.VO.CashQueryVO;
import com.ly.pay.mapper.CashOutMapper;
import com.ly.pay.mapstruct.CashOutDTOMapStruct;
import com.ly.pay.mapstruct.CashOutVOMapStruct;
import com.ly.pay.service.ICashOutService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.utils.OrderNumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-12-23 09：14：19
 */
@Slf4j
@Service
public class CashOutServiceImpl extends ServiceImpl<CashOutMapper, CashOut> implements ICashOutService {
    @Autowired
    private DistributeLock distributeLock;
    @Autowired
    private CashOutVOMapStruct cashOutVOMapStruct;
    @Autowired
    private CashOutDTOMapStruct cashOutDTOMapStruct;

    @Override
    public R<CashOutDTO> cashOut(CashOutVO cashOutVO) {

        //1、校验参数
        validParam(cashOutVO);
        //2、拼装参数
        Partner partner = PartnerHolder.getPartner();
        CashOut cashOut = cashOutVOMapStruct.toEntity(cashOutVO);
        cashOut.setRequestOrderNo(cashOutVO.getOrderNo());
        cashOut.setPartnerNo(partner.getPartnerCode());
        cashOut.setPayOrderNo(OrderNumberUtils.generateOrderNumber());
        cashOut.setStatus(CashOutOrderStatusEnum.WITHDRAWING.getCode());
        //TODO 没有接入第三方，这里直接改成成功 后期接了再加逻辑
        cashOut.setStatus(CashOutOrderStatusEnum.SUCCESS.getCode());
        //3、先查一次看是否存在
        CashOut cashOutInDB = queryByPartnerCodeAndPartnerOrderNo(cashOut.getPartnerNo(),cashOut.getRequestOrderNo());
        if(cashOutInDB!=null){
            log.error("order is exist!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
            return R.fail(ResultCode.PARTNER_PAY_ORDER_EXIST);
        }
        //4、锁定，处理业务
        String lockKey = cashOut.getRequestOrderNo()+cashOut.getPartnerNo();
        boolean isLock= false;
        try {
            isLock = distributeLock.tryLock(lockKey,1000);
            if(isLock){
                //5、再查一次，进行再次判断
                cashOutInDB = queryByPartnerCodeAndPartnerOrderNo(cashOut.getPartnerNo(),cashOut.getRequestOrderNo());
                if(cashOutInDB!=null){
                    log.error("order is exist!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
                    return R.fail(ResultCode.PARTNER_PAY_ORDER_EXIST);
                }
                this.save(cashOut);
                return R.data(cashOutDTOMapStruct.toDto(cashOut));
            }
        } catch (PayBusinessException e){
            log.error("{},userId={},orderNo={}",e.getResultCode().getMessage(), cashOutVO.getUserId(),cashOutVO.getOrderNo());
            return R.fail(e.getResultCode());
        }  finally{
            if(isLock){
                distributeLock.unlock(lockKey);
            }
        }
        return R.fail(ResultCode.PARTNER_PAY_ORDER_EXIST);
    }

    /**
     * 根据cod 和订单号查询
     * @param partnerCode 业务编号
     * @param partnerOrderNo 业务提现订单号
     * @return
     */
    private CashOut queryByPartnerCodeAndPartnerOrderNo(String partnerCode,String partnerOrderNo){
        LambdaQueryWrapper<CashOut> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(CashOut::getPartnerNo,partnerCode).eq(CashOut::getRequestOrderNo,partnerOrderNo);
        return this.getOne(lambdaQueryWrapper);
    }
    /**
     * 校验参数
     * @param cashOutVO 提现请求参数
     */
    private void validParam(CashOutVO cashOutVO) {
        if(cashOutVO == null){
            log.error("param cashOutVO is null!!!");
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }
        if(cashOutVO.getOrderNo() == null || cashOutVO.getUserId() == null){
            log.error("param orderNo or userId is null!!!");
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }
        if(cashOutVO.getClientIp() == null){
            log.error("param clientIp is null!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }
        if(cashOutVO.getCurrency() == null){
            log.error("param currency is null!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }
        if(cashOutVO.getAmount() == null){
            log.error("param amount is null!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }
        if(cashOutVO.getBankCard() == null){
            log.error("param bankCard is null!!!,userId={},orderNo={}",cashOutVO.getUserId(),cashOutVO.getOrderNo());
            throw new PayBusinessException(ResultCode.PARAM_MISS);
        }

    }

    @Override
    public R<CashOutDTO> query(CashQueryVO cashQueryVO) {
        Partner partner = PartnerHolder.getPartner();
        CashOut cashOut = queryByPartnerCodeAndPartnerOrderNo(partner.getPartnerCode(),cashQueryVO.getPartnerOrderNo());
        if(null == cashOut){
            throw new PayBusinessException(ResultCode.ORDER_NOT_EXIST);
        }
        return R.data(cashOutDTOMapStruct.toDto(cashOut));
    }
}
