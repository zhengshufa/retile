package com.ly.pay.service.payment.payWay;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.common.enums.PayOrderStatusEnum;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.service.payment.PayContext;
import com.ly.utils.VstResult;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.pay.service.IPayOrderService;
import com.ly.pay.service.payment.Pay;
import com.ly.pay.service.client.BalancePayClient;
import com.ly.pay.service.client.vo.BalancePayReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.impl.payment.BalancePay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 14:07
 * @description TODO
 */
@Component
@Slf4j
public class BalancePay implements Pay {

    @Autowired
    private BalancePayClient balancePayClient;
    @Autowired
    private IPayOrderService payOrderService;
    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;

    @Override
    public PayOrderDTO pay(PayContext payContext) {
        PayOrder payOrder = payContext.getPayOrder();
        BalancePayReq balancePayReq = new BalancePayReq();
        balancePayReq.setAmount(payOrder.getTotalAmount().doubleValue());
        balancePayReq.setBillNo(payOrder.getPayOrderNo());
        //从扩展字段拿推荐码
        balancePayReq.setReferralCode(payOrder.getReferralCode());
        balancePayReq.setOperationType(3L);
        balancePayReq.setUserId(payOrder.getUserId());
        balancePayReq.setReferralCode(payOrder.getReferralCode());
        try {
            String orderNo = balancePayClient.balancePay(balancePayReq);
            if(orderNo!=null){
                payOrder.setMerchantOrderNo(orderNo);
                payOrder.setStatus(PayOrderStatusEnum.SUCCESS.getCode());
                LambdaQueryWrapper<PayOrder> wrapper = new LambdaQueryWrapper<>();
                wrapper.eq(PayOrder::getPayOrderNo,payOrder.getPayOrderNo())
                        .eq(PayOrder::getPartnerNo,payOrder.getPartnerNo());
                payOrderService.update(payOrder,wrapper);
                PayOrderDTO dto = payOrderDTOMapStruct.toDto(payOrder);
                dto.setCallbackUrl(payOrder.getPartnerCallbackUrl());
                dto.setOrderNo(payOrder.getPartnerOrderNo());
                log.error("success,payOrderNo={},userId={},payRes={}",payOrder.getPayOrderNo(),payOrder.getUserId(),orderNo);
                return dto;
            }
            log.error("balance pay error, userId={},payOrderNo={}",payOrder.getUserId(),payOrder.getPayOrderNo());
           throw new PayBusinessException(ResultCode.BALANCE_PAY_ERROR);
        } catch (Exception e) {
            log.error("balance pay error, userId={},payOrderNo={}",payOrder.getUserId(),payOrder.getPayOrderNo(), e);
            throw new PayBusinessException(ResultCode.BALANCE_PAY_ERROR);
        }
    }
}