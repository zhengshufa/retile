package com.ly.pay.service.client.vo;

import lombok.Data;

/**
 * packageName.className com.ly.pay.service.payment.client.vo.BalancePayReq
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 16:06
 * @description TODO
 */
@Data
public class BalancePayReq {
    /**
     * 金额
     */
    private Double amount;
    /**
     * 第三方订单号（提现和支付的情况下才有）
     */
    private String billNo;

    /**
     * 操作类型（1-分佣，2-提现，3-支付）
     */
    private Long operationType;
    /**
     * 推荐码
     */
    private String referralCode;
    /**
     * 退款关联单号（仅在退款的时候有值，对应的是第三方单号）
     */
    private String refundTrackNo;
    /**
     * 用户id
     */
    private Long userId;


}