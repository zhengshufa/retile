package com.ly.pay.common.enums;


/**
 * <p>
 *  货币单位
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum CurrencyUnitEnum {

    // 人民币（中国）
    CNY("人民币", "China Yuan Renminbi", "¥"),
    // 美元（美国）
    USD("美元", "United States Dollar", "$"),
    // 欧元（欧元区多个国家通用）
    EUR("欧元", "Euro", "€"),
    // 英镑（英国）
    GBP("英镑", "British Pound Sterling", "£"),
    // 日元（日本）
    JPY("日元", "Japanese Yen", "¥"),
    // 港元（中国香港特别行政区）
    HKD("港元", "Hong Kong Dollar", "HK$"),
    // 澳元（澳大利亚）
    AUD("澳元", "Australian Dollar", "A$"),
    // 加元（加拿大）
    CAD("加元", "Canadian Dollar", "C$"),
    // 瑞士法郎（瑞士）
    CHF("瑞士法郎", "Swiss Franc", "CHF"),
    // 新加坡元（新加坡）
    SGD("新加坡元", "Singapore Dollar", "S$");

    private final String currencyName;
    private final String fullEnglishName;
    private final String symbol;

    CurrencyUnitEnum(String currencyName, String fullEnglishName, String symbol) {
        this.currencyName = currencyName;
        this.fullEnglishName = fullEnglishName;
        this.symbol = symbol;
    }

    // 获取货币中文名称
    public String getCurrencyName() {
        return currencyName;
    }

    // 获取货币英文全称
    public String getFullEnglishName() {
        return fullEnglishName;
    }

    // 获取货币符号
    public String getSymbol() {
        return symbol;
    }

    // 根据货币符号查找对应的CurrencyUnit枚举实例（可用于从符号反查货币信息）
    public static CurrencyUnitEnum fromCode(String symbol) {
        for (CurrencyUnitEnum unit : values()) {
            if (unit.name().equals(symbol)) {
                return unit;
            }
        }
        return null;
    }
}