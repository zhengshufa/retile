package com.ly.pay.service.callback.stripe.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.ly.distribute.DistributeLock;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.entity.StripeCallback;
import com.ly.pay.service.IStripeCallbackService;
import com.ly.pay.service.callback.stripe.EventHandler;
import com.stripe.model.Event;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.callback.stripe.handler.RefundUpdateEvent
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-10 11:18
 * @description TODO
 */
@Component
@Slf4j
public class RefundUpdateEvent implements EventHandler {

    @Autowired
    private IStripeCallbackService stripeCallbackService;

    @Override
    public PayOrder handle(Event event) {
        String json = event.getDataObjectDeserializer().getRawJson();
        JSONObject jsonObject = JSON.parseObject(json);
        log.info(jsonObject.toJSONString());
        return null;
    }
}