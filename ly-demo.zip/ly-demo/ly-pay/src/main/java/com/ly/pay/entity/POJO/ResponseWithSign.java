package com.ly.pay.entity.POJO;

import lombok.Data;

/**
 * packageName.className com.ly.pay.entity.POJO.ResponseWithSign
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-30 16:57
 * @description TODO
 */
@Data
public class ResponseWithSign {
    private String msg;
    private String code;
    private String data;
    private String sign;

}