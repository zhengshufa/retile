package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.pay.entity.MerchantMapProduct;
import com.ly.pay.mapper.MerchantMapProductMapper;
import com.ly.pay.service.IMerchantMapProductService;
import org.apache.ibatis.reflection.wrapper.BaseWrapper;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author alaric
 * @since 2025-01-08 09：20：27
 */
@Service
public class MerchantMapProductServiceImpl extends ServiceImpl<MerchantMapProductMapper, MerchantMapProduct> implements IMerchantMapProductService {

    @Override
    public MerchantMapProduct findByProductIdAndProductId(String merchantId, String productId) {
        QueryWrapper<MerchantMapProduct> wrapper = new QueryWrapper<>();
        wrapper.eq("vst_product_id", productId);
        wrapper.eq("merchant_code", merchantId);
        return this.getOne(wrapper);

    }
}
