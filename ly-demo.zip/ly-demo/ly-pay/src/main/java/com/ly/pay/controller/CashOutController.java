package com.ly.pay.controller;

import com.ly.domain.api.R;
import com.ly.pay.entity.DTO.CashOutDTO;
import com.ly.pay.entity.VO.CashOutVO;
import com.ly.pay.entity.VO.CashQueryVO;
import com.ly.pay.service.ICashOutService;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * packageName.className com.ly.pay.controller.CashOutController
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 17:17
 * @description 提现接口
 */
@RestController
@RequestMapping("cash")
@Schema(title = "提现相关接口类")
@Slf4j
public class CashOutController {


    @Autowired
    private ICashOutService cashOutService;


    /**
     * <p>
     *  支付请求接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping("out")
    public R<CashOutDTO> cashOut(@RequestBody CashOutVO cashOutVO) {
        return cashOutService.cashOut(cashOutVO);
    }


    /**
     * <p>
     * 支付方式查询接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping("query")
    public R<CashOutDTO> query(@RequestBody CashQueryVO cashQueryVO) {
            return cashOutService.query(cashQueryVO);
    }




}