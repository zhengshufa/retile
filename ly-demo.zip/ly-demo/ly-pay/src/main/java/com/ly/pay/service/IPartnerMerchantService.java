package com.ly.pay.service;

import com.ly.pay.entity.PartnerMerchant;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-50-18 10：12：11
 */
public interface IPartnerMerchantService extends IService<PartnerMerchant> {

    /**
     * 根据产品业务类型和支付渠道查询可以用的支付渠道列表
     * @param partnerNo
     * @param vendor
     * @return
     */
    List<PartnerMerchant> queryByPartnerAndVendor(String partnerNo,Integer vendor);


    /**
     * 根据产品业务类型和支付渠道查询可以用的支付渠道列表
     * @param partnerCode
     * @return
     */
    List<PartnerMerchant> queryByPartnerCode(String partnerCode);

}
