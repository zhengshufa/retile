package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2025-01-17 14：01：28
 */
@Getter
@Setter
@TableName("vst_cash_out")
public class CashOut extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 业务线业务编号
     */
    private String partnerNo;

    /**
     * 请求订单号
     */
    private String requestOrderNo;

    /**
     * 通知地址
     */
    private String callbackUrl;

    /**
     * 支付系统订单号
     */
    private String payOrderNo;

    /**
     * 提现金额
     */
    private BigDecimal amount;

    /**
     * 币种
     */
    private String currency;

    /**
     * 银行卡
     */
    private String bankCardNo;

    /**
     * 用户端ip地址
     */
    private String clientIp;

    /**
     * 扩展参数
     */
    private String extParams;

    /**
     * 备注
     */
    private String remark;
}
