package com.ly.pay.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.pay.entity.Charge;
import com.ly.pay.mapper.ChargeMapper;
import com.ly.pay.service.IChargeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2025-01-16 16：16：23
 */
@Service
public class ChargeServiceImpl extends ServiceImpl<ChargeMapper, Charge> implements IChargeService {

    @Override
    public Long queryCntByReferralCode(String referralCode) {
        LambdaQueryWrapper<Charge> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Charge::getReferralCode, referralCode);
        lambdaQueryWrapper.le(Charge::getCreateTime,new Date());
        lambdaQueryWrapper.ge(Charge::getCreateTime, DateUtil.beginOfDay(new Date()));
        return this.count(lambdaQueryWrapper);
    }
    @Override
    public Charge queryByPartnerChargeNo(String partnerChargeNo) {
        LambdaQueryWrapper<Charge> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Charge::getPartnerChargeNo, partnerChargeNo);
        return this.getOne(lambdaQueryWrapper);
    }

}
