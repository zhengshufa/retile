package com.ly.pay.service.client;

import com.ly.pay.service.client.vo.BalancePayReq;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName.className com.ly.pay.service.payment.client.BalancePayClient
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:15
 * @description TODO
 */
@Component
public class BalancePayClient extends AbstractClient<String> {

    @Value("${member.host}")
    private String memberHost;

    /***
     * 余额支付
     * @param balancePayReq
     * @return
     * @throws Exception
     */
    public String balancePay(BalancePayReq balancePayReq) throws Exception {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("userId", balancePayReq.getUserId().toString());
        paramMap.put("referralCode", balancePayReq.getReferralCode());
        paramMap.put("billNo", balancePayReq.getBillNo());
        paramMap.put("amount", balancePayReq.getAmount().toString());
        paramMap.put("operationType", balancePayReq.getOperationType().toString());
        paramMap.put("refundTrackNo", balancePayReq.getRefundTrackNo());
        return this.request(paramMap, String.class);
    }

    @Override
    public String getInterPath() {
        return memberHost + "/ly-member/memberAccount/memberAccountPay";
    }
}