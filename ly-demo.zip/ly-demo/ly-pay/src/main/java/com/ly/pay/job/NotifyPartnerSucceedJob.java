package com.ly.pay.job;

import com.ly.pay.service.IPayService;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.job.NotifyPartnerSucceedJob
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:57
 * @description
 */
@Slf4j
@Component
public class NotifyPartnerSucceedJob {

    @Autowired
    private IPayService payService;

    @XxlJob("notifyPartnerSucceedJob")
    public void demoJobHandler() throws Exception {
        log.info("notifyPartnerSucceedJob process start");
        payService.reInvoke();
        log.info("notifyPartnerSucceedJob process end");
    }
}

