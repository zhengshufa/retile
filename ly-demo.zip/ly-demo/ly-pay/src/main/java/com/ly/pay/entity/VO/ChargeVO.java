package com.ly.pay.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.NOT_REQUIRED;
import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.REQUIRED;

/**
 * packageName.className com.ly.pay.entity.VO.ChargeVO
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-15 11:43
 * @description TODO
 */
@Schema(description = "充值请求")
@Data
public class ChargeVO {

    /**
     * 充值交易号 需要保持唯一性 必须
     */
    @Schema(description = "充值交易号 需要保持唯一性 必须",requiredMode = REQUIRED )
    private String tradeNo;

    /**
     * 推荐码 必须
     */
    @Schema(description = "推荐码 必须",requiredMode = REQUIRED)
    private String referralCode;

    /**
     * 推荐码 必须
     */
    @Schema(description = "用户Id 必须",requiredMode = REQUIRED)
    private Long userId;

    /**
     * 金额 单位为最小单位，美元对应的是美分，日元对应的是日元 必须
     */
    @Schema(description = "金额 单位为最小单位，美元对应的是美分，日元对应的是日元 必须",requiredMode = REQUIRED)
    private BigDecimal amount;

    /**
     * 币种 必须
     */
    @Schema(description = "币种 必须",requiredMode = REQUIRED)
    private String currency;

    /**
     * 时间戳 毫秒数 必须
     */
    @Schema(description = "时间戳 毫秒数 必须",requiredMode = REQUIRED)
    private Long timestamp;


    /**
     * 标题，不能为空
     */
    @Schema(description = "标题，必须",requiredMode = REQUIRED)
    private String title;


    /**
     * 扩展字段，json格式，可以为空
     */
    @Schema(description = "扩展字段，json格式，可以为空",requiredMode =NOT_REQUIRED )
    private String extParams;


}