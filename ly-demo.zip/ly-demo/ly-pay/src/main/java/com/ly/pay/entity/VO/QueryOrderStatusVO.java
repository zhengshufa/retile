package com.ly.pay.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * packageName.className com.ly.pay.entity.VO.QueryOrderStatusVO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:52
 * @description TODO
 */
@Schema(description = "订单状态查询请求类")
@Data
public class QueryOrderStatusVO {

    /**
     * 业务方订单号
     */
    @Schema(description = "业务方订单号，必须")
    private String orderNo;


}