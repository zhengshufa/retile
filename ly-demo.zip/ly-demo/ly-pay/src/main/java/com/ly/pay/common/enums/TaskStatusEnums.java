package com.ly.pay.common.enums;

public enum TaskStatusEnums {
    // 待执行，对应数值0
    WAITING(0, "待执行"),
    // 执行成功，对应数值1
    SUCCESS(1, "执行成功"),
    // 执行失败，对应数值2
    FAILED(2, "执行失败"),
    //超过5次之后的状态
    NOT_SUCCESS(3, "最终没有成功");

    private final int code;
    private final String description;

    TaskStatusEnums(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static TaskStatusEnums fromCode(int code) {
        for (TaskStatusEnums status : TaskStatusEnums.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        throw new IllegalArgumentException("无效的任务状态码: " + code);
    }
}