package com.ly.pay.mapper;

import com.ly.pay.entity.PayTask;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2024-12-23 16：27：30
 */
public interface PayTaskMapper extends BaseMapper<PayTask> {

}
