package com.ly.pay.service.payment.cashPay.channel.nihao;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.service.payment.cashPay.FormatUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.nihao.CardPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-23 10:33
 * @description TODO
 */
@Slf4j
@Service
public class CardPay extends AbstractNiHao {


    @Override
    public PayOrderDTO doProcessResult(PayOrderDTO dto, String result) {
        JSONObject jsonObject = JSON.parseObject(result);
        String url = jsonObject.getString("redirect_url");
        if( url== null ||!url.startsWith("https://")){
            log.error("card pay error,dto={},result={}",dto,result);
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
        dto.setRedirectUrl(FormatUtils.formatUrl2HtmlForCard(url));
        return dto;
    }
}