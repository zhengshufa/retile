package com.ly.pay.service.callback.stripe.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ly.distribute.DistributeLock;
import com.ly.pay.common.RedisKey;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.entity.StripeCallback;
import com.ly.pay.service.IStripeCallbackService;
import com.ly.pay.service.callback.stripe.EventHandler;
import com.stripe.model.Event;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.callback.stripe.handler.ChargeSucceededEvent
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 16:50
 * @description TODO
 */
@Component
@Slf4j
public class ChargeSucceededEvent implements EventHandler {

    @Autowired
    private IStripeCallbackService stripeCallbackService;

    @Autowired
    private DistributeLock distributeLock;

    @Override
    public PayOrder handle(Event event) {
        String json = event.getDataObjectDeserializer().getRawJson();
        JSONObject jsonObject = JSON.parseObject(json);
        String chargeId = jsonObject.getString("id");
        String paymentIntentId = String.valueOf(jsonObject.get("payment_intent"));
        log.info("handle========>ChargeSucceededEvent,{}", paymentIntentId);

        String key = RedisKey.getPaymentIntentKey(paymentIntentId);
        boolean isLocked = distributeLock.tryLock(key, 1000);
        try {
            if (isLocked) {
                StripeCallback newStripeCallback = stripeCallbackService.selectByPaymentIntent(paymentIntentId);
                if (newStripeCallback != null) {
                    newStripeCallback.setChargeId(chargeId);
                    newStripeCallback.setEventChargeSucceeded(jsonObject.toJSONString());
                    stripeCallbackService.updateById(newStripeCallback);
                } else {
                    StripeCallback stripeCallback = new StripeCallback();
                    stripeCallback.setPaymentIntentId(paymentIntentId);
                    stripeCallback.setChargeId(chargeId);
                    stripeCallback.setEventChargeSucceeded(jsonObject.toJSONString());
                    stripeCallbackService.save(stripeCallback);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (isLocked) {
                distributeLock.unlock(key);
            }
        }
        return null;

    }
}