package com.ly.pay.service.impl;

/**
 * packageName.className com.ly.pay.service.impl.AbstractService
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 15:48
 * @description TODO
 */
public class AbstractService {


}