package com.ly.pay.service.payment;

import com.ly.pay.entity.PayOrder;
import com.ly.pay.entity.VO.PayOderVO;
import lombok.Builder;
import lombok.Data;

/**
 * packageName.className com.ly.pay.service.payment.PayContext
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-08 13:22
 * @description 支付逻辑的的上下文，主要放入需要上下传递的内容
 */
@Builder
@Data
public class PayContext {

    public static final String PRODUCT_ID = "PRODUCT_ID";
    /**
     * 当前请求支付的请求对象
     */
    private PayOderVO payRequestVO;

    /**
     * 当前处理的订单
     */
    private PayOrder payOrder;

}