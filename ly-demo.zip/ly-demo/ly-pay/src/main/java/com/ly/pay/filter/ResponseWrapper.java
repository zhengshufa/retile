package com.ly.pay.filter;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;

public class ResponseWrapper extends HttpServletResponseWrapper {

    // 使用字节数组输出流来存储响应数据
    private final ByteArrayOutputStream buffer;
    private ServletOutputStream outputStream;
    private PrintWriter writer;
    private final Charset charset;

    public ResponseWrapper(HttpServletResponse response) {
        super(response);
        this.buffer = new ByteArrayOutputStream();
        // 获取响应的字符编码，若未设置则使用默认编码（通常是UTF-8）
        this.charset = Charset.forName(response.getCharacterEncoding()!= null? response.getCharacterEncoding() : "UTF-8");
    }

    /**
     * 获取包装后的输出流，确保线程安全以及正确的流关联逻辑
     */
    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        if (writer!= null) {
            throw new IllegalStateException("Cannot get output stream if writer is already in use.");
        }
        if (outputStream == null) {
            outputStream = new WrappedOutputStream(buffer);
        }
        return outputStream;
    }

    /**
     * 获取包装后的字符写入器（PrintWriter），同样确保线程安全以及与输出流的互斥使用
     */
    @Override
    public PrintWriter getWriter() throws IOException {
        if (outputStream!= null) {
            throw new IllegalStateException("Cannot get writer if output stream is already in use.");
        }
        if (writer == null) {
            writer = new PrintWriter(new OutputStreamWriter(buffer, charset), true);
        }
        return writer;
    }

    /**
     * 刷新缓冲区，确保内部字节数组输出流中的数据被正确处理
     */
    @Override
    public void flushBuffer() throws IOException {
        if (writer!= null) {
            writer.flush();
        } else if (outputStream!= null) {
            outputStream.flush();
        }
        buffer.flush();
    }

    /**
     * 获取捕获到的响应数据内容，返回字节数组形式
     */
    public byte[] getContent() {
        return buffer.toByteArray();
    }

    /**
     * 内部类，用于包装真正的ServletOutputStream，实现将写入的数据存储到字节数组输出流中
     */
    private class WrappedOutputStream extends ServletOutputStream {

        private final ByteArrayOutputStream bos;

        public WrappedOutputStream(ByteArrayOutputStream bos) {
            this.bos = bos;
        }

        @Override
        public void write(int b) throws IOException {
            bos.write(b);
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            bos.write(b, off, len);
        }

        @Override
        public boolean isReady() {
            return false;
        }

        @Override
        public void setWriteListener(WriteListener writeListener) {
            // 这里可以根据需要实现WriteListener相关逻辑，通常在异步处理场景更常用，当前简单返回即可
        }
    }
}