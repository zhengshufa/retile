package com.ly.pay.service.payment.cashPay.channel.nihao.request;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.request.ShippingAddressConfig
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 13:15
 * @description TODO
 */
@Component
@Data
@RefreshScope
public class ShippingAddressConfig {

    @Value("${shipping.address.first_name}")
    private String firstName;

    @Value("${shipping.address.middle_name}")
    private String middleName;

    @Value("${shipping.address.last_name}")
    private String lastName;

    @Value("${shipping.address.line1}")
    private String line1;

    @Value("${shipping.address.line2}")
    private String line2;

    @Value("${shipping.address.city}")
    private String city;

    @Value("${shipping.address.state}")
    private String state;

    @Value("${shipping.address.country}")
    private String country;

    @Value("${shipping.address.zip}")
    private String zip;

}