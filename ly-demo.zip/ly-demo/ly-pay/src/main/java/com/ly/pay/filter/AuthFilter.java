package com.ly.pay.filter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.common.utils.PartnerHolder;
import com.ly.pay.common.utils.RequestHolder;
import com.ly.pay.entity.POJO.RequestInfo;
import com.ly.pay.entity.Partner;
import com.ly.pay.service.IAuthService;
import com.ly.pay.service.IPartnerService;
import com.ly.utils.OrderNumberUtils;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Map;

/**
 * packageName.className com.ly.pay.filter.AuthFilter
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 9:29
 * @description TODO
 */
@Slf4j
@WebFilter(filterName = "AuthFilter", urlPatterns = "/*")
public class AuthFilter implements Filter, ApplicationContextAware {
    private ApplicationContext applicationContext;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String requestBody = "";
        String requestParams = "";
        String responseStr = "";
        String responseCode = "";
        String requestId = "";
        try {
            log.info("this times request url={}", request.getRequestURL());
            if (request.getRequestURL() != null && request.getRequestURL().toString().contains("v3/api-docs") || request.getRequestURL().toString().contains("/callback")|| request.getRequestURL().toString().contains("/health")) {
                filterChain.doFilter(request, servletResponse);
                return;
            }
            response.setContentType("application/json;charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
            String appId = request.getHeader("appId");
            requestId = request.getHeader("X-Request-ID");
            int lastIndex = request.getRequestURI().lastIndexOf('.');
            if (lastIndex != -1) {
                String fileExtension = request.getRequestURI().substring(lastIndex + 1).toLowerCase();
                if ("js".equals(fileExtension) || "html".equals(fileExtension) || "css".equals(fileExtension)) {
                    log.info("filter request===>method={},url={}", request.getMethod(), request.getRequestURL());
                    filterChain.doFilter(servletRequest, servletResponse);
                    return;
                }
            }
            RequestHolder.putRequestInfo(RequestInfo.builder().appId(appId).requestId(requestId).build());
            ServletRequest requestWrapper = new BodyRequestWrapper(request);
            ResponseWrapper wrapperResponse = new ResponseWrapper(response);
            requestBody = HttpHelper.getBodyString(requestWrapper);
            if (appId == null || appId.isEmpty()) {
                log.info("filter request===>method={},url={}", request.getMethod(), request.getRequestURL());
                log.error("appId is blank!!");
                writeOut(request, response, requestBody, ResultCode.APP_ID_IS_NULL);
                return;
            }

            IPartnerService partnerService = (IPartnerService) applicationContext.getBean("partnerService");
            Partner partner = partnerService.queryByToken(appId);
            PartnerHolder.putPartner(partner);

            //GET请求不做签名
            if ("GET".equals(request.getMethod())) {
                log.info("filter request===>method={},url={}", request.getMethod(), request.getRequestURL());
                Map<String, String[]> params = request.getParameterMap();
                if (!params.isEmpty()) {
                    StringBuilder str = new StringBuilder();
                    for (String key : params.keySet()) {
                        String[] values = params.get(key);
                        for (String value : values) {
                            str.append(key).append("=").append(value).append("&");
                        }
                    }
                    requestParams = str.toString();
                }
                filterChain.doFilter(requestWrapper, wrapperResponse);
                byte[] content = wrapperResponse.getContent();
                // 在这里对content进行签名操作
                responseStr = new String(content);
                response.getOutputStream().write(content);
                response.getOutputStream().flush();
                return;
            }
            // 获取请求头中的 sign
            String sign = request.getHeader("sign");
            if (sign == null || sign.isEmpty()) {
                log.error("sign is blank!!");
                writeOut(request, response, requestBody, ResultCode.UN_AUTHORIZED);
                return;
            }
            IAuthService iAuthService = (IAuthService) applicationContext.getBean("iAuthService");
            log.info("filter request===>method={},url={},body={}", request.getMethod(), request.getRequestURL(), requestBody);
            try {
                if (!iAuthService.verifyAndDecode(appId, sign, requestBody, partner.getPublicKey())) {
                    writeOut(request, response, requestBody, ResultCode.UN_AUTHORIZED);
                    return;
                }
            } catch (Exception e) {
                log.info("check sign is fail, body={}", requestBody, e);
                throw new PayBusinessException(e);
            }
            filterChain.doFilter(requestWrapper, wrapperResponse);
            log.info("after controller....");
            byte[] content = wrapperResponse.getContent();
            // 在这里对content进行签名操作
            responseStr = new String(content);
            if (StringUtils.hasLength(responseStr)) {
                JSONObject json = JSON.parseObject(content);
                log.info(json.toJSONString());
                try {
                    String responseSign = iAuthService.vstEncode(responseStr);
                    response.addHeader("sign", responseSign);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                    throw new RuntimeException(e);
                }
            }
            response.getOutputStream().write(content);
            response.getOutputStream().flush();
        } catch (Exception e) {
            log.error("======",e);
            throw new RuntimeException(e);
        } finally {
            if(requestId == null){
                requestId = OrderNumberUtils.generateSimpleNumber();
            }
            responseCode = String.valueOf(response.getStatus());
            log.info("""
                            {}
                            [{}]request[{}]{}\
                            
                            [{}]requestParams={}\
                            
                            [{}]requestBody={}\
                            
                            [{}]resultCode={}\
                            
                            [{}]resultBody={}""",
                    requestId,
                    requestId, request.getMethod(), request.getRequestURL(),
                    requestId,requestParams, requestId,requestBody,
                    requestId,responseCode, requestId,responseStr);
        }
    }

    /**
     * 没有权限
     *
     * @param request  请求对象
     * @param response 返回对象
     * @throws IOException
     */
    private void writeOut(HttpServletRequest request, HttpServletResponse response, String jsonData, ResultCode resultCode) throws IOException {
        log.info("auth filter error, request===>method={},url={},body={}", request.getMethod(), request.getRequestURL(), jsonData);
        response.getWriter().print(JSON.toJSONString(R.fail(resultCode)));
        response.getWriter().flush();
    }

    @Override
    public void destroy() {
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}