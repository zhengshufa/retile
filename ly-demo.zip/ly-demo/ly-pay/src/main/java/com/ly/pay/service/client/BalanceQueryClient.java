package com.ly.pay.service.client;

import com.ly.pay.service.client.vo.QueryBalanceReq;
import com.ly.pay.service.client.vo.QueryBalanceRes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName.className com.ly.pay.service.payment.client.BalanceQueryClient
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:14
 * @description TODO
 */
@Component
public class BalanceQueryClient extends AbstractClient<QueryBalanceRes> {

    @Value("${member.host}")
    private String memberHost;


    public QueryBalanceRes queryBalance(QueryBalanceReq queryBalanceReq) throws Exception {
        Map<String,Object> paramMap = new HashMap<>();
        paramMap.put("referralCode",queryBalanceReq.getReferralCode());
        return this.request(paramMap, QueryBalanceRes.class);
    }
    @Override
    public String getInterPath() {
        return memberHost+"/ly-member/memberAccount/memberAccount";
    }
}