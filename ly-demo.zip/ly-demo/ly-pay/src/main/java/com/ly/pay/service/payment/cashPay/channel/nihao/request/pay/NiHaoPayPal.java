package com.ly.pay.service.payment.cashPay.channel.nihao.request.pay;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.service.payment.cashPay.channel.nihao.AbstractNiHao;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.NiHaoPayPal
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:35
 * @description niHaoPay的paypal
 */
@Service
public class NiHaoPayPal extends AbstractNiHao {


    @Override
    public PayOrderDTO doProcessResult(PayOrderDTO dto, String result) {
        dto.setRedirectUrl(result);
        return dto;
    }
}