package com.ly.pay.entity.POJO;

import lombok.Data;

@Data
public class CreatePaymentResponse {
    private String clientSecret;
    private String paymentIntentId;
    private String publishableKey;

    public CreatePaymentResponse(String clientSecret, String paymentIntentId,String pubKey) {
        this.clientSecret = clientSecret;
        this.paymentIntentId = paymentIntentId;
        this.publishableKey = pubKey;
    }

}