package com.ly.pay.service.client.vo;

import lombok.Data;

/**
 * packageName.className com.ly.pay.service.payment.client.vo.QueryBalanceReq
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:59
 * @description TODO
 */
@Data
public class QueryBalanceReq {
    private Long userId;
    private String referralCode;

}