package com.ly.pay.service;

import com.ly.pay.entity.Charge;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2025-01-16 16：16：23
 */
public interface IChargeService extends IService<Charge> {


    /**
     *
     * @param referralCode
     * @return
     */
    Long queryCntByReferralCode(String referralCode);


    /**
     * 根据业务方订单号查询
     * @param partnerChargeNo
     * @return
     */
    Charge queryByPartnerChargeNo(String partnerChargeNo);

}
