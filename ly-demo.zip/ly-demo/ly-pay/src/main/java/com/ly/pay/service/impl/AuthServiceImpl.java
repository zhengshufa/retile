package com.ly.pay.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.ly.pay.common.utils.PartnerHolder;
import com.ly.pay.entity.Partner;
import com.ly.pay.service.IAuthService;
import com.ly.pay.service.IPartnerService;
import com.ly.utils.signatureUtil.rsa.RSACoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

/**
 * packageName.className com.ly.pay.service.impl.AuthServiceImpl
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 9:59
 * @description TODO
 */
@Slf4j
@Service("iAuthService")
public class AuthServiceImpl implements IAuthService {

    @Autowired
    private IPartnerService partnerService;

    @Value("${rsa.private-key}")
    private String payRsaPrivateKey;

    @Override
    public String vstEncode(String inputStr) throws Exception {
        return RSACoder.sign(inputStr.getBytes(StandardCharsets.UTF_8), payRsaPrivateKey);

    }

    @Override
    public Boolean verifyAndDecode(String headerId, String sign, String jsonStr,String publicKey) throws Exception {
        TreeMap<String, String> treeMap = JSON.parseObject(jsonStr, new TypeReference<TreeMap<String, String>>() {});
        StringBuilder sb = new StringBuilder();
        treeMap.forEach((k, v) -> {
            sb.append(k).append("=").append(v).append("&");
        });
        log.info("source sign=====>{}",sign);
        log.info("verifyAndDecode data ===> {}", sb);
        boolean result = RSACoder.verify(sb.toString().getBytes(StandardCharsets.UTF_8), publicKey, sign);
        log.info("verify result====>{}",result);
        return result;
    }
}