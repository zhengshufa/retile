package com.ly.pay.mapper;

import com.ly.pay.entity.Merchant;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2024-12-18 16：54：49
 */
public interface MerchantMapper extends BaseMapper<Merchant> {

}
