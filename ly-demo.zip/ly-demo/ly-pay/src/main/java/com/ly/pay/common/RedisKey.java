package com.ly.pay.common;

/**
 * packageName.className com.ly.pay.common.utils.RedisKey
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-10 17:50
 * @description redisKey
 */
public class RedisKey {

  public final static String STRIPE_CALL_BACK = "STRIPE_CALL_BACK_%s";

  public static String getPaymentIntentKey(String paymentIntent){
      return STRIPE_CALL_BACK.formatted(paymentIntent);
  }

}