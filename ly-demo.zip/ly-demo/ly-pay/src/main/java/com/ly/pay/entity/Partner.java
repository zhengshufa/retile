package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2024-08-17 11：12：14
 */
@Getter
@Setter
@TableName("vst_partner")
public class Partner extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 合作商/业务线名称
     */
    private String partnerName;

    /**
     * 合作商/业务线编号
     */
    private String partnerCode;

    /**
     * pay生成的token
     */
    private String partnerToken;

    /**
     * 接入业务的公钥
     */
    private String publicKey;

    /**
     * 对调地址，可为空
     */
    private String callbcakUrl;
}
