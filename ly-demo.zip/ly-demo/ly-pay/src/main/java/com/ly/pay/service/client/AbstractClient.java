package com.ly.pay.service.client;

import com.ly.utils.OrderNumberUtils;
import com.ly.utils.signatureUtil.AbstractSignatureUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * packageName.className com.ly.pay.service.payment.client.BalancePayClient
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:15
 * @description TODO
 */
@Slf4j
@Component
public abstract class AbstractClient<T> extends AbstractSignatureUtil<T> {

    @Value("${rsa.private-key}")
    private String payRsaPrivateKey;
    @Value("${spring.application.appId}")
    private String payAppId;
    /**
     * 请求封装类
     *
     * @param paramMap
     * @param tClass
     * @throws Exception
     */
    public T request(Map<String, Object> paramMap, Class<T> tClass) throws Exception {
        return request( paramMap, tClass, getAppId(), getRequestId());
    }

    public T request(Map<String, Object> paramMap,String requestUrl, Class<T> tClass) throws Exception {
        return request(paramMap, requestUrl,tClass, getAppId(), getRequestId());

    }
    /**
     * 获取加密的key
     * @return
     */
    @Override
    public String getPrivateKey(){
        return payRsaPrivateKey;
    }

    public String getAppId(){
        return payAppId;
    }

    public String getRequestId(){
        return OrderNumberUtils.generateSimpleNumber();
    }

}