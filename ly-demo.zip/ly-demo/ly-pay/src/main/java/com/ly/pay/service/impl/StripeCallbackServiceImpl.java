package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.pay.entity.StripeCallback;
import com.ly.pay.mapper.StripeCallbackMapper;
import com.ly.pay.service.IStripeCallbackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2025-01-09 14：39：44
 */
@Service
public class StripeCallbackServiceImpl extends ServiceImpl<StripeCallbackMapper, StripeCallback> implements IStripeCallbackService {


    @Override
    public boolean updateByPaymentIntentId(StripeCallback stripeCallback){
        QueryWrapper<StripeCallback> wrapper = new QueryWrapper<>();
        wrapper.eq("payment_intent_id",stripeCallback.getPaymentIntentId());
        return this.update(stripeCallback,wrapper);
    }

    @Override
    public StripeCallback selectByPaymentIntent(String paymentIntentId) {
        QueryWrapper<StripeCallback> wrapper = new QueryWrapper<>();
        wrapper.eq("payment_intent_id",paymentIntentId);
        return this.getOne(wrapper);
    }

}
