package com.ly.pay.service.payment.cashPay.channel.nihao;

import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.common.enums.CurrencyUnitEnum;
import com.ly.pay.common.enums.PayOsTypeEnum;
import com.ly.pay.common.enums.VendorEnum;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.Merchant;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.pay.service.IMerchantService;
import com.ly.pay.service.IPayOrderService;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.Channel;
import com.ly.pay.service.payment.cashPay.channel.nihao.request.HttpRequest;
import com.ly.pay.service.payment.cashPay.channel.nihao.request.NhPayReq;
import com.ly.pay.service.payment.cashPay.channel.nihao.request.ShippingAddressConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.Objects;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.NiHaoPayChannel
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 13:15
 * @description TODO
 */
@Slf4j
public abstract class AbstractNiHao implements Channel {

    @Value("${callbackHost.niHao}")
    private String niHaoPayCallbackHost;
    private static final String INVOKE_PAY_URL = "/ly-pay/callback/niHao";
    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IPayOrderService iPayOrderService;
    @Autowired
    private ShippingAddressConfig shippingAddressConfig;

    @Override
    public PayOrderDTO pay(PayContext payContext) {
        PayOrder payOrder = payContext.getPayOrder();
        PayOrderDTO dto = payOrderDTOMapStruct.toDto(payOrder);
        dto.setOrderNo(payOrder.getPartnerOrderNo());
        dto.setCallbackUrl(payOrder.getPartnerCallbackUrl());
        NhPayReq payReq = new NhPayReq();
        payReq.setAmount(String.valueOf(payOrder.getTotalAmount().intValue()));
        payReq.setVendor(Objects.requireNonNull(VendorEnum.fromCode(payOrder.getVendor())).getDesc());
        payReq.setReference(payOrder.getPayOrderNo());
        payReq.setTimeout(payOrder.getTimeout().toString());
        payReq.setIpn_url(niHaoPayCallbackHost + INVOKE_PAY_URL);
        payReq.setNote(payOrder.getNote());
        payReq.setCallback_url(payOrder.getRedirectUrl());
        payReq.setCurrency(CurrencyUnitEnum.USD.name());
        Merchant merchant = merchantService.findByCode(payOrder.getMerchantNo());
        payReq.setToken(merchant.getToken());
        payReq.setTerminal(PayOsTypeEnum.WAP.name());
        //这里让接口返回JSON，这样可以解析出orderId，也可是HTML,这样的话没有orderId
        payReq.setResponse_format("JSON");

        //card
        if (VendorEnum.BANK_CARD.getCode() == payOrder.getVendor()) {
            payReq.setWebsite("http://www.vst-wordwide.com");
            payReq.setClient_ip("192.168.0.1");
            payReq.setVendor(null);
            payReq.setTerminal(null);
            payReq.setTimeout(null);
            buildShippingAddress(payReq);
        }

        log.info("url====>{}", merchant.getMerchantInvokeUrl());
        log.info("params====>{}", payReq.getInput());
        log.info("token====>{}", payReq.getToken());
        String result = HttpRequest.sendAuthPost(merchant.getMerchantInvokeUrl(), payReq.getInput(), "Bearer " + payReq.getToken());
        log.info("result===>{}", result);
        payOrder.setRemark(result);
        iPayOrderService.updateByPayOrder(payOrder);
        return doProcessResult(dto, result);
    }




    /**
     * 构造返回参数
     *
     * @param payReq 传入的参数
     */
    public void buildShippingAddress(NhPayReq payReq) {
        payReq.setShipping_address_first_name(shippingAddressConfig.getFirstName());
        payReq.setShipping_address_middle_name(shippingAddressConfig.getMiddleName());
        payReq.setShipping_address_last_name(shippingAddressConfig.getLastName());
        payReq.setShipping_address_line1(shippingAddressConfig.getLine1());
        payReq.setShipping_address_line2(shippingAddressConfig.getLine2());
        payReq.setShipping_address_city(shippingAddressConfig.getCity());
        payReq.setShipping_address_state(shippingAddressConfig.getState());
        payReq.setShipping_address_country(shippingAddressConfig.getCountry());
        payReq.setShipping_address_zip(shippingAddressConfig.getZip());

    }

    /**
     * 结果处理方法， paypal 和  微信、支付宝、银联 返回的结果不同
     *
     * @param dto
     * @param result
     * @return
     */
    public abstract PayOrderDTO doProcessResult(PayOrderDTO dto, String result);




}