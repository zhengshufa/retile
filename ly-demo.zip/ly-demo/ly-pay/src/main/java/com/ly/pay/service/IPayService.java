package com.ly.pay.service;

import com.ly.domain.api.R;
import com.ly.pay.entity.DTO.ChargeDTO;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.DTO.PayWayDTO;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.entity.VO.ChargeVO;
import com.ly.pay.entity.VO.PayOderVO;

import java.util.List;

/**
 * packageName.className com.ly.pay.service.IPayService
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 15:47
 * @description TODO
 */
public interface IPayService {

    /**
     * <p>
     * 发起支付的业务逻辑
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 15:58
     */
    R<PayOrderDTO> pay(PayOderVO payRequestVO);


    /**
     * <p>
     * 查询支付方式
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 15:58
     */
    R<List<PayWayDTO>> queryPayWay(String accountId);


    /***
     * <p>
     * 查询支付状态
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 15:58
     */
    R<PayOrderDTO> queryPayStatus(String partnerOrderNo);


    /**
     * 支付成功后通知处理
     * @param payOrder
     */
    void callSuccess(PayOrder payOrder);

    /**
     * <p>
     *  定时任务调用，进行回调补偿
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 15:58
     */
    void reInvoke();


    /**
     * 充值
     * @param chargeVO
     */
    R<ChargeDTO> charge(ChargeVO chargeVO);
}