package com.ly.pay.filter;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Custom request wrapper to allow reading the request body multiple times.
 */
public class BodyRequestWrapper extends HttpServletRequestWrapper {
    // The request body, stored as a byte array.
    private final byte[] body;
    // To read the body multiple times
    private final ByteArrayInputStream byteArrayInputStream;
    /**
     * Constructor that reads the request body and stores it as a byte array.
     *
     * @param request The original HttpServletRequest.
     * @throws IOException if an I/O error occurs.
     */
    public BodyRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        // Read the body of the request and store it as a byte array.
        String bodyString = HttpHelper.getBodyString(request);
        body = bodyString.getBytes(StandardCharsets.UTF_8);
        this.byteArrayInputStream = new ByteArrayInputStream(body);
    }

    /**
     * Returns a BufferedReader for reading the request body.
     *
     * @return BufferedReader
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream(), StandardCharsets.UTF_8));
    }

    /**
     * Returns a ServletInputStream to read the request body as bytes.
     *
     * @return ServletInputStream
     * @throws IOException if an I/O error occurs.
     */
    @Override
    public ServletInputStream getInputStream() throws IOException {
        // Reset the ByteArrayInputStream to allow reading from the start again.
        byteArrayInputStream.reset();

        return new ServletInputStream() {

            @Override
            public int read() throws IOException {
                return byteArrayInputStream.read();
            }

            @Override
            public boolean isFinished() {
                // Return true if all the bytes are read from the stream
                return byteArrayInputStream.available() == 0;
            }

            @Override
            public boolean isReady() {
                // Return true since the byte array is always ready to be read
                return true;
            }

            @Override
            public void setReadListener(ReadListener listener) {
                // No async support, we leave it empty.
            }
        };
    }
}
