package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.pay.common.enums.TaskStatusEnums;
import com.ly.pay.entity.PayTask;
import com.ly.pay.mapper.PayTaskMapper;
import com.ly.pay.service.IPayTaskService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.utils.DateUtil;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import static com.ly.pay.common.Constants.JOB_PROCESS_MAX_TIMES;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
@Service
public class PayTaskServiceImpl extends ServiceImpl<PayTaskMapper, PayTask> implements IPayTaskService {



    @Override
    public List<PayTask> queryByNextTime(Integer busiType) {
        QueryWrapper<PayTask>queryWrapper = new QueryWrapper<>();
        Date now = DateUtil.now();
        Date lastDate = DateUtil.minusDays(now,1);
        queryWrapper.le("next_process_time",now);
        queryWrapper.ge("next_process_time",lastDate);
        queryWrapper.eq("status", TaskStatusEnums.WAITING.getCode());
        queryWrapper.lt("process_times", JOB_PROCESS_MAX_TIMES);
        queryWrapper.lt("busi_type", busiType);
        queryWrapper.last(" limit 500");
        return this.list(queryWrapper);

    }
}
