package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2024-12-18 14：30：18
 */
@Getter
@Setter
@TableName("vst_partner_merchant")
public class PartnerMerchant extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 业务方编码
     */
    private String partnerCode;

    /**
     * 支付厂商编码
     */
    private String merchantCode;

    /**
     * 现金支付的渠道 1-微信 2-支付宝 3-银联 4-paypal 5-Visa 6-Master
     */
    private Integer vendor;

    /**
     * 分流比例0-100
     */
    private Integer diversionRatio;
}
