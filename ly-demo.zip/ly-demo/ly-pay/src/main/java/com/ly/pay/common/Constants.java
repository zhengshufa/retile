package com.ly.pay.common;

/**
 * packageName.className com.ly.pay.common.Constans
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 17:55
 * @description TODO
 */
public interface Constants {

    /**
     * 现金支付的超时时间 单位分钟
     */
    Integer CASH_PAY_TIME_OUT = 2 * 60;


    /**
     * 现金支付的超时时间 单位分钟
     */
    Integer BALANCE_AND_VST_POWER_PAY_TIME_OUT = 30;

    /**
     * 任务执行的最大次数
     */
    Integer JOB_PROCESS_MAX_TIMES = 5;
    /**
     * 处理间隔时间
     */
    Integer[] JOB_PROCESS_INTERVAL = {1,5,30,60,120};




}