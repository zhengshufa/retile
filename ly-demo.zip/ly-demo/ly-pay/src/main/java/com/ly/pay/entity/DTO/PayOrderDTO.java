package com.ly.pay.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * packageName.className com.ly.pay.entity.DTO.PayRequestDTO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:09
 * @description TODO
 */
@Schema(description = "支付订单返回对象")
@Data
@ToString
public class PayOrderDTO {
    /**
     * 支付订单号
     */
    @Schema(description = "支付订单号")
    private String payOrderNo;

    /**
     * 业务方订单号
     */
    @Schema(description = "业务方订单号")
    private String orderNo;

    /**
     * 业务方回调地址
     */
    @Schema(description = "业务方回调地址")
    private String callbackUrl;

    /**
     * 页面重定向地址
     */
    @Schema(description = "页面重定向地址")
    private String redirectUrl;

    /**
     * 页面重定向地址
     */
    @Schema(description = "用于调起渠道方sdk的订单信息，具体使用参见NihaoPay提供的IOS Demo or Android Demo。微信支付的In-app功能需要特殊流程，如果要开通，请联系NihaoPay获取帮助。")
    private String orderInfo;


    /**
     * 1-余额支付 2-算力支付 3-现金支付
     */
    @Schema(description = "支付类型，1-余额支付 2-算力支付 3-现金支付")
    private Integer payType;

    /**
     * 现金支付的回复方式1-微信 2-支付宝 3-银联 4-paypal
     */
    @Schema(description = "现金支付的回复方式，1-微信 2-支付宝 3-银联 4-paypal")
    private Integer vendor;

    /**
     * 单价
     */
    @Schema(description = "单价")
    private BigDecimal amount;

    /**
     * 数量
     */
    @Schema(description = "数量")
    private Integer count;

    /**
     * 总价
     */
    @Schema(description = "总价")
    private BigDecimal totalAmount;

    /**
     * 币种
     */
    @Schema(description = "币种")
    private String currency;

    /**
     * 支付标题
     */
    @Schema(description = "支付标题")
    private String title;

    /**
     * 备注
     */
    @Schema(description = "备注")
    private String note;

    /**
     * 扩展字段
     */
    @Schema(description = "扩展字段")
    private String extendParams;

    /**
     * 1-ANDROID 2-IOS 3-wap 4-pc
     */
    @Schema(description = "操作系统类型，1-ANDROID 2-IOS 3-wap 4-pc")
    private String osType;

    /**
     * 订单超时时间
     */
    @Schema(description = "订单超时时间")
    private Integer timeout;

    /**
     * 默认0-创建订单 1-支付中 2-支付成功 3-支付失败 4-已退款
     */
    @Schema(description = "订单状态，默认0-创建订单 1-支付中 2-支付成功 3-支付失败 4-已退款")
    private Integer status;


}