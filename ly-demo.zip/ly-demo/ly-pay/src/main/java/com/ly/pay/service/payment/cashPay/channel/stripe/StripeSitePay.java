package com.ly.pay.service.payment.cashPay.channel.stripe;

import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.Merchant;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.pay.service.IMerchantMapProductService;
import com.ly.pay.service.IMerchantService;
import com.ly.pay.service.IPayOrderService;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.FormatUtils;
import com.stripe.StripeClient;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.ly.pay.service.payment.PayContext.PRODUCT_ID;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.stripe.StripeSitePay
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-06 14:22
 * @description Stripe 网页支付
 */
@Slf4j
@Component
public class StripeSitePay {
    private final static String YOUR_DOMAIN = "http://111.0.90.8:9001/ly-pay/";
    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IPayOrderService iPayOrderService;

    @Autowired
    private StripeClient stripeClient;

    @Autowired
    private IMerchantMapProductService merchantMapProductService;

    public PayOrderDTO pay(PayContext payContext) {
        PayOrder payOrder = payContext.getPayOrder();
        Merchant merchant = merchantService.findByCode(payOrder.getMerchantNo());
        String vstProductId = (String) payContext.getPayRequestVO().getExtMap().get(PRODUCT_ID);
        payOrder.setMerchantNo(merchant.getMerchantCode());
        Session session = createSession(payOrder, vstProductId);

        log.info("session id={}, url={}", session.getId(), session.getUrl());
        String returnHtml = FormatUtils.formatUrl2Html(session.getUrl());
        PayOrderDTO payOrderDTO = payOrderDTOMapStruct.toDto(payOrder);
        payOrderDTO.setRedirectUrl(returnHtml);
        payOrder.setRemark(returnHtml);
        payOrder.setMerchantOrderNo(session.getId());
        iPayOrderService.updateByPayOrder(payOrder);
        return payOrderDTO;
    }


    private Session createSession(PayOrder payOrder, String vstProductId) {

        try {
            merchantMapProductService.findByProductIdAndProductId(payOrder.getMerchantNo(), vstProductId);
            SessionCreateParams params = SessionCreateParams.builder()
                    .setMode(SessionCreateParams.Mode.PAYMENT).setSuccessUrl(payOrder.getRedirectUrl())
                    .setCancelUrl(payOrder.getRedirectUrl())
                    .addLineItem(SessionCreateParams.LineItem.builder().setQuantity(1L)
                            // 提供你要销售产品的准确价格ID（例如，pr_1234）
                            //TODO 价格id需要变量
                            .setPrice("price_1QeB4YQSJYs4RczyLRyoa3aD").build()).build();
            return stripeClient.checkout().sessions().create(params);
        } catch (Exception e) {
            log.error("Stripe pay create payment intent error,userId={},payOrderNo={}", payOrder.getUserId(), payOrder.getPayOrderNo(), e);
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
    }


}