package com.ly.pay.service.callback.stripe;

import com.google.gson.JsonObject;
import com.ly.pay.entity.PayOrder;
import com.stripe.model.Event;

/**
 * packageName.className com.ly.pay.service.callback.stripe.EventHandler
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 16:21
 * @description TODO
 */
public interface EventHandler {

    PayOrder handle(Event event);
}