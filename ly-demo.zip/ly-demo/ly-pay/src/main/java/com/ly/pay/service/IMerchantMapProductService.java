package com.ly.pay.service;

import com.ly.pay.entity.MerchantMapProduct;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2025-01-08 09：20：27
 */
public interface IMerchantMapProductService extends IService<MerchantMapProduct> {


    /**
     * 根据合作商Id 和 vstProductId 查询
     * @param merchantId
     * @param productId
     * @return
     */
    MerchantMapProduct findByProductIdAndProductId(String merchantId, String productId);


}
