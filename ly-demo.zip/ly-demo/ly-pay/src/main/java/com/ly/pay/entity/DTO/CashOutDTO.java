package com.ly.pay.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * packageName.className com.ly.pay.entity.DTO.CashOutDTO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 17:54
 * @description TODO
 */
@Schema(description = "查询返回结果类")
@Data
public class CashOutDTO {

    /**
     * 用户id
     */
    @Schema(description = "用户id")
    private Long userId;

    /**
     * 业务线编号
     */
    @Schema(description = "业务线编号")
    private String partnerNo;

    /**
     * 请求订单号
     */
    @Schema(description = "请求订单号")
    private String requestOrderNo;

    /**
     * 支付系统订单号
     */
    @Schema(description = "支付系统订单号")
    private String payOrderNo;

    /**
     * 提现金额
     */
    @Schema(description = "提现金额")
    private BigDecimal amount;

    /**
     * 币种
     */
    @Schema(description = "币种")
    private String currency;

    /**
     * 银行卡
     */
    @Schema(description = "银行卡")
    private String bankCard;

    /**
     *  状态 0-默认 1-提现中 2-提现成功 3-提现失败 4-已退回
     */
    @Schema(description = "状态")
    private String status;




}