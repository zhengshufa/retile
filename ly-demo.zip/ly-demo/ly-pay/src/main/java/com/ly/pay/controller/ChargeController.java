package com.ly.pay.controller;

import com.ly.domain.api.R;
import com.ly.pay.entity.DTO.ChargeDTO;
import com.ly.pay.entity.VO.ChargeVO;
import com.ly.pay.service.IPayService;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * packageName.className com.ly.pay.controller.ChargeController
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:59
 * @description 充值接口
 */
@RestController
@RequestMapping("/charge")
@Schema(title = "充值相关接口")
@Slf4j
public class ChargeController {


    @Autowired
    private IPayService payService;

    /**
     * <p>
     * 支付请求接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping("/inner")
    @Schema(title = "内部充值接口")
    public R<ChargeDTO> chargeInner(@RequestBody ChargeVO chargeVO) {
        return payService.charge(chargeVO);
    }


}

