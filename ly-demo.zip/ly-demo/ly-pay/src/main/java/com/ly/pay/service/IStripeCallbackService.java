package com.ly.pay.service;

import com.ly.pay.entity.StripeCallback;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2025-01-09 14：39：44
 */
public interface IStripeCallbackService extends IService<StripeCallback> {

    /**
     * 更新
     * @param stripeCallback
     * @return
     */
    boolean updateByPaymentIntentId(StripeCallback stripeCallback);


    /**
     * 查询
     * @param paymentIntentId
     * @return
     */
    StripeCallback selectByPaymentIntent(String paymentIntentId);

}
