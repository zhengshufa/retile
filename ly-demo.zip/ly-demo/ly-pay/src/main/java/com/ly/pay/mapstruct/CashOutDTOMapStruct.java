package com.ly.pay.mapstruct;

import com.ly.mapstruct.BaseMapStruct;
import com.ly.pay.entity.CashOut;
import com.ly.pay.entity.DTO.CashOutDTO;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.PayOrder;
import org.mapstruct.Mapper;

/**
 * packageName.className com.ly.pay.mapstruct.PayOrderMapStruct
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 14:24
 * @description TODO
 */
@Mapper(componentModel = "spring")
public interface CashOutDTOMapStruct extends BaseMapStruct<CashOut, CashOutDTO> {


}