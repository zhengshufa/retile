package com.ly.pay.common.enums;


/**
 * <p>
 *  OSType 1-ANDROID 2-IOS 3-wap 4-pc
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum PayOsTypeEnum {
    // 待执行，对应数值0
    ANDROID(1, "ANDROID"),
    // 执行成功，对应数值1
    IOS(2, "IOS"),
    // 执行失败，对应数值2
    WAP(3, "WAP"),
    ONLINE(4, "ONLINE");

    private final int code;
    private final String description;

    PayOsTypeEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static PayOsTypeEnum fromCode(int code) {
        for (PayOsTypeEnum status : PayOsTypeEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }
}