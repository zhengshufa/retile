package com.ly.pay.service.payment.cashPay.channel;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.Channel;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.WeChatPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:32
 * @description TODO
 */
public class WeChatPay implements Channel {


    @Override
    public PayOrderDTO pay(PayContext payContext) {
        return null;
    }
}