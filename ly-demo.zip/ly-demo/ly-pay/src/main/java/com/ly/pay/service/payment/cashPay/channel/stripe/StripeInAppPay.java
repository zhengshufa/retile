package com.ly.pay.service.payment.cashPay.channel.stripe;

import com.alibaba.fastjson.JSON;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.Merchant;
import com.ly.pay.entity.POJO.CreatePaymentResponse;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.pay.service.IMerchantService;
import com.ly.pay.service.IPayOrderService;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.Channel;
import com.stripe.StripeClient;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.StripeBankCard
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-24 14:09
 * @description TODO
 */
@Slf4j
@Component
public class StripeInAppPay  {

    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;

    @Autowired
    private IMerchantService merchantService;

    @Autowired
    private IPayOrderService iPayOrderService;

    @Autowired
    private StripeClient stripeClient;

    @Autowired
    private StripeClientConfig stripeClientConfig;


    public PayOrderDTO pay(PayContext payContext) {
        PayOrder payOrder = payContext.getPayOrder();
        CreatePaymentResponse paymentResponse = createPaymentIntent(payOrder);
        PayOrderDTO payOrderDTO = payOrderDTOMapStruct.toDto(payOrder);
        payOrderDTO.setOrderInfo(JSON.toJSONString(paymentResponse));
        payOrder.setMerchantOrderNo(paymentResponse.getPaymentIntentId());
        iPayOrderService.updateByPayOrder(payOrder);
        return payOrderDTO;
    }


    public CreatePaymentResponse createPaymentIntent(PayOrder payOrder) {
        //因为乘了100，转换成了整数，所以转换后如果有小数，直接舍弃
        Long amount = payOrder.getAmount().longValue();
        PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                //单位是：分
                .setAmount(amount)
                //小写
                .setCurrency(payOrder.getCurrency().toLowerCase())
                //在客户端处理完 “next_actions” 之后，无需额外的确认操作即可完成支付。
                .setAutomaticPaymentMethods(PaymentIntentCreateParams.AutomaticPaymentMethods.builder().setEnabled(true).build())
                .build();

        try {
            PaymentIntent paymentIntent = stripeClient.paymentIntents().create(params);
            return new CreatePaymentResponse(paymentIntent.getClientSecret(), paymentIntent.getId(),stripeClientConfig.getStripeApiPubKey());
        } catch (Exception e) {
            log.error("Stripe pay create payment intent error,userId={},payOrderNo={}",payOrder.getUserId(),payOrder.getPayOrderNo(),e);
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
    }





}