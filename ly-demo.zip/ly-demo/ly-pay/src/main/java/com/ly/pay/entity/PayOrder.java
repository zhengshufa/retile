package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2025-01-17 14：15：44
 */
@Getter
@Setter
@TableName("vst_pay_order")
public class PayOrder extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 推荐码
     */
    private String referralCode;

    /**
     * 支付订单号
     */
    private String payOrderNo;

    /**
     * 业务方订单号
     */
    private String partnerOrderNo;

    /**
     * 业务方回调地址
     */
    private String partnerCallbackUrl;

    /**
     * 页面重定向地址
     */
    private String redirectUrl;

    /**
     * 商户订单号
     */
    private String merchantOrderNo;

    /**
     * 业务方编号
     */
    private String partnerNo;

    /**
     * 商户id
     */
    private String merchantNo;

    /**
     * 1-余额支付 2-算力支付 3-现金支付
     */
    private Integer payType;

    /**
     * 现金支付的回复方式1-微信 2-支付宝 3-银联 4-paypal
     */
    private Integer vendor;

    /**
     * 单价
     */
    private BigDecimal amount;

    /**
     * 数量
     */
    private Integer count;

    /**
     * 总价
     */
    private BigDecimal totalAmount;

    /**
     * 币种
     */
    private String currency;

    /**
     * 支付标题
     */
    private String title;

    /**
     * 备注
     */
    private String note;

    /**
     * 扩展字段
     */
    private String extendParams;

    /**
     * 1-ANDROID 2-IOS 3-wap 4-pc
     */
    private Integer osType;

    /**
     * 订单超时时间
     */
    private Integer timeout;

    /**
     * 备注
     */
    private String remark;
}
