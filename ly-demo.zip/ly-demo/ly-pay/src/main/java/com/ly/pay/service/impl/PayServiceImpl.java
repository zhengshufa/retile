package com.ly.pay.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.nacos.shaded.io.grpc.netty.shaded.io.netty.util.internal.StringUtil;
import com.ly.distribute.DistributeLock;
import com.ly.domain.api.R;
import com.ly.domain.api.ResultCode;
import com.ly.exception.BusinessException;
import com.ly.exception.PayBusinessException;
import com.ly.pay.common.Constants;
import com.ly.pay.common.enums.*;
import com.ly.pay.common.utils.PartnerHolder;
import com.ly.pay.entity.*;
import com.ly.pay.entity.DTO.ChargeDTO;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.DTO.PayWayDTO;
import com.ly.pay.entity.VO.ChargeVO;
import com.ly.pay.entity.VO.PayOderVO;
import com.ly.pay.mapstruct.ChargeDTOMapStruct;
import com.ly.pay.mapstruct.ChargeVOMapStruct;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.pay.mapstruct.PayOrderVOMapStruct;
import com.ly.pay.service.*;
import com.ly.pay.service.client.BalanceQueryClient;
import com.ly.pay.service.client.InvokeVstClient;
import com.ly.pay.service.client.RechargeBalanceClient;
import com.ly.pay.service.client.vo.ChargeBalanceReq;
import com.ly.pay.service.client.vo.QueryBalanceReq;
import com.ly.pay.service.client.vo.QueryBalanceRes;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.PaymentService;
import com.ly.utils.DateUtil;
import com.ly.utils.OrderNumberUtils;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.ly.domain.api.ResultCode.*;
import static com.ly.pay.common.Constants.JOB_PROCESS_INTERVAL;
import static com.ly.pay.common.Constants.JOB_PROCESS_MAX_TIMES;

/**
 * packageName.className com.ly.pay.service.impl.PayServiceImpl
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 15:47
 * @description 支付逻辑类
 */
@Slf4j
@Service
public class PayServiceImpl extends AbstractService implements IPayService {

    @Autowired
    private IPayTaskService taskService;
    @Autowired
    private IPayOrderService iPayOrderService;
    @Autowired
    private DistributeLock distributeLock;
    @Autowired
    private PaymentService paymentService;
    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;
    @Autowired
    private PayOrderVOMapStruct payOrderVOMapStruct;
    @Autowired
    private BalanceQueryClient balanceQueryClient;
    @Autowired
    private InvokeVstClient invokeVstClient;
    @Autowired
    private IPartnerMerchantService partnerMerchantService;
    @Autowired
    private ChargeVOMapStruct chargeVOMapStruct;
    @Autowired
    private ChargeDTOMapStruct chargeDTOMapStruct;
    @Autowired
    private IChargeService chargeService;
    @Value("${charge.maxCountOfDay}")
    private Integer maxCountOfDay;
    @Value("${charge.maxAmountOfCharge}")
    private Double maxAmountOfCharge;
    @Autowired
    private RechargeBalanceClient rechargeBalanceClient;

    private static final Integer CHARGE_REQUEST_OUT_TIME = 5000;

    @Override
    public R<PayOrderDTO> pay(PayOderVO payRequestVO) {
        //1、参数校验
        if (!isParamValid(payRequestVO)) {
            log.error("参数错误！");
            return R.fail(ResultCode.PARAM_MISS);
        }

        //2、填充默认值
        fillDefaultParam(payRequestVO);
        PayContext payContext = PayContext.builder().payRequestVO(payRequestVO).build();
        //3、先校验一次订单状态
        Partner partner = PartnerHolder.getPartner();
        PayOrder payOrder = iPayOrderService.queryByPartnerOrder(payRequestVO.getOrderNo(), partner.getPartnerCode());
        validOrderStatus(payRequestVO, payOrder);


        //4、分布式锁，防止重复提交
        String lockKey = payRequestVO.getUserId() + payRequestVO.getOrderNo();
        boolean isLock = false;
        try {
            isLock = distributeLock.tryLock(lockKey, 1000);
            if (isLock) {
                //4、再校验一次订单状态
                payOrder = iPayOrderService.queryByPartnerOrder(payRequestVO.getOrderNo(), partner.getPartnerCode());
                validOrderStatus(payRequestVO, payOrder);
                //订单存在，但是支付方式不同，则更新原订单，说明换了一种支付方式
                if (payOrder != null) {
                    payOrder.setAmount(payRequestVO.getAmount());
                    payOrder.setTotalAmount(payRequestVO.getTotalAmount());
                    payOrder.setVendor(payOrder.getVendor());
                    //需要更新订单的支付方式
                    iPayOrderService.updateById(payOrder);
                    //调用新的支付
                    payContext.setPayOrder(payOrder);
                    return R.data(paymentService.pay(payContext));
                }
                //如果订单不存在，则需要添加到数据库中
                PayOrder newPayOrder = payOrderVOMapStruct.toEntity(payRequestVO);
                newPayOrder.setStatus(PayOrderStatusEnum.PAYING.getCode());
                newPayOrder.setPayOrderNo(OrderNumberUtils.generateOrderNumber());
                newPayOrder.setPartnerNo(partner.getPartnerCode());
                newPayOrder.setPartnerOrderNo(payRequestVO.getOrderNo());
                newPayOrder.setPartnerCallbackUrl(payRequestVO.getCallbackUrl());
                newPayOrder.setRedirectUrl(payRequestVO.getRedirectUrl());
                newPayOrder.setReferralCode(payRequestVO.getReferralCode());
                iPayOrderService.save(newPayOrder);
                //调用支付
                payContext.setPayOrder(newPayOrder);
                return R.data(paymentService.pay(payContext));
            }
        } catch (BusinessException e) {
            ResultCode resultCode = e.getResultCode();
            log.error("process pay error ====> errorMsg={},errorCode={}", resultCode.getCode(), resultCode.getMessage(), e);
            return R.fail(resultCode);
        } finally {
            if (isLock) {
                distributeLock.unlock(lockKey);
            }
        }
        return R.fail(PARTNER_PAY_ORDER_EXIST);
    }


    private void validOrderStatus(PayOderVO payRequestVO, PayOrder payOrder) {
        if (payOrder != null && PayOrderStatusEnum.SUCCESS.getCode() == payOrder.getStatus()) {
            log.error("订单已完成！userId={},orderNo={}", payOrder.getCount(), payOrder.getPayOrderNo());
            throw new PayBusinessException(PARTNER_PAY_ORDER_FINISHED);
        }
        //订单存在，并且本次的付款方式和上次没有差异
        if (payOrder != null && payOrder.getVendor().equals(payRequestVO.getVendor())) {
            log.error("订单已存在！userId={},orderNo={}", payOrder.getCount(), payOrder.getPayOrderNo());
            throw new PayBusinessException(PARTNER_PAY_ORDER_EXIST);
        }
    }

    @Override
    public R<List<PayWayDTO>> queryPayWay(String accountId) {
        List<PayWayDTO> resultData = new ArrayList<>();
        Partner partner = PartnerHolder.getPartner();
        Set<Integer> vendors = partnerMerchantService.queryByPartnerCode(partner.getPartnerCode()).stream().map(PartnerMerchant::getVendor).collect(Collectors.toSet());
        Arrays.stream(VendorEnum.values()).forEach(vendor -> {
            if (!vendors.contains(vendor.getCode())) {
                return;
            }
            resultData.add(PayWayDTO.builder().name(vendor.getDesc()).code(vendor.getCode()).balance(null).build());
        });
        if (StringUtils.hasLength(accountId)) {
            QueryBalanceReq queryBalanceReq = new QueryBalanceReq();
            queryBalanceReq.setReferralCode(accountId);
            try {
                QueryBalanceRes queryBalanceRes = balanceQueryClient.queryBalance(queryBalanceReq);
                //设置支付方式name为balance，code为0
                resultData.add(PayWayDTO.builder().name(VendorEnum.BALANCE.getDesc()).code(VendorEnum.BALANCE.getCode()).balance(queryBalanceRes.getAvailableAmount()).build());
                log.warn("this times balance not enough account={}", accountId);

            } catch (Exception e) {
                //这里不抛出异常，如果没有查到 就不显示余额支付
                log.error("query balance error,accountId={}", accountId, e);
            }
        }
        if (resultData.isEmpty()) {
            throw new PayBusinessException(PARTNER_PAY_CHANNEL_NOT_FIND);
        }
        List<PayWayDTO> finalResultData = new ArrayList<>(resultData).stream().sorted(Comparator.comparing(PayWayDTO::getCode)).collect(Collectors.toList());
        return R.data(finalResultData);
    }

    @Override
    public R<PayOrderDTO> queryPayStatus(String partnerOrderNo) {
        Partner partner = PartnerHolder.getPartner();
        PayOrder payOrder = iPayOrderService.queryByPartnerOrder(partnerOrderNo, partner.getPartnerCode());
        if (payOrder == null) {
            return R.fail(ORDER_NOT_EXIST);
        }
        return R.data(payOrderDTOMapStruct.toDto(payOrder));
    }

    @Override
    public void callSuccess(PayOrder payOrder) {
        //先修改订单的状态
        payOrder.setStatus(PayOrderStatusEnum.SUCCESS.getCode());
        iPayOrderService.updateByPayOrder(payOrder);
        //这里不加事务，为了尽可能快，先把task入库
        PayTask payTask = new PayTask();
        payTask.setPayOrderNo(payOrder.getPayOrderNo());
        payTask.setStatus(TaskStatusEnums.WAITING.getCode());
        payTask.setProcessTimes(1);
        Date date = DateUtil.plusMinutes(new Date(), 1);
        payTask.setNextProcessTime(date);
        payTask.setBusiType(TaskBusiTypeEnum.PAY.getCode());
        taskService.save(payTask);
        //入库后立即调用一次
        try {
            String vstResult = invokeVstClient.notifyVst(payOrder);
            if ("OK".equals(vstResult)) {
                payTask.setStatus(TaskStatusEnums.SUCCESS.getCode());
                taskService.updateById(payTask);
            }
        } catch (Exception e) {
            log.error("invoke fail,payOrderNo={},partnerOrderNo={},userId={}", payOrder.getPayOrderNo(), payOrder.getPartnerOrderNo(), payOrder.getUserId(), e);
        }
    }


    /**
     * 设置默认值
     *
     * @param payRequestVO 请求参数
     */
    private void fillDefaultParam(PayOderVO payRequestVO) {
        if (payRequestVO.getCount() == null) {
            payRequestVO.setCount(1);
        }
        if (payRequestVO.getAmount() == null) {
            payRequestVO.setAmount(payRequestVO.getTotalAmount());
        }
        if (payRequestVO.getExtendParams() == null || payRequestVO.getExtendParams().isEmpty()) {
            payRequestVO.setExtendParams("-");
        } else {
            String extendParams = payRequestVO.getExtendParams();
            Map<String, Object> extMap = JSON.parseObject(extendParams, new TypeReference<>() {
            });
            payRequestVO.setExtMap(extMap);
        }
        if (payRequestVO.getNote() == null) {
            payRequestVO.setNote(payRequestVO.getTitle());
        }
        if (payRequestVO.getTimeout() == null) {
            if (payRequestVO.getPayType().equals(PayWayEnum.CASH.getCode())) {
                payRequestVO.setTimeout(Constants.CASH_PAY_TIME_OUT);
            } else {
                payRequestVO.setTimeout(Constants.BALANCE_AND_VST_POWER_PAY_TIME_OUT);
            }
        }
    }


    /**
     * @param payRequestVO 请求参数
     * @return boolean
     */
    private Boolean isParamValid(PayOderVO payRequestVO) {
        if (Objects.isNull(payRequestVO)) {
            return false;
        }
        if (Objects.isNull(payRequestVO.getOrderNo())) {
            log.error("订单好不能为空！");
            return false;
        }
        if (Objects.isNull(payRequestVO.getUserId())) {
            log.error("userId不能为空！");
            return false;
        }
        if (payRequestVO.getTotalAmount() == null || payRequestVO.getTotalAmount().doubleValue() <= 0) {
            log.error("金额设置错误，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        if (payRequestVO.getCurrency() == null) {
            log.error("币种不能为空，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        CurrencyUnitEnum currencyUnitEnum = CurrencyUnitEnum.fromCode(payRequestVO.getCurrency());
        if (currencyUnitEnum == null) {
            log.error("币种解析失败，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        if (payRequestVO.getPayType() == null) {
            log.error("支付方式不能为空，必须是(1-余额支付 2-算力支付 3-现金支付)中一种，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        PayWayEnum payWayEnum = PayWayEnum.fromCode(payRequestVO.getPayType());
        if (payWayEnum == null) {
            log.error("支付方式必须是(1-余额支付 2-算力支付 3-现金支付)中一种，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        if (StringUtil.isNullOrEmpty(payRequestVO.getTitle())) {
            log.error("支付名称不能为空，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }

        if (payRequestVO.getOsType() == null) {
            log.error("osType不能为空，必须是（1-ANDROID 2-IOS 3-wap 4-pc）中一种，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        PayOsTypeEnum payOsTypeEnum = PayOsTypeEnum.fromCode(payRequestVO.getOsType());
        if (payOsTypeEnum == null) {
            log.error("osType必须是（1-ANDROID 2-IOS 3-wap 4-pc）中一种，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        if (StringUtil.isNullOrEmpty(payRequestVO.getCallbackUrl())) {
            log.error("回调url不能为空，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        if (payRequestVO.getVendor() == null) {
            log.error("现金支付渠道不能为空，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        VendorEnum vendorEnum = VendorEnum.fromCode(payRequestVO.getVendor());
        if (vendorEnum == null) {
            log.error("现金支付渠道必须是供应商渠道 1-微信 2-支付宝 3-银联 4-paypal 之一，userId={},orderNo={}", payRequestVO.getUserId(), payRequestVO.getUserId());
            return false;
        }
        return true;
    }


    /***
     *
     */
    @Override
    public void reInvoke() {
        List<PayTask> taskList = taskService.queryByNextTime(TaskBusiTypeEnum.PAY.getCode());
        for (PayTask task : taskList) {
            PayOrder payOrder = iPayOrderService.queryByPayOrder(task.getPayOrderNo());
            if (payOrder == null) {
                log.error("payOrder is null,orderNo={}", task.getPayOrderNo());
                continue;
            }
            if (!payOrder.getStatus().equals(PayOrderStatusEnum.SUCCESS.getCode())) {
                log.error("this order is not success,orderNo={}", task.getPayOrderNo());
                continue;
            }
            try {
                String vstResult = invokeVstClient.notifyVst(payOrder);
                if (vstResult != null && vstResult.equals("OK")) {
                    task.setStatus(TaskStatusEnums.SUCCESS.getCode());
                    taskService.updateById(task);
                    continue;
                }
            } catch (Exception e) {
                log.error("this times notify is fail, payOrderNo={}", payOrder.getPayOrderNo());
            }
            Integer times = task.getProcessTimes();
            if (times >= JOB_PROCESS_MAX_TIMES) {
                log.error("this times notify is fail, process than 5 times, payOrderNo={}", payOrder.getPayOrderNo());
                task.setStatus(TaskStatusEnums.NOT_SUCCESS.getCode());
                taskService.updateById(task);
                continue;
            }
            times += 1;
            int minutes = JOB_PROCESS_INTERVAL[times];
            task.setProcessTimes(times);
            Date date = DateUtil.plusMinutes(new Date(), minutes);
            task.setNextProcessTime(date);
            taskService.updateById(task);
        }

    }

    @Override
    public R<ChargeDTO> charge(ChargeVO chargeVO) {
        //参数判断
        checkParams(chargeVO);

        //参数填充
        Charge charge = chargeVOMapStruct.toEntity(chargeVO);
        buildParams(chargeVO, charge);

        //分布式锁，防止重复提交
        String lockKey = chargeVO.getReferralCode() + chargeVO.getTradeNo();
        boolean isLock = false;
        try {
            isLock = distributeLock.tryLock(lockKey, 1000);
            //风控 单次额度判断 + 每日次数判断
            riskCheck(chargeVO);
            Charge newCharge = chargeService.queryByPartnerChargeNo(chargeVO.getTradeNo());
            if (newCharge != null) {
                throw new PayBusinessException(ORDER_NOT_EXIST);
            }
            //入库
            chargeService.save(charge);
            //调用会员充值
            ChargeBalanceReq chargeBalanceReq = new ChargeBalanceReq();
            chargeBalanceReq.setCreateTime(charge.getCreateTime());
            //会员系统定义1-分佣，2-提现，3-支付，4-充值
            chargeBalanceReq.setOperationType(4);
            chargeBalanceReq.setBillNo(chargeVO.getTradeNo());
            chargeBalanceReq.setAmount(chargeVO.getAmount());
            chargeBalanceReq.setReferralCode(chargeVO.getReferralCode());
            String orderNo = rechargeBalanceClient.rechargeBalance(chargeBalanceReq);
            if (orderNo == null) {
                throw new PayBusinessException(INTERNAL_SERVER_ERROR);
            }
            newCharge = chargeService.queryByPartnerChargeNo(chargeBalanceReq.getBillNo());
            newCharge.setStatus(ChargeOrderStatusEnum.SUCCESS.getCode());
            newCharge.setMemberChargeOrder(orderNo);
            chargeService.updateById(newCharge);
            log.info("charge success, payChargeNo={}, tradeNo={}, memberNo={}", newCharge.getPayChargeNo(), newCharge.getPartnerChargeNo(), orderNo);
            //返回结果
            ChargeDTO chargeDTO = chargeDTOMapStruct.toDto(newCharge);
            chargeDTO.setChargeNo(charge.getPayChargeNo());
            chargeDTO.setTradeNo(charge.getPartnerChargeNo());
            return R.data(chargeDTO);
        } catch (BusinessException e) {
            ResultCode resultCode = e.getResultCode();
            log.error("process pay error ====> tradeNo={},errorMsg={},errorCode={}",charge.getPartnerNo(), resultCode.getCode(), resultCode.getMessage(), e);
            return R.fail(resultCode);
        } finally {
            if (isLock) {
                distributeLock.unlock(lockKey);
            }
        }
    }

    /**
     * 填充参数
     *
     * @param chargeVO
     * @param charge
     */
    private void buildParams(ChargeVO chargeVO, Charge charge) {
        charge.setPayChargeNo(OrderNumberUtils.generateOrderNumber());
        charge.setPartnerChargeNo(chargeVO.getTradeNo());
        charge.setMerchantChargeNo("-");
        charge.setMerchantNo("-");
        charge.setStatus(ChargeOrderStatusEnum.DEFAULT.getCode());
        charge.setCreateTime(new Date());
        charge.setUpdateTime(charge.getCreateTime());
    }

    /**
     * 简单风控逻辑
     *
     * @param chargeVO
     */
    private void riskCheck(ChargeVO chargeVO) {
        //请求超过5秒钟不处理
        if (System.currentTimeMillis() - chargeVO.getTimestamp() > CHARGE_REQUEST_OUT_TIME) {
            throw new PayBusinessException(REQUEST_IS_EXPIRED);
        }
        //单次充值额度不能大于设定额度
        if (chargeVO.getAmount().compareTo(new BigDecimal(maxAmountOfCharge)) > 0) {
            throw new PayBusinessException(MAX_AMOUNT_OF_CHARGE);
        }
        //一天一个推荐码充值不能超过设置上线
        Long cnt = chargeService.queryCntByReferralCode(chargeVO.getReferralCode());
        if (cnt > maxCountOfDay) {
            throw new PayBusinessException(MAX_COUNT_OF_DAY);
        }
    }

    /**
     * 校验充值参数
     *
     * @param chargeVO 充值请求对象
     */
    private void checkParams(ChargeVO chargeVO) {
        if (chargeVO == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getUserId() == null || chargeVO.getReferralCode() == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getAmount() == null || new BigDecimal(String.valueOf(chargeVO.getAmount())).compareTo(BigDecimal.ZERO) <= 0) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getTimestamp() == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getCurrency() == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getTradeNo() == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
        if (chargeVO.getTitle() == null) {
            throw new PayBusinessException(PARAM_VALID_ERROR);
        }
    }

}