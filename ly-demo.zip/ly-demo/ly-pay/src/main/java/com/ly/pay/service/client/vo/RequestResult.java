package com.ly.pay.service.client.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * packageName.className com.ly.pay.service.payment.client.vo.PayResult
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-23 14:51
 * @description TODO
 */
@Data
public class RequestResult {
    @Schema(description = "状态码")
    private int code;
    @Schema(description = "是否成功")
    private boolean success;
    @Schema(description = "承载数据")
    private String data;
    @Schema(description = "返回消息")
    private String msg;

}