package com.ly.pay.service;

import com.ly.pay.entity.Partner;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-21-16 09：12：01
 */
public interface IPartnerService extends IService<Partner> {


    Partner queryByToken(String token);

}
