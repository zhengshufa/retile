package com.ly.pay.service.callback.stripe.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.ly.distribute.DistributeLock;
import com.ly.pay.common.RedisKey;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.entity.StripeCallback;
import com.ly.pay.service.IStripeCallbackService;
import com.ly.pay.service.callback.stripe.EventHandler;
import com.stripe.model.Event;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.callback.stripe.handler.PaymentIntentCreatedEvent
 * {
 *   "object": {
 *     "id": "pi_3QfEOpQSJYs4Rczy1zPJ6Ije",
 *     "object": "payment_intent",
 *     "amount": 5000,
 *     "amount_capturable": 0,
 *     "amount_details": {
 *       "tip": {}
 *     },
 *     "amount_received": 0,
 *     "application": null,
 *     "application_fee_amount": null,
 *     "automatic_payment_methods": null,
 *     "canceled_at": null,
 *     "cancellation_reason": null,
 *     "capture_method": "automatic_async",
 *     "client_secret": "pi_3QfEOpQSJYs4Rczy1zPJ6Ije_secret_Gbz9V9WiU6m71eO53cRbt6f49",
 *     "confirmation_method": "automatic",
 *     "created": 1736400919,
 *     "currency": "usd",
 *     "customer": null,
 *     "description": null,
 *     "invoice": null,
 *     "last_payment_error": null,
 *     "latest_charge": null,
 *     "livemode": false,
 *     "metadata": {},
 *     "next_action": null,
 *     "on_behalf_of": null,
 *     "payment_method": null,
 *     "payment_method_configuration_details": null,
 *     "payment_method_options": {
 *       "card": {
 *         "installments": null,
 *         "mandate_options": null,
 *         "network": null,
 *         "request_three_d_secure": "automatic"
 *       }
 *     },
 *     "payment_method_types": [
 *       "card"
 *     ],
 *     "processing": null,
 *     "receipt_email": null,
 *     "review": null,
 *     "setup_future_usage": null,
 *     "shipping": null,
 *     "source": null,
 *     "statement_descriptor": null,
 *     "statement_descriptor_suffix": null,
 *     "status": "requires_payment_method",
 *     "transfer_data": null,
 *     "transfer_group": null
 *   },
 *   "previous_attributes": null
 * }
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 17:06
 * @description TODO
 */
@Component
@Slf4j
public class PaymentIntentCreatedEvent implements EventHandler {

    @Autowired
    private IStripeCallbackService stripeCallbackService;

    @Autowired
    private DistributeLock distributeLock;

    @Override
    public PayOrder handle(Event event) {
        String json = event.getDataObjectDeserializer().getRawJson();
        JSONObject jsonObject = JSON.parseObject(json);
        String clientSecret = String.valueOf(jsonObject.get("client_secret"));
        String paymentIntentId = jsonObject.getString("id");
        log.info("handle========>PaymentIntentCreatedEvent,{}",paymentIntentId);
        String key = RedisKey.getPaymentIntentKey(paymentIntentId);
        boolean isLocked = distributeLock.tryLock(key,1000);
        try {
            if(isLocked){
                StripeCallback newStripeCallback =  stripeCallbackService.selectByPaymentIntent(paymentIntentId);
                if(newStripeCallback!=null){
                    newStripeCallback.setPaymentIntentId(paymentIntentId);
                    newStripeCallback.setClientSecret(clientSecret);
                    stripeCallbackService.updateById(newStripeCallback);
                }else{
                    StripeCallback stripeCallback = new StripeCallback();
                    stripeCallback.setPaymentIntentId(paymentIntentId);
                    stripeCallback.setClientSecret(clientSecret);
                    stripeCallbackService.save(stripeCallback);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }  finally {
            if(isLocked){
                distributeLock.unlock(key);
            }
        }

        return null;
    }
}