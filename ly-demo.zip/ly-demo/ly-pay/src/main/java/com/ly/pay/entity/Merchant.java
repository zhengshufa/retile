package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2024-12-18 16：54：49
 */
@Getter
@Setter
@TableName("vst_merchant")
public class Merchant extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 商户名称
     */
    private String merchantName;

    /**
     * 商户编码
     */
    private String merchantCode;

    /**
     * 商户描述
     */
    private String merchantDesc;

    /**
     * 请求地址
     */
    private String merchantInvokeUrl;

    /**
     * 查询地址
     */
    private String merchantQueryUrl;

    /**
     * 请求使用的token
     */
    private String token;
}
