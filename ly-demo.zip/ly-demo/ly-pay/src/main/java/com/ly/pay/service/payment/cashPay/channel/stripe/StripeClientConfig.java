package com.ly.pay.service.payment.cashPay.channel.stripe;

import com.ly.pay.filter.AuthFilter;
import com.stripe.StripeClient;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.stripe.StripeClientConfig
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-06 14:22
 * @description Stripe 网页支付
 */
@Getter
@Configuration
public class StripeClientConfig {

    //配置Stripe API密钥
    @Value("${stripe.api.key}")
    private String stripeApiKey;

    //配置Stripe API密钥
    @Value("${stripe.api.pubKey}")
    private String stripeApiPubKey;

    @Bean
    public StripeClient stripeClient() {
        return new StripeClient(stripeApiKey);
    }


}