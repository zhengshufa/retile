package com.ly.pay.service.payment.cashPay.channel.nihao.request;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


@Slf4j
public class HttpRequest {
	/**
	 * inquiry method
	 * 
	 * @param strURL 請求地址
	 * @param param 请求参数应该是 name1=value1&name2=value2 的形式。
	 * @param param token
	 * @return
	 */
	public static String sendAuthPost(String strURL, String param, String token) {
		StringBuilder result = new StringBuilder();
		PrintWriter out = null;
		BufferedReader in = null;
		HttpURLConnection conn = null;
		try {
			URL realUrl = new URL(strURL);
			conn = (HttpURLConnection) realUrl.openConnection();
			conn.addRequestProperty("Authorization", token);
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			out = new PrintWriter(conn.getOutputStream());
			out.print(param);
			out.flush();
			try {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} catch (Exception e) {
				in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}
			String line = "";
			while ((line = in.readLine()) != null) {
				result.append(line);
			}
		} catch (Exception e) {
			log.error("order pay error,url={},param={}",strURL,param,e);
			throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				log.error("流关闭异常=----！！param={}",param,ex);
			}
		}
		log.info("Post req success result:{}", result);
		return result.toString();
	}

	/**
	 * inquiry get method
	 * @param strURL 請求地址
	 * @param param 请求参数应该是 name1=value1&name2=value2 的形式。
	 * @param param token
	 */
	public static String sendAuthGet(String strURL, String param, String token) {
		StringBuilder result = new StringBuilder();
		PrintWriter out = null;
		BufferedReader in = null;
		HttpURLConnection conn = null;
		try {
			URL realUrl = new URL(strURL);
			conn = (HttpURLConnection) realUrl.openConnection();
			conn.setRequestMethod("GET");
			conn.addRequestProperty("Authorization", token);
			conn.setDoInput(true);
			if (StringUtils.isNotBlank(param)) {
				conn.setDoOutput(true);
				out = new PrintWriter(conn.getOutputStream());
				out.print(param);
				out.flush();
			}
			try {
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} catch (Exception e) {
				in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}
			String line = "";

			while ((line = in.readLine()) != null) {
				result.append(line);
			}
		} catch (Exception e) {
			log.error("order pay error,url={},param={}",strURL,param,e);
			throw new PayBusinessException("niHaoPay 请求支付异常！");
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				log.error("流关闭异常=----！！param={}",param,ex);
			}
		}
		log.info("Get request success result:{}", result);
		return result.toString();
	}

}
