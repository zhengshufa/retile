package com.ly.pay.common.utils;

import com.ly.pay.entity.Partner;

/**
 * packageName.className com.ly.pay.common.utils.UserHolder
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-17 17:01
 * @description TODO
 */
public class PartnerHolder {

    private static final ThreadLocal<Partner> threadLocal = new ThreadLocal<>();

    public static void putPartner(Partner partner) {
        threadLocal.set(partner);
    }

    public static Partner getPartner() {
        return threadLocal.get();
    }

}