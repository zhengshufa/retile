package com.ly.pay.service.payment.cashPay;

import com.ly.pay.service.payment.cashPay.enums.ChannelEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.impl.PaymentFactory
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:09
 * @description TODO
 */
@Component
@Slf4j
public class ChannelFactory {

    @Autowired
    private ApplicationContext applicationContext;

    public Channel creator(String code) {
        ChannelEnum channelEnum = ChannelEnum.fromCode(code);
        if(channelEnum == null){
            log.error("支付渠道不存在，code={}",code);
            return null;
        }
        return applicationContext.getBean(channelEnum.getClazz());
    }

}