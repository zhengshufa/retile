package com.ly.pay.service.callback.stripe;

import com.ly.pay.service.payment.cashPay.enums.ChannelEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.callback.stripe.HandlerFactory
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 17:15
 * @description TODO
 */
@Slf4j
@Component
public class HandlerFactory {
    @Autowired
    private ApplicationContext applicationContext;


    public EventHandler creator(String eventId){
        StripeEventEnum stripeEventEnum = StripeEventEnum.fromEvent(eventId);
        if(stripeEventEnum == null){
            log.warn("this event not find handler !! eventId={}",eventId);
            return null;
        }
        return applicationContext.getBean(stripeEventEnum.getClazz());
    }

}