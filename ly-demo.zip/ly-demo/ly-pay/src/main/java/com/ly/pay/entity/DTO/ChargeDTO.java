package com.ly.pay.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.NOT_REQUIRED;
import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.REQUIRED;

/**
 * packageName.className com.ly.pay.entity.VO.ChargeVO
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-15 11:43
 * @description TODO
 */
@Schema(description = "充值请求")
@Data
public class ChargeDTO {

    /**
     * 推荐码
     */
    @Schema(description = "充值交易号 需要保持唯一性，原样返回", requiredMode = REQUIRED)
    private String tradeNo;

    /**
     * 推荐码
     */
    @Schema(description = "我方充值订单号", requiredMode = REQUIRED)
    private String chargeNo;

    /**
     * 推荐码
     */
    @Schema(description = "推荐码 ，原样返回", requiredMode = REQUIRED)
    private String referralCode;

    /**
     * 金额
     */
    @Schema(description = "金额 单位为最小单位，美元对应的是美分，日元对应的是日元 ，原样返回", requiredMode = REQUIRED)
    private BigDecimal amount;

    /**
     * 推荐码
     */
    @Schema(description = "币种 ，原样返回", requiredMode = REQUIRED)
    private String currency;

    /**
     * 推荐码
     */
    @Schema(description = "时间戳 毫秒数 ，原样返回", requiredMode = REQUIRED)
    private Long timestamp;


    /**
     * 推荐码
     */
    @Schema(description = "标题，原样返回", requiredMode = REQUIRED)
    private String title;


    /**
     * 推荐码
     */
    @Schema(description = "扩展字段，json格式，原样返回", requiredMode = NOT_REQUIRED)
    private String extParams;

    /**
     * 推荐码
     */
    @Schema(description = "充值状态 0-默认订单生成 1-充值中 2-充值成功 3-充值失败 4-已退款", requiredMode = REQUIRED)
    private Integer status;

}