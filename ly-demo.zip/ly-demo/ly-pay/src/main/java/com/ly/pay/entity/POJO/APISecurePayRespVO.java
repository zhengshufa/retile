package com.ly.pay.entity.POJO;


import lombok.Data;
import lombok.ToString;

/**
 * 你好 pay 异步通知返回结果类
 */
@Data
@ToString
public class APISecurePayRespVO {

	private String id;
	private String status;
	private String amount;
	private String currency;
	private String time;
	private String reference;
	private String note;

}