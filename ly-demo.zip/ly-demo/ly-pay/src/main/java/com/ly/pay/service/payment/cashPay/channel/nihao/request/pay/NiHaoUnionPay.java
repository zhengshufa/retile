package com.ly.pay.service.payment.cashPay.channel.nihao.request.pay;

import com.ly.pay.service.payment.cashPay.channel.nihao.InAppPay;
import com.ly.pay.service.payment.cashPay.channel.nihao.Securepay;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.NiHaoUnionPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:35
 * @description niHaoPay的UnionPay
 */
@Service
public class NiHaoUnionPay extends Securepay {


}