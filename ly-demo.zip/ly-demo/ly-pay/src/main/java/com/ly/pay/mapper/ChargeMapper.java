package com.ly.pay.mapper;

import com.ly.pay.entity.Charge;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2025-01-21 09：34：59
 */
public interface ChargeMapper extends BaseMapper<Charge> {

}
