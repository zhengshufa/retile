package com.ly.pay.common.enums;


/**
 * <p>
 *  默认0-创建订单 1-支付中 2-支付成功 3-支付失败 4-已退款
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum ChargeOrderStatusEnum {
    DEFAULT(0, "默认"),
    PAYING(1, "充值付中"),
    SUCCESS(2, "充值成功"),
    FAIL(3, "充值失败"),
    REFUNDED(4, "已退款");

    private final int code;
    private final String description;

    ChargeOrderStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static ChargeOrderStatusEnum fromCode(int code) {
        for (ChargeOrderStatusEnum status : ChargeOrderStatusEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }
}