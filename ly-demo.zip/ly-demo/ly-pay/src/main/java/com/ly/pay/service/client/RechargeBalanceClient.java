package com.ly.pay.service.client;

import cn.hutool.core.date.DateUtil;
import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.service.client.vo.BalancePayReq;
import com.ly.pay.service.client.vo.ChargeBalanceReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName.className com.ly.pay.service.payment.client.BalancePayClient
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:15
 * @description TODO
 */
@Slf4j
@Component
public class RechargeBalanceClient extends AbstractClient<String> {

    @Value("${member.host}")
    private String memberHost;

    /***
     * 充值余额
     * @param req
     * @return
     * @throws Exception
     */
    public String rechargeBalance(ChargeBalanceReq req) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("referralCode", req.getReferralCode());
        paramMap.put("billNo", req.getBillNo());
        paramMap.put("amount", req.getAmount().toString());
        paramMap.put("operationType", req.getOperationType().toString());
        paramMap.put("createTime", DateUtil.now());
        try {
            return this.request(paramMap, String.class);
        } catch (Exception e) {
            log.error("rechargeBalance fail,referralCode={}, billNo={},amount={}",req.getReferralCode(),req.getBillNo(),req.getAmount());
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public String getInterPath() {
        return memberHost + "/ly-member/memberAccount/memberAccountAdd";
    }
}