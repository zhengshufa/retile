package com.ly.pay.common.utils;

import com.ly.pay.entity.POJO.RequestInfo;
import com.ly.pay.entity.Partner;

/**
 * packageName.className com.ly.pay.common.utils.RequestHolder
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-23 17:45
 * @description TODO
 */
public class RequestHolder {

    private static final ThreadLocal<RequestInfo> threadLocal = new ThreadLocal<>();

    public static void putRequestInfo(RequestInfo info) {
        threadLocal.set(info);
    }

    public static RequestInfo getRequestInfo() {
        return threadLocal.get();
    }
}