package com.ly.pay.mapper;

import com.ly.pay.entity.PayOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2025-01-17 14：15：44
 */
public interface PayOrderMapper extends BaseMapper<PayOrder> {

}
