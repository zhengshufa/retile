package com.ly.pay.service.payment.cashPay.channel.stripe;

import com.ly.pay.common.enums.PayOsTypeEnum;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.stripe.AbstractStripe
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-06 15:19
 * @description TODO
 */
@Component
public class StripePay implements Channel {

    @Autowired
    private StripeSitePay stripeSitePay;
    @Autowired
    private StripeInAppPay inAppPay;
    @Override
    public PayOrderDTO pay(PayContext payContext) {
        if(PayOsTypeEnum.WAP.getCode() == payContext.getPayOrder().getOsType()){
            return stripeSitePay.pay(payContext);
        }else{
            return inAppPay.pay(payContext);
        }
    }
}