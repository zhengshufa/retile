package com.ly.pay.common.enums;


/**
 * <p>
 *  供应商渠道 1-微信 2-支付宝 3-银行卡 4-paypal
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum VendorEnum {
    BALANCE(0, "balance"),
    WECHAT_PAY(1, "wechatpay"),
    ALIPAY(2, "alipay"),
    UNIONPAY(3, "unionpay"),
    PAYPAL(4, "paypal"),
    BANK_CARD(5, "Visa"),
    ;
    private final int code;
    private final String desc;

    VendorEnum(int code, String description) {
        this.code = code;
        this.desc = description;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static VendorEnum fromCode(int code) {
        for (VendorEnum status : VendorEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }
}