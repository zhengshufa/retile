package com.ly.pay.service.client.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

/**
 * packageName.className com.ly.pay.service.payment.client.vo.QueryBalanceReq
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:59
 * @description TODO
 */
@Data
public class QueryBalanceRes {
    @Schema(description = "用户id")
    private Long userId;

    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "用户昵称")
    private String nickname;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "总金额（总佣金）")
    private BigDecimal amount;

    @Schema(description = "可用余额")
    private BigDecimal availableAmount;

    @Schema(description = "已提现金额")
    private BigDecimal withdrawalAmount;

    @Schema(description = "状态")
    private Integer status;
}