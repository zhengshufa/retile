package com.ly.pay.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;

import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.REQUIRED;

/**
 * packageName.className com.ly.pay.entity.DTO.CashOutDTO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 17:54
 * @description TODO
 */
@Schema(description = "提现请求参数")
@Data
public class CashOutVO {

    /**
     * 用户id
     */
    @Schema(description = "用户id 必须", requiredMode = REQUIRED)
    private Long userId;



    /**
     * 请求订单号
     */
    @Schema(description = "请求订单号 必须", requiredMode = REQUIRED)
    private String orderNo;

    /**
     * 提现金额
     */
    @Schema(description = "提现金额 必须", requiredMode = REQUIRED)
    private BigDecimal amount;

    /**
     * 币种
     */
    @Schema(description = "币种 必须", requiredMode = REQUIRED)
    private String currency;


    /**
     * 业务方回调地址
     */
    @Schema(description = "后端回调业务方地址， 必须", requiredMode = REQUIRED)
    private String callbackUrl;


    /**
     * 银行卡
     */
    @Schema(description = "银行卡 必须", requiredMode = REQUIRED)
    private String bankCard;

    /**
     * 用户端ip地址
     */
    @Schema(description = "用户端ip地址，必须", requiredMode = REQUIRED)
    private String clientIp;

}