package com.ly.pay.mapper;

import com.ly.pay.entity.PartnerMerchant;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2024-12-18 14：30：18
 */
public interface PartnerMerchantMapper extends BaseMapper<PartnerMerchant> {

}
