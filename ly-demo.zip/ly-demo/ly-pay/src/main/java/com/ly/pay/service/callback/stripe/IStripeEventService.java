package com.ly.pay.service.callback.stripe;

import com.ly.pay.entity.PayOrder;
import com.stripe.model.Event;

/**
 * packageName.className com.ly.pay.service.callback.stripe.StripeEventService
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 17:28
 * @description TODO
 */
public interface IStripeEventService {


    PayOrder handleEvent(Event event);
}