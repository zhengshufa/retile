package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.pay.entity.Partner;
import com.ly.pay.mapper.PartnerMapper;
import com.ly.pay.service.IPartnerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-21-16 09：12：01
 */
@Service("partnerService")
public class PartnerServiceImpl extends ServiceImpl<PartnerMapper, Partner> implements IPartnerService {

    @Override
    public Partner queryByToken(String token) {
        QueryWrapper<Partner> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("partner_token",token);
        return this.getOne(queryWrapper);
    }
}
