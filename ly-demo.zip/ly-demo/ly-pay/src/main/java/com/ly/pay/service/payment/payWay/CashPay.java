package com.ly.pay.service.payment.payWay;

import com.ly.exception.PayBusinessException;
import com.ly.pay.common.utils.RandomWinUtil;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PartnerMerchant;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.IPartnerMerchantService;
import com.ly.pay.service.payment.Pay;
import com.ly.pay.service.payment.PayContext;
import com.ly.pay.service.payment.cashPay.ChannelFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static com.ly.domain.api.ResultCode.PARTNER_PAY_CHANNEL_NOT_FIND;

/**
 * packageName.className com.ly.pay.service.impl.payment.enums.CashPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 14:09
 * @description TODO
 */
@Component
public class CashPay implements Pay {

    @Autowired
    private IPartnerMerchantService partnerMerchantService;

    @Autowired
    private ChannelFactory channelFactory;


    @Override
    public PayOrderDTO pay(PayContext payContext) {
        PayOrder payOrder = payContext.getPayOrder();
        List<PartnerMerchant> vendorList = partnerMerchantService.queryByPartnerAndVendor(payOrder.getPartnerNo(),payOrder.getVendor());
        String merchantCode;
        if(vendorList.isEmpty()){
            throw new PayBusinessException(PARTNER_PAY_CHANNEL_NOT_FIND);
        }
        Map<String,Integer> map = new HashMap<>();
        vendorList.forEach(p->{
            map.put(p.getMerchantCode(),p.getDiversionRatio());
        });
        //根据配置的比例随机分流
        merchantCode =  RandomWinUtil.lottery(map);
        if(merchantCode == null){
            //理论上这里走不到
            throw new PayBusinessException(PARTNER_PAY_CHANNEL_NOT_FIND);
        }
        payOrder.setMerchantNo(merchantCode);
        payContext.setPayOrder(payOrder);
        return channelFactory.creator(merchantCode).pay(payContext);
    }

}