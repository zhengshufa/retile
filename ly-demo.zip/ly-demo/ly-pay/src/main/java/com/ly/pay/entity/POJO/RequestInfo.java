package com.ly.pay.entity.POJO;

import lombok.Builder;
import lombok.Data;

/**
 * packageName.className com.ly.pay.entity.POJO.RequestInfo
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-23 17:46
 * @description TODO
 */
@Data
@Builder
public class RequestInfo {

    private String appId;

    private String requestId;

}