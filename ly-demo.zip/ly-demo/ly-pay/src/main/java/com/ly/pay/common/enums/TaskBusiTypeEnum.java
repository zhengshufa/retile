package com.ly.pay.common.enums;

/**
 * packageName.className com.ly.pay.common.enums.TaskBusiTypeEnum
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-23 16:45
 * @description TODO
 */
public enum TaskBusiTypeEnum {
    PAY(1, "pay"),
    CASH_OUT(2, "cashOut"),
    ;

    private final int code;
    private final String desc;

    TaskBusiTypeEnum(int code, String description) {
        this.code = code;
        this.desc = description;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static TaskBusiTypeEnum fromCode(int code) {
        for (TaskBusiTypeEnum status : TaskBusiTypeEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }

}