package com.ly.pay.common.enums;


import com.ly.pay.service.payment.payWay.BalancePay;
import com.ly.pay.service.payment.payWay.CashPay;
import com.ly.pay.service.payment.Pay;
import com.ly.pay.service.payment.payWay.VstPowerPay;

/**
 * <p>
 * 支付方式 1-余额支付 2-算力支付 3-现金支付
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum PayWayEnum {
    // 待执行，对应数值0
    BALANCE(1, "余额支付", BalancePay.class),
    // 执行成功，对应数值1
    VST_POW(2, "算力支付", VstPowerPay.class),
    // 执行失败，对应数值2
    CASH(3, "现金支付", CashPay.class);

    private final int code;
    private final String description;
    private final Class<? extends Pay> clazz;

    PayWayEnum(int code, String description, Class<? extends Pay> clazz) {
        this.code = code;
        this.description = description;
        this.clazz = clazz;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public Class<? extends Pay> getClazz() {
        return clazz;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static PayWayEnum fromCode(int code) {
        for (PayWayEnum status : PayWayEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }
}