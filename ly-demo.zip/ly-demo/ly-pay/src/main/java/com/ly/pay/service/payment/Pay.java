package com.ly.pay.service.payment;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PayOrder;

/**
 * packageName.className com.ly.pay.service.impl.payment.Pay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 14:11
 * @description 支付接口
 */
public interface Pay {


    PayOrderDTO pay(PayContext payContext);


}