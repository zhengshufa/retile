package com.ly.pay.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * packageName.className com.ly.pay.entity.DTO.CashOutDTO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 17:54
 * @description TODO
 */
@Schema(description = "提现结果查询请求参数")
@Data
public class CashQueryVO {

    /**
     * 用户id
     */
    @Schema(description = "用户id 必须")
    private Long userId;

    /**
     * 业务线编号
     */
    @Schema(description = "业务线编号 必须")
    private String partnerOrderNo;

}