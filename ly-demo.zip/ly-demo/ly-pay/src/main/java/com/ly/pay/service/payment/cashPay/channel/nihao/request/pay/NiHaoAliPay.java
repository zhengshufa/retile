package com.ly.pay.service.payment.cashPay.channel.nihao.request.pay;

import com.ly.pay.service.payment.cashPay.channel.nihao.InAppPay;
import com.ly.pay.service.payment.cashPay.channel.nihao.Securepay;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.NiHaoAliPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:33
 * @description niHaoPay的alipay
 */
@Service
public class NiHaoAliPay extends Securepay {


}