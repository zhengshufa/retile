package com.ly.pay;

import com.ly.utils.HttpUtils;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@SpringBootApplication
@EnableDiscoveryClient
@MapperScan("com.ly.pay.mapper")
@ComponentScan(basePackages = {"com.ly.*","com.ly.pay.controller"})
@ServletComponentScan
@Configuration
@Slf4j
@RefreshScope
public class LyPayApplication {
    @Autowired
    private Environment environment;
    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(LyPayApplication.class, args);
        Environment environment = context.getEnvironment();
        int i = 0;
        while (i<10){

            try {
                Thread.sleep(100);
                String url = "http://111.0.90.8:9001/ly-pay/health";
               // String url = "http://localhost:"+environment.getProperty("server.port")+"/health";
                String result = HttpUtils.sendGetRequest(url);
                log.info(result);
              //  String url = "http://111.0.90.8:9001/ly-pay/health";
                  url = "http://localhost:"+environment.getProperty("server.port")+"/health";
                 result = HttpUtils.sendGetRequest(url);
                log.info(result);
                if(result.contains("\"success\":true")){
                    log.info("application start success !!!");
                    break;
                }
            } catch (Exception e) {
                log.error("health test fail",e);
            }
            i++;
        }

    }

}
