package com.ly.pay.entity.DTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * packageName.className com.ly.pay.entity.DTO.PayWayDTO
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:36
 * @description TODO
 */
@Schema(description = "支付方式查询返回结果类")
@Data
@Builder
public class PayWayDTO {
    /**
     * 支付方式编码
     */
    @Schema(description = "支付方式编码")
    private Integer code;
    /**
     * 支付方式名称
     */
    @Schema(description = "支付方式名称")
    private String name;


    @Schema(description = "余额")
    private BigDecimal balance;

}