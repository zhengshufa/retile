package com.ly.pay.service.payment;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.payment.payWay.PayWayFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.impl.payment.PaymentService
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 13:50
 * @description TODO
 */
@Component
public class PaymentService {

    @Autowired
    private PayWayFactory payWayFactory;

    public PayOrderDTO pay(PayContext payContext){
        return payWayFactory.creator(payContext.getPayOrder().getPayType()).pay(payContext);
    }
}