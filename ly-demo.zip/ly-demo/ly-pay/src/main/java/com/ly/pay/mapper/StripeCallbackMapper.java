package com.ly.pay.mapper;

import com.ly.pay.entity.StripeCallback;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2025-01-09 14：39：44
 */
public interface StripeCallbackMapper extends BaseMapper<StripeCallback> {

}
