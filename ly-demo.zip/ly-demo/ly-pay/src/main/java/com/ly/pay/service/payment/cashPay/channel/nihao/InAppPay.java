package com.ly.pay.service.payment.cashPay.channel.nihao;

import com.alibaba.fastjson.JSON;
import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.impl.payment.channel.nihao.NihaoWeChatPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:33
 * @description niHaoPay的微信支付
 */
@Slf4j
@Service
public class InAppPay extends AbstractNiHao {

    @Override
    public PayOrderDTO doProcessResult(PayOrderDTO dto, String result) {
        PayResult payResult = JSON.parseObject(result, PayResult.class);
        dto.setRedirectUrl(payResult.getRedirectUrl());
        dto.setOrderInfo(payResult.getOrderInfo());
        return dto;
    }
}