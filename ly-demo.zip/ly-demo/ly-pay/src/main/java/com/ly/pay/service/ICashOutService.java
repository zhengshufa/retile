package com.ly.pay.service;

import com.ly.domain.api.R;
import com.ly.pay.entity.CashOut;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ly.pay.entity.DTO.CashOutDTO;
import com.ly.pay.entity.VO.CashOutVO;
import com.ly.pay.entity.VO.CashQueryVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-12-23 09：14：19
 */
public interface ICashOutService extends IService<CashOut> {


    /**
     * <p>
     *  支付请求接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    R<CashOutDTO> cashOut( CashOutVO cashOutVO);


    /**
     * <p>
     * 支付方式查询接口
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    R<CashOutDTO> query( CashQueryVO cashQueryVO) ;


}
