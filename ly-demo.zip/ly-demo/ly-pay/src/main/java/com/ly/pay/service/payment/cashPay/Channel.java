package com.ly.pay.service.payment.cashPay;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.payment.PayContext;

/**
 * packageName.className com.ly.pay.service.impl.payment.PaymentChannel
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:11
 * @description 支付渠道
 */

public interface Channel {


    PayOrderDTO pay(PayContext payContext);

}