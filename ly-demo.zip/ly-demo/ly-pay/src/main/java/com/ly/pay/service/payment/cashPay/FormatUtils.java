package com.ly.pay.service.payment.cashPay;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.FormatUtils
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-23 13:34
 * @description TODO
 */
public class FormatUtils {



    /**
     * 将url 格式化给html
     * @param url
     * @return
     */
    public static String formatUrl2Html(String url){
        String returnHtml = "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" +
                "<head>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n" +
                "    <title>Waiting</title>\n" +
                "    <style>\n" +
                "                body{text-align:center;overflow:auto} div{ margin:0 auto; width:320px;}  .loader{margin-top:40vh;border:16px solid #f3f3f3;border-radius:50%;border-top:16px solid #3498db;width:120px;height:120px;-webkit-animation:spin 2s linear infinite;animation:spin 2s linear infinite}@-webkit-keyframes spin{0%{-webkit-transform:rotate(0deg)}100%{-webkit-transform:rotate(360deg)}}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}        \n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"loader\"></div>\n" +
                "<div>\n" +
                "    <form id=\"pay_form\" name=\"pay_form\" action=\"***\" method=\"GET\"\n" +
                "          target=\"_self\"></form>\n" +
                "</div>\n" +
                "</body>\n" +
                "<script>\n" +
                "    \t\tdocument.forms[0].submit();\t\twindow.onload = function (){          document.getElementById(\"loading\").style=\"display:none\";       }\t\n" +
                "</script>\n" +
                "</html>\n";

        return returnHtml.replace("***",url);
    }




    /**
     * 将url 格式化给html
     * @param url
     * @return
     */
    public static String formatUrl2HtmlForCard(String url){
        String returnHtml = "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n" +
                "<head>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n" +
                "    <title>Waiting</title>\n" +
                "    <style>\n" +
                "        body{text-align:center;overflow:auto} div{ margin:0 auto; width:320px;}  .loader{margin-top:40vh;border:16px solid #f3f3f3;border-radius:50%;border-top:16px solid #3498db;width:120px;height:120px;-webkit-animation:spin 2s linear infinite;animation:spin 2s linear infinite}@-webkit-keyframes spin{0%{-webkit-transform:rotate(0deg)}100%{-webkit-transform:rotate(360deg)}}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"loader\"></div>\n" +
                "<div>\n" +
                "    <form id=\"pay_form\" name=\"pay_form\" action=\"https://apitest.nihaopay.com/v1.2/cardpay/checkout/20250123055421100137?otp=2s18L9xteyXuMjCXqES0WLIQU7F\" method=\"GET\"\n" +
                "          target=\"_self\">\n" +
                "\n" +
                "    </form>\n" +
                "</div>\n" +
                "</body>\n" +
                "<script>\n" +
                "    window.location.href=\"***\"\n" +
                "</script>\n" +
                "</html>";

        return returnHtml.replace("***",url);
    }

}