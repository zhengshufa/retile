package com.ly.pay.service.client.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ly.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * packageName.className com.ly.pay.service.client.vo.ChargeBalanceReq
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-17 10:22
 * @description TODO
 */
@Schema(description = "余额充值请求vo")
@Data
public class ChargeBalanceReq {


    @Schema(description = "推荐码")
    private String referralCode;

    @Schema(description = "操作类型（1-分佣，2-提现，3-支付，4-充值）")
    private Integer operationType;

    @Schema(description = "创建时间/操作时间/支付时间")
    @JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    private Date createTime;

    @Schema(description = "金额")
    private BigDecimal amount;

    @Schema(description = "第三方订单号（提现和支付的情况下才有）")
    private String billNo;


}