package com.ly.pay.common.utils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * packageName.className com.ly.pay.common.utils.RandomWinUtils
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-19 15:16
 * @description 按比例随机抽奖工具类
 */
public class RandomWinUtil {

    public static String lottery(Map<String,Integer> map) {
        if (map == null || map.isEmpty()) {
            return null; // 表示没有可抽奖的用户，返回一个特殊值，可根据实际情况调整
        }
        int totalProbability = 0;
        for (String key : map.keySet()) {
            totalProbability += map.get(key);
        }
        Random random = new Random();
        int randomNumber = random.nextInt(totalProbability);
        int cumulativeProbability = 0;
        for (String key : map.keySet()) {
            cumulativeProbability += map.get(key);
            if (randomNumber < cumulativeProbability) {
                return key;
            }
        }
        return null; // 正常情况下不会执行到这，只是为了符合语法要求，可根据实际优化
    }


    public static void main(String[] args) {
        Map<String, Integer> map = new ConcurrentHashMap<>();
        Map<String, Integer> userMap = new ConcurrentHashMap<>();
        userMap.put("1", 20);
        userMap.put("2", 30);
        userMap.put("3", 50);
        for (int i=0;i<10000;i++){
            String winnerId = lottery(userMap);
            if(map.containsKey(winnerId)){
                Integer c = map.get(winnerId);
                c++;
                map.put(winnerId, c);
            }else{
                map.put(winnerId,1);
            }

        }

        System.out.println(map);

    }
}

