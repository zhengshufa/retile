package com.ly.pay.service.payment.payWay;

import com.ly.exception.PayBusinessException;
import com.ly.pay.common.enums.PayWayEnum;
import com.ly.pay.service.payment.Pay;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import static com.ly.domain.api.ResultCode.PARTNER_PAY_WAY_NOT_FIND;

/**
 * packageName.className com.ly.pay.service.impl.PaymentFactory
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:09
 * @description TODO
 */
@Component
@Slf4j
public class PayWayFactory {

    @Autowired
    private ApplicationContext applicationContext;

    public Pay creator(Integer payWay) {
        PayWayEnum payWayEnum = PayWayEnum.fromCode(payWay);
        if(payWayEnum == null){
            throw new PayBusinessException(PARTNER_PAY_WAY_NOT_FIND);
        }
        return applicationContext.getBean(payWayEnum.getClazz());
    }

}