package com.ly.pay.service.payment.cashPay.enums;


/**
 * packageName.className com.ly.pay.service.impl.payment.enums.PaymentChannelEnum
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:13
 * @description 业务方对应的商户是否开启枚举
 */
public enum PartnerMerchantStatusEnum {
    OPENED(0, "opened"),
    CLOSED(1, "closed"),
    ;

    private final int code;
    private final String desc;

    PartnerMerchantStatusEnum(int code, String description) {
        this.code = code;
        this.desc = description;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static PartnerMerchantStatusEnum fromCode(int code) {
        for (PartnerMerchantStatusEnum status : PartnerMerchantStatusEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }

}