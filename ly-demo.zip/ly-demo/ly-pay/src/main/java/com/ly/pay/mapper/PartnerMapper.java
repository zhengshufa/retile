package com.ly.pay.mapper;

import com.ly.pay.entity.Partner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2024-08-17 11：12：14
 */
public interface PartnerMapper extends BaseMapper<Partner> {

}
