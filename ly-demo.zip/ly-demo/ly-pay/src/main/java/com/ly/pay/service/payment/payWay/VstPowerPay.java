package com.ly.pay.service.payment.payWay;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.POJO.PayResult;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.payment.Pay;
import com.ly.pay.service.payment.PayContext;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.impl.payment.VstPowerPay
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 14:08
 * @description TODO
 */
@Component
public class VstPowerPay implements Pay {


    @Override
    public PayOrderDTO pay(PayContext payContext) {
        //算力支付不走支付系统
        return null;
    }
}