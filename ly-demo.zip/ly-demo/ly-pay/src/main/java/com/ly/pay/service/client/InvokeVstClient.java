package com.ly.pay.service.client;

import com.ly.pay.entity.DTO.PayOrderDTO;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapstruct.PayOrderDTOMapStruct;
import com.ly.utils.OrderNumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.TreeMap;

/**
 * packageName.className com.ly.pay.service.payment.client.BalanceQueryClient
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-20 15:14
 * @description TODO
 */
@Component
public class InvokeVstClient extends AbstractClient<String> {

    @Value("${vstApp.host}")
    private String memberHost;

    @Autowired
    private PayOrderDTOMapStruct payOrderDTOMapStruct;

    public String notifyVst(PayOrder payOrder) throws Exception {
        PayOrderDTO payOrderDTO = payOrderDTOMapStruct.toDto(payOrder);
        String invokeUrl = payOrder.getPartnerCallbackUrl();
        return this.vstRequest(convertPayOrderDTOToMap(payOrderDTO),String.class,invokeUrl,"pay-server", OrderNumberUtils.generateOrderNumber());
    }
    @Override
    public String getInterPath() {
        return memberHost;
    }



    public static Map<String,Object> convertPayOrderDTOToMap(PayOrderDTO payOrderDTO) {
        TreeMap<String,Object> resultMap = new TreeMap<>();
        if (payOrderDTO == null) {
            return resultMap;
        }
        resultMap.put("payOrderNo", payOrderDTO.getPayOrderNo());
        resultMap.put("orderNo", payOrderDTO.getOrderNo());
        resultMap.put("callbackUrl", payOrderDTO.getCallbackUrl());
        resultMap.put("redirectUrl", payOrderDTO.getRedirectUrl());
        resultMap.put("orderInfo", payOrderDTO.getOrderInfo());
        resultMap.put("payType", payOrderDTO.getPayType());
        resultMap.put("vendor", payOrderDTO.getVendor());
        resultMap.put("amount", payOrderDTO.getAmount());
        resultMap.put("count", payOrderDTO.getCount());
        resultMap.put("totalAmount", payOrderDTO.getTotalAmount());
        resultMap.put("currency", payOrderDTO.getCurrency());
        resultMap.put("title", payOrderDTO.getTitle());
        resultMap.put("note", payOrderDTO.getNote());
        resultMap.put("extendParams", payOrderDTO.getExtendParams());
        resultMap.put("osType", payOrderDTO.getOsType());
        resultMap.put("timeout", payOrderDTO.getTimeout());
        resultMap.put("status", payOrderDTO.getStatus());
        return resultMap;
    }
}