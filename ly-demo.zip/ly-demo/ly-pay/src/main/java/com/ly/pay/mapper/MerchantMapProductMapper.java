package com.ly.pay.mapper;

import com.ly.pay.entity.MerchantMapProduct;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author alaric
 * @since 2025-01-08 17：18：15
 */
public interface MerchantMapProductMapper extends BaseMapper<MerchantMapProduct> {

}
