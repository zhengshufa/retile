package com.ly.pay.common.enums;


/**
 * <p>
 *  默认0-创建订单 1-提现中 2-支付成功 3-支付失败 4-已退款
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */
public enum CashOutOrderStatusEnum {
    DEFAULT(0, "默认"),
    WITHDRAWING (1, "提现中"),
    SUCCESS(2, "提现成功"),
    FAIL(3, "提现失败"),
    Refunded(4, "已退款");

    private final int code;
    private final String description;

    CashOutOrderStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    // 根据状态码获取对应的枚举实例，方便在外部通过状态码来获取相应的枚举对象
    public static CashOutOrderStatusEnum fromCode(int code) {
        for (CashOutOrderStatusEnum status : CashOutOrderStatusEnum.values()) {
            if (status.getCode() == code) {
                return status;
            }
        }
        return null;
    }
}