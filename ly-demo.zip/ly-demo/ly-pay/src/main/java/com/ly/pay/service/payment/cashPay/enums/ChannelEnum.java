package com.ly.pay.service.payment.cashPay.enums;

import com.ly.pay.service.payment.cashPay.Channel;
import com.ly.pay.service.payment.cashPay.channel.nihao.request.pay.*;
import com.ly.pay.service.payment.cashPay.channel.stripe.StripePay;
import lombok.Getter;

/**
 * packageName.className com.ly.pay.service.impl.payment.enums.PaymentChannelEnum
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 11:13
 * @description 支付渠道枚举
 */
@Getter
public enum ChannelEnum {
    NI_HAO_WECHAT("1001", "wechatPay", NiHaoWeChatPay.class),
    NI_HAO_ALIPAY("1002", "alipay", NiHaoAliPay.class),
    NI_HAO_UNION_PAY("1003", "unionPay", NiHaoUnionPay.class),
    NI_HAO_PAYPAL("1004", "paypal", NiHaoPayPal.class),
    NI_HAO_VISA("1005", "Visa", NiHaoVisaPay.class),
    STRIPE_BANK_CARD("1050", "stripe_card", StripePay.class),

    ;


    private final String code;
    private final String desc;
    private final Class<? extends Channel> clazz;

    ChannelEnum(String code, String description, Class<? extends Channel> clazz) {
        this.code = code;
        this.desc = description;
        this.clazz = clazz;
    }

    public static ChannelEnum fromCode(String code) {
        for (ChannelEnum status : ChannelEnum.values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return null;
    }

}