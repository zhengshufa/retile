package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2025-01-08 17：18：15
 */
@Getter
@Setter
@TableName("vst_merchant_map_product")
public class MerchantMapProduct extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 商家编码
     */
    private String merchantCode;

    /**
     * vst商品编码
     */
    private String vstProductId;

    /**
     * 商家商品id
     */
    private String merchantProductId;

    /**
     * 商家商品价格id
     */
    private String merchantProductPriceId;

    /**
     * 扩展字段 json
     */
    private String extParams;
}
