package com.ly.pay.service.payment.cashPay.channel.nihao;

import com.ly.domain.api.ResultCode;
import com.ly.exception.PayBusinessException;
import com.ly.pay.entity.DTO.PayOrderDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.nihao.Securepay
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-23 10:33
 * @description TODO
 */
@Slf4j
@Service
public class Securepay  extends AbstractNiHao {


    @Override
    public PayOrderDTO doProcessResult(PayOrderDTO dto, String result) {
        if (!result.startsWith("<html")) {
            log.error("invoke niHao pay error, error msg={}, dto={}", result, dto);
            throw new PayBusinessException(ResultCode.INTERNAL_SERVER_ERROR);
        }
        dto.setRedirectUrl(result);
        return dto;
    }
}