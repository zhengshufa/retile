package com.ly.pay.controller;

import com.google.gson.JsonSyntaxException;
import com.ly.pay.entity.Merchant;
import com.ly.pay.entity.POJO.APISecurePayRespVO;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.service.IMerchantService;
import com.ly.pay.service.IPayOrderService;
import com.ly.pay.service.IPayService;
import com.ly.pay.service.callback.stripe.IStripeEventService;
import com.ly.utils.MD5;
import com.stripe.model.Event;
import com.stripe.model.EventDataObjectDeserializer;
import com.stripe.net.ApiResource;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 * packageName.className com.ly.pay.controller.NiHaoPayCallBack
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-14 14:59
 * @description niHaoPay通知回调类
 */
@RestController
@RequestMapping("callback")
@Schema(title = "通知回调类")
@Slf4j
public class ThirdBusiCallBack {


    @Autowired
    private IPayOrderService payOrderService;
    @Autowired
    private IMerchantService merchantService;
    @Autowired
    private IPayService payService;

    @Autowired
    private IStripeEventService iStripeEventService;

    /**
     * <p>
     * 你好pay通知回调
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @PostMapping(value = "/niHao")
    public @ResponseBody void niHao(HttpServletResponse response, HttpServletRequest request,
                                      APISecurePayRespVO respVO) {
        try {
            log.info(getClientInfo(request));
            log.info(respVO.toString());
            Map<String, String[]> params = request.getParameterMap();
            if (params.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
            }
            log.info(request.getParameter("id"));
            Set<String> keySet = params.keySet();
            List<String> keyList = new ArrayList<String>(keySet);
            Collections.sort(keyList);
            StringBuilder mdStr = new StringBuilder();
            for (String key : keyList) {
                String value = params.get(key)[0];
                if (!"verify_sign".equals(key) && params.get(key) != null && value != null && !"null".equals(value)) {
                    mdStr.append(key).append("=").append(value).append("&");
                }
            }
            if (respVO.getReference() == null) {
                writeResult(response, "fail");
                return;
            }
            PayOrder payOrder = payOrderService.queryByPayOrder(respVO.getReference());
            if (payOrder == null) {
                writeResult(response, "fail");
                return;
            }
            Merchant merchant = merchantService.findByCode(payOrder.getMerchantNo());
            mdStr.append(MD5.sign(merchant.getToken(), "", "utf-8").toLowerCase());
            String verifySign = params.get("verify_sign")[0];
            String sign = MD5.sign(mdStr.toString(), "", "utf-8").toLowerCase();
            log.info("sign={},verify_sign={}", sign, verifySign);
            String resultStr = "fail";
            if (sign.equals(verifySign)) {
                payOrder.setMerchantOrderNo(respVO.getId());
                payService.callSuccess(payOrder);
                resultStr = "ok";
            }
            writeResult(response, resultStr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }


    private void writeResult(HttpServletResponse response, String resultStr) throws IOException {
        response.setHeader("Content-type", "application/json");
        response.getWriter().print(resultStr);
        response.flushBuffer();
    }

    /**
     * <p>
     * 你好pay通知回调
     * </p>
     * 作者：alaric
     * 日期：2024/12/14 14:33
     */
    @GetMapping(value = "/niHaoHtml")
    public @ResponseBody void niHaoHtml(HttpServletResponse response, HttpServletRequest request,
                                        APISecurePayRespVO respVO) {
        try {
            log.info("IPN request:");
            log.info(getClientInfo(request));
            log.info(respVO.toString());
            BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            log.info("getInputStream to String: {}", sb.toString());
            Map<String, String[]> params = request.getParameterMap();
            if (params.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
            }
            log.info(request.getParameter("id"));
            StringBuilder str = new StringBuilder();
            str.append("Form Data:");
            for (String key : params.keySet()) {
                String[] values = params.get(key);
                for (String value : values) {
                    str.append("\r\n ").append(key).append(" -> ").append(value);
                }
            }
            Set<String> keySet = params.keySet();
            List<String> keyList = new ArrayList<String>(keySet);
            Collections.sort(keyList);
            StringBuilder mdStr = new StringBuilder();
            for (String key : keyList) {
                String value = params.get(key)[0];
                if (!"verify_sign".equals(key) && params.get(key) != null && value != null && !"null".equals(value)) {
                    mdStr.append(key).append("=").append(value).append("&");
                }
            }
            log.info("sign prams string:{}", mdStr.toString());
            PayOrder payOrder = payOrderService.queryByPayOrder(respVO.getReference());
            Merchant merchant = merchantService.findByCode(payOrder.getMerchantNo());
            mdStr.append(MD5.sign(merchant.getToken(), "", "utf-8").toLowerCase());
            log.info("prams and token sign string:{}", mdStr.toString());
            String verifySign = params.get("verify_sign")[0];
            String sign = MD5.sign(mdStr.toString(), "", "utf-8").toLowerCase();
            log.info("sign string:{}", sign);
            log.info("verify_sign string:{}", verifySign);
            String resultStr = "fail";
            if (sign.equals(verifySign)) {
                str.append("\r\n sign_vlidated -> true");
            } else {
                str.append("\r\n sign_vlidated -> false");
            }
            log.info("IPN: {}", str.toString());
            response.setHeader("Content-type", "application/json");
            response.getWriter().print(str);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }


    @PostMapping(value = "/stripe")
    public void stripe(HttpServletResponse response, HttpServletRequest request, @RequestBody String payload) throws IOException {
        log.info("stripe payload={}", payload);
        Event event = null;
        try {
            event = ApiResource.GSON.fromJson(payload, Event.class);

            // Deserialize the nested object inside the event
            EventDataObjectDeserializer dataObjectDeserializer = event.getDataObjectDeserializer();

            if (dataObjectDeserializer.getRawJson() == null) {
                response.setStatus(HttpStatus.SC_BAD_REQUEST);
                response.getWriter().write("");
                response.getWriter().flush();
                return;
            }
            String stripeObject = dataObjectDeserializer.getRawJson();
            log.info("stripe callback param={}", stripeObject);
            //开始处理
            PayOrder payOrder = iStripeEventService.handleEvent(event);
            if(payOrder != null){
                payService.callSuccess(payOrder);
            }
            response.setStatus(HttpStatus.SC_OK);
            response.getWriter().write("");
            response.getWriter().flush();

        } catch (Exception e) {
            log.info("this callback fail, payload={}",payload,e);
            response.setStatus(HttpStatus.SC_BAD_REQUEST);
            response.getWriter().write("");
            response.getWriter().flush();
        }
    }

    public String getClientInfo(HttpServletRequest request) {
        StringBuilder str = new StringBuilder();
        str.append("\r\n ----------New Request---------------");
        str.append("\r\n RequestURL:").append(request.getRequestURL());
        str.append("\r\n Request Header");
        str.append("\r\n Origin:").append(request.getHeader("Origin"));
        str.append("\r\n Referer:").append(request.getHeader("Referer"));
        str.append("\r\n Accept:").append(request.getHeader("Accept"));
        str.append("\r\n Host:").append(request.getHeader("Host"));
        str.append("\r\n User-Agent:").append(request.getHeader("User-Agent"));
        str.append("\r\n Locale:").append(request.getLocale());
        str.append("\r\n Protocol:").append(request.getProtocol());
        str.append("\r\n Scheme:").append(request.getScheme());
        str.append("\r\n Connection:").append(request.getHeader("Connection"));
        str.append("\r\n Character Encoding:").append(request.getCharacterEncoding());
        str.append("\r\n Content Type:").append(request.getContentType());
        str.append("\r\n Content Length:").append(request.getContentLength());
        str.append("\r\n Http Method:").append(request.getMethod());
        str.append("\r\n Remote Addr: ").append(request.getRemoteAddr());
        str.append("\r\n Remote Host: ").append(request.getRemoteHost());
        str.append("\r\n Remote Port: ").append(request.getRemotePort());
        str.append("\r\n Remote User: ").append(request.getRemoteUser());
        str.append("\r\n Query String: ").append(request.getQueryString());
        str.append("\r\n Form Data:");
        Map<String, String[]> params = request.getParameterMap();
        for (String key : params.keySet()) {
            String[] values = params.get(key);
            for (String value : values) {
                str.append("\r\n ").append(key).append(" -> ").append(value);
            }
        }
        str.append("\r\n ----------End Request---------------");
        return str.toString();
    }
}