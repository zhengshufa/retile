package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.pay.entity.PayOrder;
import com.ly.pay.mapper.PayOrderMapper;
import com.ly.pay.service.IPayOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-35-17 16：12：20
 */
@Service
public class PayOrderServiceImpl extends ServiceImpl<PayOrderMapper, PayOrder> implements IPayOrderService {

    @Override
    public PayOrder queryByPartnerOrder(String partnerOrder,String partnerNo) {
        QueryWrapper<PayOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("partner_order_no",partnerOrder);
        queryWrapper.eq("partner_no",partnerNo);
        return this.getOne(queryWrapper);
    }

    @Override
    public PayOrder queryByPayOrder(String payOrderNo) {
        QueryWrapper<PayOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pay_order_no",payOrderNo);
        return this.getOne(queryWrapper);
    }

    @Override
    public boolean updateByPayOrder(PayOrder payOrder) {
        QueryWrapper<PayOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pay_order_no",payOrder.getPayOrderNo());
        return this.update(payOrder, queryWrapper);
    }


    @Override
    public PayOrder queryByMerchantOrder(String merchantOrderNo) {
        QueryWrapper<PayOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("merchant_order_no",merchantOrderNo);
        return this.getOne(queryWrapper);
    }

}
