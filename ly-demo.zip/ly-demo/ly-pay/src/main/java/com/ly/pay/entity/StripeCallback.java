package com.ly.pay.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ly.domain.BaseEntity;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2025-01-09 14：39：44
 */
@Getter
@Setter
@TableName("vst_stripe_callback")
public class StripeCallback extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 结账SessionId
     */
    private String checkoutSessionId;

    /**
     * 支付意图id
     */
    private String paymentIntentId;

    /**
     * 客户端密串
     */
    private String clientSecret;

    /**
     * 付费id
     */
    private String chargeId;

    /**
     * 收据url
     */
    private String receiptUrl;

    /**
     * json 存放付费成功通知事件
     */
    private String eventChargeSucceeded;

    /**
     * json 存放支付意图成功事件
     */
    private String eventPaymentIntentSucceeded;

    /**
     * json 存放结账session完成的事件
     */
    private String eventSessionCompleted;
}
