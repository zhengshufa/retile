package com.ly.pay.service;

import com.ly.pay.entity.PayOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author alaric
 * @since 2024-12-27 18：21：59
 */
public interface IPayOrderService extends IService<PayOrder> {

    /**
     * 根据用户订单查询
     * @param partnerOrder
     * @return
     */
    PayOrder queryByPartnerOrder(String partnerOrder,String partnerNo);


    /**
     * 根据用户订单查询
     * @param payOrderNo
     * @return
     */
    PayOrder queryByPayOrder(String payOrderNo);



    /**
     * 根据
     * @param payOrder
     * @return
     */
    boolean updateByPayOrder(PayOrder payOrder);



    PayOrder queryByMerchantOrder(String merchantOrderNo);
}
