package com.ly.pay.service.payment.cashPay.channel.nihao.request;

import lombok.Data;

/**
 * packageName.className com.ly.pay.service.payment.cashPay.channel.nihao.req.NhPayReq
 *
 * @author alaric
 * @version JDK 17
 * @date 2024-12-18 16:06
 * @description TODO
 */
@Data
public class NhPayReq {

    private String url;
    private String callback_url;
    private String show_url;
    private String ipn_url;
    private String vendor;
    private String reference;
    private String amount;
    private String rmb_amount;
    private String currency;
    private String description;
    private String terminal;
    private String timeout;
    private String note;
    private String token;
    private String response_format;


    //card
    private String website;
    // 客户端ip
    private String client_ip;


    //名字
    private String shipping_address_first_name;
    //中间名
    private String shipping_address_middle_name;
    //姓.
    private String shipping_address_last_name;
    // 地址第一行. 不为空
    private String shipping_address_line1;
    // 地址第二行. 允许为空
    private String shipping_address_line2;
    // 城市 不为空
    private String shipping_address_city;
    // 州/省/直辖市. 不能为空
    private String shipping_address_state;
    // 邮政编码. 不为空
    private String shipping_address_zip;
    //国家地区代码 ISO-3166-1两位字母代码. 不为空
    private String shipping_address_country;


    public String getInput() {
        StringBuilder result = new StringBuilder();
        result.append("callback_url=").append(callback_url).append("&ipn_url=").append(ipn_url).append("&vendor=").append(vendor);
        result.append("&reference=").append(reference).append("&currency=").append(currency);

        if (!(amount == null || amount.isEmpty())) {
            result.append("&amount=").append(amount);
        }

        if (!(rmb_amount == null || rmb_amount.isEmpty())) {
            result.append("&rmb_amount=").append(rmb_amount);
        }
        if (!(description == null || description.isEmpty())) {
            result.append("&description=").append(description);
        }
        if (!(terminal == null || terminal.isEmpty())) {
            result.append("&terminal=").append(terminal);
        }
        if (!(timeout == null || timeout.isEmpty())) {
            result.append("&timeout=").append(timeout);
        }
        if (!(note == null || note.isEmpty())) {
            result.append("&note=").append(note);
        }
        if (!(show_url == null || show_url.isEmpty())) {
            result.append("&show_url=").append(show_url);
        }

        if (!(client_ip == null || client_ip.isEmpty())) {
            result.append("&client_ip=").append(client_ip);
        }
        if (!(website == null || website.isEmpty())) {
            result.append("&website=").append(website);
        }
        if (!(website == null || website.isEmpty())) {
            result.append("&website=").append(website);
        }

        if (!(shipping_address_first_name == null || shipping_address_first_name.isEmpty())) {
            result.append("&shipping_address_first_name=").append(shipping_address_first_name);
        }
        if (!(shipping_address_middle_name == null || shipping_address_middle_name.isEmpty())) {
            result.append("&shipping_address_middle_name=").append(shipping_address_middle_name);
        }
        if (!(shipping_address_last_name == null || shipping_address_last_name.isEmpty())) {
            result.append("&shipping_address_last_name=").append(shipping_address_last_name);
        }
        if (!(shipping_address_line1 == null || shipping_address_line1.isEmpty())) {
            result.append("&shipping_address_line1=").append(shipping_address_line1);
        }
        if (!(shipping_address_line2 == null || shipping_address_line2.isEmpty())) {
            result.append("&shipping_address_line2=").append(shipping_address_line2);
        }
        if (!(shipping_address_city == null || shipping_address_city.isEmpty())) {
            result.append("&shipping_address_city=").append(shipping_address_city);
        }
        if (!(shipping_address_state == null || shipping_address_state.isEmpty())) {
            result.append("&shipping_address_state=").append(shipping_address_state);
        }
        if (!(shipping_address_country == null || shipping_address_country.isEmpty())) {
            result.append("&shipping_address_country=").append(shipping_address_country);
        }
        if (!(shipping_address_zip == null || shipping_address_zip.isEmpty())) {
            result.append("&shipping_address_zip=").append(shipping_address_zip);
        }

        return result.toString();
    }


    @Override
    public String toString() {
        return "APISecurePayReqVO [url=" + url + ", callback_url="
                + callback_url + ", show_url=" + show_url + ", ipn_url="
                + ipn_url + ", vendor=" + vendor + ", reference=" + reference
                + ", amount=" + amount + ", rmb_amount=" + rmb_amount
                + ", currency=" + currency + ", description=" + description
                + ", terminal=" + terminal + ", timeout=" + timeout + ", note="
                + note + ", token=" + token + "]";
    }

}