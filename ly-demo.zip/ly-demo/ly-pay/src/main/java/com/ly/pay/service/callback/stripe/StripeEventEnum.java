package com.ly.pay.service.callback.stripe;

import com.ly.pay.service.callback.stripe.handler.*;
import com.ly.pay.service.payment.payWay.BalancePay;
import com.ly.pay.service.payment.payWay.CashPay;
import com.ly.pay.service.payment.payWay.VstPowerPay;
import lombok.Getter;

/**
 * packageName.className com.ly.pay.service.callback.stripe.StripeEventEnum
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 15:57
 * @description TODO
 */
@Getter
public enum StripeEventEnum {

    PAYMENT_INTENT_CREATED("payment_intent.created", PaymentIntentCreatedEvent.class),
    CHARGE_SUCCEEDED("charge.succeeded", ChargeSucceededEvent.class),
    PAYMENT_INTENT_SUCCEEDED("payment_intent.succeeded", PaymentIntentSucceededEvent.class),
    CHECKOUT_SESSION_COMPLETED("checkout.session.completed", CheckoutSessionCompletedEvent.class),
    CHARGE_UPDATED("charge.updated", ChargeUpdateEvent.class),
    REFUND_CREATE("refund.create", RefundCreateEvent.class),
    REFUND_UPDATED("refund.updated", RefundUpdateEvent .class),
    charge_dispute_create("charge.dispute.create", ChargeDisputeCreateEvent .class),

    ;
    private final String eventId;

    private final Class<? extends EventHandler> clazz;

    StripeEventEnum(String eventId, Class<? extends EventHandler> clazz) {
        this.eventId = eventId;
        this.clazz = clazz;
    }


    static StripeEventEnum fromEvent(String eventId){
        for(StripeEventEnum eventEnum:StripeEventEnum.values()){
            if(eventEnum.eventId.equals(eventId)){
                return eventEnum;
            }
        }
        return null;
    }
}