package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.pay.entity.Merchant;
import com.ly.pay.mapper.MerchantMapper;
import com.ly.pay.service.IMerchantService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-14-17 11：12：44
 */
@Service
public class MerchantServiceImpl extends ServiceImpl<MerchantMapper, Merchant> implements IMerchantService {

    @Override
    public Merchant findByCode(String code) {
        LambdaQueryWrapper<Merchant> query = new LambdaQueryWrapper<>();
        query.eq(Merchant::getMerchantCode, code);
        return this.getOne(query);
    }
}
