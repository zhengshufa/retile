package com.ly.pay.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ly.pay.entity.PartnerMerchant;
import com.ly.pay.mapper.PartnerMerchantMapper;
import com.ly.pay.service.IPartnerMerchantService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ly.pay.service.payment.cashPay.enums.PartnerMerchantStatusEnum;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author alaric
 * @since 2024-50-18 10：12：11
 */
@Service
public class PartnerMerchantServiceImpl extends ServiceImpl<PartnerMerchantMapper, PartnerMerchant> implements IPartnerMerchantService {

    @Override
    public List<PartnerMerchant> queryByPartnerAndVendor(String partnerNo, Integer vendor) {
        LambdaQueryWrapper<PartnerMerchant>  lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(PartnerMerchant::getPartnerCode,partnerNo)
                .eq(PartnerMerchant::getVendor,vendor)
                .eq(PartnerMerchant::getStatus, PartnerMerchantStatusEnum.OPENED.getCode());
        return this.list(lambdaQueryWrapper);
    }

    @Override
    public List<PartnerMerchant> queryByPartnerCode(String partnerCode) {
        LambdaQueryWrapper<PartnerMerchant>  lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(PartnerMerchant::getPartnerCode,partnerCode)
                .eq(PartnerMerchant::getStatus, PartnerMerchantStatusEnum.OPENED.getCode());
        return this.list(lambdaQueryWrapper);
    }
}
