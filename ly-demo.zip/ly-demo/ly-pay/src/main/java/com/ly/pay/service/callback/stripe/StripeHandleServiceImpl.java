package com.ly.pay.service.callback.stripe;

import com.ly.pay.entity.PayOrder;
import com.stripe.model.Event;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName.className com.ly.pay.service.callback.stripe.StripeHandleServiceImpl
 *
 * @author alaric
 * @version JDK 17
 * @date 2025-01-09 17:29
 * @description TODO
 */
@Slf4j
@Component
public class StripeHandleServiceImpl implements IStripeEventService{

    @Autowired
    private HandlerFactory handlerFactory;


    @Override
    public PayOrder handleEvent(Event event) {
        EventHandler eventHandler = handlerFactory.creator(event.getType());
        if(eventHandler == null){
            log.warn("this event don't handle!!");
            return null;
        }
        return handlerFactory.creator(event.getType()).handle(event);
    }

}