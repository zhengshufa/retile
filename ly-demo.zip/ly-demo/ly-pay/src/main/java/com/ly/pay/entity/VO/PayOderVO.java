package com.ly.pay.entity.VO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Map;

import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.NOT_REQUIRED;
import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.REQUIRED;

/**
 * <p>
 * 
 * </p>
 *
 * @author alaric
 * @since 2024-24-14 13：12：59
 */

@Schema(description = "支付请求VO")
@Data
public class PayOderVO implements Serializable {
    /**
     * 购买用户userId
     */
    @Schema(description = "购买用户userId 必须", requiredMode = REQUIRED)
    private Long userId;

    /**
     * 购买用户userId
     */
    @Schema(description = "购买用户推荐码，余额支付的时候必须传", requiredMode = REQUIRED)
    private String referralCode;
    /**
     * 业务方订单号
     *
     */
    @Schema(description = "请求支付的订单号，在业务系统中必须唯一， 必须", requiredMode = REQUIRED)
    private String orderNo;

    /**
     * 业务方回调地址
     */
    @Schema(description = "后端回调业务方地址， 必须", requiredMode = REQUIRED)
    private String callbackUrl;

    /**
     * 页面重定向地址
     */
    @Schema(description = "页面重定向地址，在wap或者pc h5调用的时候用，paypal支付h5页面 特定场景必须", requiredMode = REQUIRED)
    private String redirectUrl;

    /**
     * 1-余额支付 2-算力支付 3-现金支付
     */
    @Schema(description = "支付方式 1-余额支付 2-算力支付 3-现金支付 ，必须", requiredMode = REQUIRED)
    private Integer payType;

    /**
     * 现金支付的渠道 1-微信 2-支付宝 3-银联 4-paypal
     */
    @Schema(description = "现金支付的渠道：1-微信 2-支付宝 3-银联 4-paypal 必须", requiredMode = REQUIRED)
    private Integer vendor;

    /**
     * 单价
     */
    @Schema(description = "单价，可选", requiredMode = NOT_REQUIRED)
    private BigDecimal amount;

    /**
     * 数量
     */
    @Schema(description = "数量，可选", requiredMode = NOT_REQUIRED)
    private Integer count;

    /**
     * 总价
     */
    @Schema(description = "总价，必须", requiredMode = REQUIRED)
    private BigDecimal totalAmount;

    /**
     * 币种
     */
    @Schema(description = "总价，必须", requiredMode = REQUIRED)
    private String currency;

    /**
     * 支付标题
     */
    @Schema(description = "支付标题，必须", requiredMode = REQUIRED)
    private String title;

    /**
     * 备注
     */
    @Schema(description = "支付标题，可选，如果没有的话，默认跟标题一致", requiredMode = NOT_REQUIRED)
    private String note;

    /**
     * 扩展字段
     */
    @Schema(description = "扩展参数，可选", requiredMode = NOT_REQUIRED)
    private String extendParams;

    /**
     * 1-ANDROID 2-IOS 3-wap 4-pc
     */
    @Schema(description = "1-ANDROID 2-IOS 3-WAP 4-PC 必须", requiredMode = REQUIRED)
    private Integer osType;

    /**
     * 订单超时时间
     */
    @Schema(description = "订单超时时间,单位：分钟，余额支付、算力支付默认30分钟，三方支付默认2小时，可选", requiredMode = NOT_REQUIRED)
    private Integer timeout;

    /**
     * extendParams 解下出来的值
     */
    @Schema(hidden=true)
    private Map<String,Object> extMap;

}
