package com.ly.pay;

import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.builder.ConfigBuilder;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.ly.domain.BaseEntity;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;

import static com.baomidou.mybatisplus.generator.config.rules.DateType.ONLY_DATE;

@Slf4j
public class CodeGenerator {

    public static void main(String[] args) {
        // 全局配置
        GlobalConfig globalConfig = new GlobalConfig.Builder()
                .author("alaric")
                .outputDir(System.getProperty("user.dir") + "/ly-pay/src/main/java")
                .disableOpenDir()
                .commentDate("yyyy-MM-dd HH：mm：ss")
                .dateType(ONLY_DATE)
                .build();
        // 数据源配置
        DataSourceConfig dataSourceConfig = new DataSourceConfig.Builder("jdbc:mysql://192.168.1.23:3306/vst_pay?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC", "ly", "qwert@123")
                .driverClassName("com.mysql.cj.jdbc.Driver")
                .build();

        // 策略配置
        StrategyConfig strategyConfig = new StrategyConfig.Builder()
               // .addExclude("_xxx")
                .addInclude("vst_charge11")
                .addTablePrefix("vst_")
                .entityBuilder().enableLombok().enableFileOverride()
                .superClass(BaseEntity.class)
                .entityBuilder().enableLombok().enableFileOverride().addSuperEntityColumns("id", "status", "create_time", "is_deleted", "update_time")
                .mapperBuilder().enableFileOverride()
                .serviceBuilder().enableFileOverride()
                .controllerBuilder().disable()
                .build();
        // 包配置
        PackageConfig packageConfig = new PackageConfig.Builder()
                .parent("com.ly.pay")
                .controller("controller")
                .service("service")
                .serviceImpl("service.impl")
                .entity("entity")
                .mapper("mapper")
                .xml("mapper")
                .build();
        TemplateConfig templateConfig = new TemplateConfig.Builder()
                .controller("")
                .xml(null)
                .build();
        // 整合配置
        AutoGenerator autoGenerator = new AutoGenerator(dataSourceConfig);
        ConfigBuilder configBuilder = new ConfigBuilder(packageConfig, dataSourceConfig, strategyConfig, templateConfig, globalConfig, null);
        autoGenerator.config(configBuilder);
        autoGenerator.execute(new FreemarkerTemplateEngine());
        log.info("Generator success!!");
    }

}