---
title: VST-Pay
language_tabs:
  - shell: Shell
  - http: HTTP
  - javascript: JavaScript
  - ruby: Ruby
  - python: Python
  - php: PHP
  - java: Java
  - go: Go
toc_footers: []
includes: []
search: true
code_clipboard: true
highlight_theme: darkula
headingLevel: 2
generator: "@tarslib/widdershins v4.0.23"

---

# VST-Pay

Base URLs:http://serviceIP:port/ly-pay/

# Authent[VST-Pay.md](../../../../文档/支付接口文档v1.0/VST-Pay.md)ication

VST项目支付接口统一用RSA非对称加密方式签名，即用接入方的私钥签名，VST支付服务端用接入方的公钥验签。
接口返回结果，支付系统会用私钥签名，接入方需要使用支付系统的公钥验签。
可根据demo提供的工具RsaKeyGenerator产生RSA公私钥对，需要将接入方的私钥填入自己的系统，将公钥发给VST支付系统的开发人员（alaric），配置到系统配置文件。
VST支付系统的公钥需要找支付系统的开发人员（alaric）获取。


统一规则：<br/>
1、接口统一使用http/https。<br/>
2、接口数据格式和返回数据格式都用json，请设置contentType为application/json。<br/>
3、接口参数编码统一为UTF-8。<br/>
4、header中设置X-Request-ID、appId、sign。<br/>
5、默认POST请求需要双向签名认知，GET方法不需要签名认证。

说明：appId由我方颁发，X-Request-ID在请求时保证唯一，可以是毫米数加随机码，由请求方自己生成，sign为RSA算法签名，签名参考demo。



# pay-controller

<a id="opIdpay"></a>

## POST pay

POST /pay/pay

> Body 请求参数

```json
{
  "userId": 0,
  "orderNo": "string",
  "callbackUrl": "string",
  "redirectUrl": "string",
  "payType": 0,
  "vendor": 0,
  "amount": 0,
  "count": 0,
  "totalAmount": 0,
  "currency": "string",
  "title": "string",
  "note": "string",
  "extendParams": "string",
  "osType": 0,
  "timeout": 0
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|[PayOderVO](#schemapayodervo)| 否 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RPayOrderDTO](#schemarpayorderdto)|

<a id="opIdqueryPayWay"></a>

## GET queryPayWay

GET /pay/payWay

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|accountId|query|string| 是 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RListPayWayDTO](#schemarlistpaywaydto)|

<a id="opIdqueryPayStatus"></a>

## POST queryPayStatus

POST /pay/payStatus

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|orderNo|query|string| 否 |业务方订单号，必须|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RPayOrderDTO](#schemarpayorderdto)|

# third-busi-call-back

<a id="opIdniHao"></a>

## POST niHao

POST /callback/niHao

> Body 请求参数

```json
{
  "userId": 0,
  "orderNo": "string",
  "callbackUrl": "string",
  "redirectUrl": "string",
  "payType": 0,
  "vendor": 0,
  "amount": 0,
  "count": 0,
  "totalAmount": 0,
  "currency": "string",
  "title": "string",
  "note": "string",
  "extendParams": "string",
  "osType": 0,
  "timeout": 0
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|[PayOderVO](#schemapayodervo)| 否 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RPayOrderDTO](#schemarpayorderdto)|

# cash-out-controller

<a id="opIdquery"></a>

## POST query

POST /cash/query

> Body 请求参数

```json
{
  "userId": 0,
  "partnerOrderNo": "string"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|[CashQueryVO](#schemacashqueryvo)| 否 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RCashOutDTO](#schemarcashoutdto)|

<a id="opIdcashOut"></a>

## POST cashOut

POST /cash/out

> Body 请求参数

```json
{
  "userId": 0,
  "orderNo": "string",
  "amount": 0,
  "currency": "string",
  "callbackUrl": "string",
  "bankCard": "string",
  "clientIp": "string"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|[CashOutVO](#schemacashoutvo)| 否 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RCashOutDTO](#schemarcashoutdto)|

# 数据模型

<h2 id="tocS_Pet">Pet</h2>

<a id="schemapet"></a>
<a id="schema_Pet"></a>
<a id="tocSpet"></a>
<a id="tocspet"></a>

```json
{
  "id": 1,
  "category": {
    "id": 1,
    "name": "string"
  },
  "name": "doggie",
  "photoUrls": [
    "string"
  ],
  "tags": [
    {
      "id": 1,
      "name": "string"
    }
  ],
  "status": "available"
}

```

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|id|integer(int64)|true|none||宠物ID编号|
|category|[Category](#schemacategory)|true|none||分组|
|name|string|true|none||名称|
|photoUrls|[string]|true|none||照片URL|
|tags|[[Tag](#schematag)]|true|none||标签|
|status|string|true|none||宠物销售状态|

#### 枚举值

|属性|值|
|---|---|
|status|available|
|status|pending|
|status|sold|

<h2 id="tocS_Category">Category</h2>

<a id="schemacategory"></a>
<a id="schema_Category"></a>
<a id="tocScategory"></a>
<a id="tocscategory"></a>

```json
{
  "id": 1,
  "name": "string"
}

```

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|id|integer(int64)|false|none||分组ID编号|
|name|string|false|none||分组名称|

<h2 id="tocS_Tag">Tag</h2>

<a id="schematag"></a>
<a id="schema_Tag"></a>
<a id="tocStag"></a>
<a id="tocstag"></a>

```json
{
  "id": 1,
  "name": "string"
}

```

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|id|integer(int64)|false|none||标签ID编号|
|name|string|false|none||标签名称|

<h2 id="tocS_PayOderVO">PayOderVO</h2>

<a id="schemapayodervo"></a>
<a id="schema_PayOderVO"></a>
<a id="tocSpayodervo"></a>
<a id="tocspayodervo"></a>

```json
{
  "userId": 0,
  "orderNo": "string",
  "callbackUrl": "string",
  "redirectUrl": "string",
  "payType": 0,
  "vendor": 0,
  "amount": 0,
  "count": 0,
  "totalAmount": 0,
  "currency": "string",
  "title": "string",
  "note": "string",
  "extendParams": "string",
  "osType": 0,
  "timeout": 0
}

```

支付请求VO

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|userId|integer(int64)|false|none||购买用户userId 必须|
|orderNo|string|false|none||请求支付的订单号，在业务系统中必须唯一， 必须|
|callbackUrl|string|false|none||后端回调业务方地址， 必须|
|redirectUrl|string|false|none||页面重定向地址，在wap或者pc h5调用的时候用，paypal支付h5页面 特定场景必须|
|payType|integer(int32)|false|none||支付方式 1-余额支付 2-算力支付 3-现金支付 ，必须|
|vendor|integer(int32)|false|none||现金支付的渠道：1-微信 2-支付宝 3-银联 4-paypal 必须|
|amount|number|false|none||单价，可选|
|count|integer(int32)|false|none||数量，可选|
|totalAmount|number|false|none||总价，必须|
|currency|string|false|none||总价，必须|
|title|string|false|none||支付标题，必须|
|note|string|false|none||支付标题，可选，如果没有的话，默认跟标题一致|
|extendParams|string|false|none||扩展参数，可选|
|osType|integer(int32)|false|none||1-ANDROID 2-IOS 3-WAP 4-PC 必须|
|timeout|integer(int32)|false|none||订单超时时间，余额支付、算力支付默认30分钟，三方支付默认2小时，可选|

<h2 id="tocS_PayOrderDTO">PayOrderDTO</h2>

<a id="schemapayorderdto"></a>
<a id="schema_PayOrderDTO"></a>
<a id="tocSpayorderdto"></a>
<a id="tocspayorderdto"></a>

```json
{
  "payOrderNo": "string",
  "orderNo": "string",
  "callbackUrl": "string",
  "redirectUrl": "string",
  "orderInfo": "string",
  "payType": 0,
  "vendor": 0,
  "amount": 0,
  "count": 0,
  "totalAmount": 0,
  "currency": "string",
  "title": "string",
  "note": "string",
  "extendParams": "string",
  "osType": "string",
  "timeout": 0,
  "status": 0
}

```

支付订单返回对象

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|payOrderNo|string|false|none||支付订单号|
|orderNo|string|false|none||业务方订单号|
|callbackUrl|string|false|none||业务方回调地址|
|redirectUrl|string|false|none||页面重定向地址|
|orderInfo|string|false|none||用于调起渠道方sdk的订单信息，具体使用参见NihaoPay提供的IOS Demo or Android Demo。微信支付的In-app功能需要特殊流程，如果要开通，请联系NihaoPay获取帮助。|
|payType|integer(int32)|false|none||支付类型，1-余额支付 2-算力支付 3-现金支付|
|vendor|integer(int32)|false|none||现金支付的回复方式，1-微信 2-支付宝 3-银联 4-paypal|
|amount|number|false|none||单价|
|count|integer(int32)|false|none||数量|
|totalAmount|number|false|none||总价|
|currency|string|false|none||币种|
|title|string|false|none||支付标题|
|note|string|false|none||备注|
|extendParams|string|false|none||扩展字段|
|osType|string|false|none||操作系统类型，1-ANDROID 2-IOS 3-wap 4-pc|
|timeout|integer(int32)|false|none||订单超时时间|
|status|integer(int32)|false|none||订单状态，默认0-创建订单 1-支付中 2-支付成功 3-支付失败 4-已退款|

<h2 id="tocS_RPayOrderDTO">RPayOrderDTO</h2>

<a id="schemarpayorderdto"></a>
<a id="schema_RPayOrderDTO"></a>
<a id="tocSrpayorderdto"></a>
<a id="tocsrpayorderdto"></a>

```json
{
  "code": 0,
  "success": true,
  "data": {
    "payOrderNo": "string",
    "orderNo": "string",
    "callbackUrl": "string",
    "redirectUrl": "string",
    "orderInfo": "string",
    "payType": 0,
    "vendor": 0,
    "amount": 0,
    "count": 0,
    "totalAmount": 0,
    "currency": "string",
    "title": "string",
    "note": "string",
    "extendParams": "string",
    "osType": "string",
    "timeout": 0,
    "status": 0
  },
  "msg": "string"
}

```

返回信息

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||状态码|
|success|boolean|false|none||是否成功|
|data|[PayOrderDTO](#schemapayorderdto)|false|none||支付订单返回对象|
|msg|string|false|none||返回消息|

<h2 id="tocS_PayWayDTO">PayWayDTO</h2>

<a id="schemapaywaydto"></a>
<a id="schema_PayWayDTO"></a>
<a id="tocSpaywaydto"></a>
<a id="tocspaywaydto"></a>

```json
{
  "code": 0,
  "name": "string"
}

```

支付方式查询返回结果类

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||支付方式编码|
|name|string|false|none||支付方式名称|

<h2 id="tocS_RPayWayDTO">RPayWayDTO</h2>

<a id="schemarpaywaydto"></a>
<a id="schema_RPayWayDTO"></a>
<a id="tocSrpaywaydto"></a>
<a id="tocsrpaywaydto"></a>

```json
{
  "code": 0,
  "success": true,
  "data": {
    "code": 0,
    "name": "string"
  },
  "msg": "string"
}

```

返回信息

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||状态码|
|success|boolean|false|none||是否成功|
|data|[PayWayDTO](#schemapaywaydto)|false|none||支付方式查询返回结果类|
|msg|string|false|none||返回消息|

<h2 id="tocS_CashQueryVO">CashQueryVO</h2>

<a id="schemacashqueryvo"></a>
<a id="schema_CashQueryVO"></a>
<a id="tocScashqueryvo"></a>
<a id="tocscashqueryvo"></a>

```json
{
  "userId": 0,
  "partnerOrderNo": "string"
}

```

提现结果查询请求参数

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|userId|integer(int64)|false|none||用户id 必须|
|partnerOrderNo|string|false|none||业务线编号 必须|

<h2 id="tocS_QueryOrderStatusVO">QueryOrderStatusVO</h2>

<a id="schemaqueryorderstatusvo"></a>
<a id="schema_QueryOrderStatusVO"></a>
<a id="tocSqueryorderstatusvo"></a>
<a id="tocsqueryorderstatusvo"></a>

```json
{
  "orderNo": "string"
}

```

订单状态查询请求类

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|orderNo|string|false|none||业务方订单号，必须|

<h2 id="tocS_CashOutDTO">CashOutDTO</h2>

<a id="schemacashoutdto"></a>
<a id="schema_CashOutDTO"></a>
<a id="tocScashoutdto"></a>
<a id="tocscashoutdto"></a>

```json
{}

```

承载数据

### 属性

*None*

<h2 id="tocS_RCashOutDTO">RCashOutDTO</h2>

<a id="schemarcashoutdto"></a>
<a id="schema_RCashOutDTO"></a>
<a id="tocSrcashoutdto"></a>
<a id="tocsrcashoutdto"></a>

```json
{
  "code": 0,
  "success": true,
  "data": {},
  "msg": "string"
}

```

返回信息

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||状态码|
|success|boolean|false|none||是否成功|
|data|[CashOutDTO](#schemacashoutdto)|false|none||承载数据|
|msg|string|false|none||返回消息|

<h2 id="tocS_CashOutVO">CashOutVO</h2>

<a id="schemacashoutvo"></a>
<a id="schema_CashOutVO"></a>
<a id="tocScashoutvo"></a>
<a id="tocscashoutvo"></a>

```json
{
  "userId": 0,
  "orderNo": "string",
  "amount": 0,
  "currency": "string",
  "callbackUrl": "string",
  "bankCard": "string",
  "clientIp": "string"
}

```

提现请求参数

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|userId|integer(int64)|false|none||用户id 必须|
|orderNo|string|false|none||请求订单号 必须|
|amount|number|false|none||提现金额 必须|
|currency|string|false|none||币种 必须|
|callbackUrl|string|false|none||后端回调业务方地址， 必须|
|bankCard|string|false|none||银行卡 必须|
|clientIp|string|false|none||用户端ip地址，必须|

<h2 id="tocS_RListPayWayDTO">RListPayWayDTO</h2>

<a id="schemarlistpaywaydto"></a>
<a id="schema_RListPayWayDTO"></a>
<a id="tocSrlistpaywaydto"></a>
<a id="tocsrlistpaywaydto"></a>

```json
{
  "code": 0,
  "success": true,
  "data": [
    {
      "code": 0,
      "name": "string"
    }
  ],
  "msg": "string"
}

```

返回信息

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||状态码|
|success|boolean|false|none||是否成功|
|data|[[PayWayDTO](#schemapaywaydto)]|false|none||承载数据|
|msg|string|false|none||返回消息|

