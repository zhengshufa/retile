---
title: VST-Pay
language_tabs:
  - shell: Shell
  - http: HTTP
  - javascript: JavaScript
  - ruby: Ruby
  - python: Python
  - php: PHP
  - java: Java
  - go: Go
toc_footers: []
includes: []
search: true
code_clipboard: true
highlight_theme: darkula
headingLevel: 2
generator: "@tarslib/widdershins v4.0.23"

---

# VST-Pay

Base URLs:

# Authentication



Base URLs:http://serviceIP:port/ly-pay/

# Authent[VST-Pay.md](../../../../文档/支付接口文档v1.0/VST-Pay.md)ication

VST项目支付接口统一用RSA非对称加密方式签名，即用接入方的私钥签名，VST支付服务端用接入方的公钥验签。
接口返回结果，支付系统会用私钥签名，接入方需要使用支付系统的公钥验签。
可根据demo提供的工具RsaKeyGenerator产生RSA公私钥对，需要将接入方的私钥填入自己的系统，将公钥发给VST支付系统的开发人员（alaric），配置到系统配置文件。
VST支付系统的公钥需要找支付系统的开发人员（alaric）获取。


统一规则：<br/>
1、接口统一使用http/https。<br/>
2、接口数据格式和返回数据格式都用json，请设置contentType为application/json。<br/>
3、接口参数编码统一为UTF-8。<br/>
4、header中设置X-Request-ID、appId、sign。<br/>
5、默认POST请求需要双向签名认知，GET方法不需要签名认证。

说明：appId由我方颁发，X-Request-ID在请求时保证唯一，可以是毫米数加随机码，由请求方自己生成，sign为RSA算法签名，签名参考demo。





# charge-controller

<a id="opIdchargeInner"></a>

## POST chargeInner

POST /charge/inner

> Body 请求参数

```json
{
  "tradeNo": "string",
  "referralCode": "string",
  "userId": 0,
  "amount": 0,
  "currency": "string",
  "timestamp": 0,
  "title": "string",
  "extParams": "string"
}
```

### 请求参数

|名称|位置|类型|必选|说明|
|---|---|---|---|---|
|body|body|[ChargeVO](#schemachargevo)| 否 |none|

> 返回示例

> 200 Response

### 返回结果

|状态码|状态码含义|说明|数据模型|
|---|---|---|---|
|200|[OK](https://tools.ietf.org/html/rfc7231#section-6.3.1)|OK|[RChargeDTO](#schemarchargedto)|

# 数据模型

<h2 id="tocS_ChargeVO">ChargeVO</h2>

<a id="schemachargevo"></a>
<a id="schema_ChargeVO"></a>
<a id="tocSchargevo"></a>
<a id="tocschargevo"></a>

```json
{
  "tradeNo": "string",
  "referralCode": "string",
  "userId": 0,
  "amount": 0,
  "currency": "string",
  "timestamp": 0,
  "title": "string",
  "extParams": "string"
}

```

充值请求

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|tradeNo|string|false|none||充值交易号 需要保持唯一性 必须|
|referralCode|string|false|none||推荐码 必须|
|userId|integer(int64)|false|none||用户Id 必须|
|amount|number|false|none||金额 单位为最小单位，美元对应的是美分，日元对应的是日元 必须|
|currency|string|false|none||币种 必须|
|timestamp|integer(int64)|false|none||时间戳 毫秒数 必须|
|title|string|false|none||标题，必须|
|extParams|string|false|none||扩展字段，json格式，可以为空|

<h2 id="tocS_ChargeDTO">ChargeDTO</h2>

<a id="schemachargedto"></a>
<a id="schema_ChargeDTO"></a>
<a id="tocSchargedto"></a>
<a id="tocschargedto"></a>

```json
{
  "tradeNo": "string",
  "chargeNo": "string",
  "referralCode": "string",
  "amount": 0,
  "currency": "string",
  "timestamp": 0,
  "title": "string",
  "extParams": "string",
  "status": 0
}

```

充值请求

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|tradeNo|string|false|none||充值交易号 需要保持唯一性，原样返回|
|chargeNo|string|false|none||我方充值订单号|
|referralCode|string|false|none||推荐码 ，原样返回|
|amount|number|false|none||金额 单位为最小单位，美元对应的是美分，日元对应的是日元 ，原样返回|
|currency|string|false|none||币种 ，原样返回|
|timestamp|integer(int64)|false|none||时间戳 毫秒数 ，原样返回|
|title|string|false|none||标题，原样返回|
|extParams|string|false|none||扩展字段，json格式，原样返回|
|status|integer(int32)|false|none||充值状态 0-默认订单生成 1-充值中 2-充值成功 3-充值失败 4-已退款|

<h2 id="tocS_RChargeDTO">RChargeDTO</h2>

<a id="schemarchargedto"></a>
<a id="schema_RChargeDTO"></a>
<a id="tocSrchargedto"></a>
<a id="tocsrchargedto"></a>

```json
{
  "code": 0,
  "success": true,
  "data": {
    "tradeNo": "string",
    "chargeNo": "string",
    "referralCode": "string",
    "amount": 0,
    "currency": "string",
    "timestamp": 0,
    "title": "string",
    "extParams": "string",
    "status": 0
  },
  "msg": "string"
}

```

返回信息

### 属性

|名称|类型|必选|约束|中文名|说明|
|---|---|---|---|---|---|
|code|integer(int32)|false|none||状态码|
|success|boolean|false|none||是否成功|
|data|[ChargeDTO](#schemachargedto)|false|none||充值请求|
|msg|string|false|none||返回消息|

